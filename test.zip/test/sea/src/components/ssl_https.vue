<template>
</template>


<script>
  import { Loading } from 'element-ui'
  import {
    sslSstatusApply,
    sslOpenApply,
    sslCloseApply,
  } from '@/api/website'

  export default {
    data() {
      return {
      }
    },
    mounted() {
    },
    methods: {
      sslSstatusApply(type, row) { // ssl状态 ,未使用
        let query = {}
        query.siteid = row.id
        this.$set(row, 'showLoading3', true)
        sslSstatusApply(query).then(response => {
          if(response.status) {
            this.$alert(response.message, '提示', {
              confirmButtonText: '确认'
            })
          } else {
            this.$alert(response.data, '提示', {
              confirmButtonText: '确认'
            })
          }
          this.$set(row, 'showLoading3', false)
        }).catch(err => {
          console.log(err)
        })
      },
      applyHttps(type, row) {
        let title = ''
        type == 'open' ? title = '开启' : title = '关闭'
        this.$alert(`此操作将${title}申请证书, 是否继续?`, '提示', {
          confirmButtonText: '确定',
          callback: action => {
            if(action == 'confirm') {
              let query = {}
              query.siteid = row.id
              if(type == 'open') { // 开启
                sslOpenApply(query).then(response => {
                  if(response.status) {
                    this.$alert(response.message, '提示', {
                      confirmButtonText: '确认'
                    })
                  } else {
                    this.$alert(response.data, '提示', {
                      confirmButtonText: '确认'
                    })
                  }
                }).catch(err => {
                  console.log(err)
                })
              } else { // 关闭
                sslCloseApply(query).then(response => {
                  if(response.status) {
                    this.$alert(response.data, '提示', {
                      confirmButtonText: '确认'
                    })
                  } else {
                    this.$alert(response.message, '提示', {
                      confirmButtonText: '确认'
                    })
                  }
                }).catch(err => {
                  console.log(err)
                })
              }
            }
          }
        })
      }
    }
  }
</script>

<style>
</style>