<template>
  <div class="editable-cell">
    <div v-if="editable" class="editable-cell-input-wrapper clearfix">
      <el-input v-if="inputType == 'input'" class="editable-input" ref="editableInput" v-model="value" size="mini"
        @input="handleInput" @keyup.enter.native="check"></el-input>
      <el-input v-if="inputType == 'textarea'" type="textarea" autosize ref="editableTextarea" v-model="value"
        @input="handleInput" @keyup.enter.native="check"></el-input>
      <i class="editable-cell-icon-check el-icon-check" @click="check"></i>
    </div>
    <div v-else class="editable-cell-text-wrapper">
      {{ value || ' ' }}
      <i class="editable-cell-icon el-icon-edit" @click="edit"></i>
    </div>
  </div>
</template>
<script>
  export default {
    props: {
      text: [String, Number],
      inputType: {
        type: String,
        default: () => 'input'
      }
    },
    watch: {
      text(newValue, oldValue) {
        this.value = newValue;
      }
    },
    data() {
      return {
        value: this.text,
        editable: false,
      }
    },
    methods: {
      handleInput(e) {
        const value = e;
        this.value = value;
      },
      check() {
        this.editable = false;
        this.$emit('changeValue', this.value);
      },
      edit() {
        this.editable = true;
        this.$nextTick(() => {
          this.$refs.editableInput?.focus();
          this.$refs.editableTextarea?.focus();
        })
      }
    }
  }
</script>
<style>
  .cl:after,
  .clearfix:after {
    content: ".";
    display: block;
    height: 0;
    clear: both;
    visibility: hidden;
  }

  .cl,
  .clearfix {
    zoom: 1;
  }

  .editable-cell {
    position: relative;
  }

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding-right: 24px;
    height: 28px;
    line-height: 28px;
  }

  .editable-cell-text-wrapper {
    /* padding: 5px 24px 5px 5px; */
  }

  .editable-cell-input-wrapper .editable-input {
    float: left;
  }

  .editable-cell-input-wrapper .el-textarea {
    height: 100%;
  }

  .editable-cell-input-wrapper .el-textarea textarea {
    height: 100%;
    overflow: hidden;
  }

  .editable-cell-icon,
  .editable-cell-icon-check {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    margin: auto;
    cursor: pointer;
  }

  .editable-cell-icon {
    width: 16px;
    height: 16px;
    line-height: 16px;
    text-align: center;
    display: none;
  }

  .editable-cell-icon-check {
    width: 16px;
    height: 16px;
    line-height: 16px;
    text-align: center;
  }

  .editable-cell:hover .editable-cell-icon {
    display: inline-block;
  }

  .editable-cell-icon:hover,
  .editable-cell-icon-check:hover {
    color: #108ee9;
  }


  td.textareaColumn *:not(i) {
    height: 100%;
  }

  .textareaColumn textarea {
    min-height: 100% !important;
  }
</style>
