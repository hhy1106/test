<template>
  <div class="server-select">
    <label>服务器：</label>
    <el-select
      v-model="server_lable"
      @change="serverChange($event)"
      style="width: 220px;">
      <el-option
        v-for="(item, index) in optionsServer"
        :key="item.id"
        :label="item.label + '（' + item.value+ '）'" :value="item.value">
      </el-option>
    </el-select>

  </div>
</template>

<script>
import {
  severList
} from '@/api/server'
export default {
  props: {
    showAllOpation: Boolean,
    cloneDeploy: Boolean
  },
  data() {
    return {
      deploy: 'all',
      page: 1,
      limit: 10000,
      keywordsInput: '',
      optionsServer: [],
      server_id: null,
      server_lable: ''
    }
  },
  mounted() {
    this.cloneDeploy ? this.deploy = 'clone' : this.deploy = this.deploy
    this.getServerList()
  },
  methods: {
    getServerList() { // 查
      let query = {}
      query.page = this.page
      query.limit = this.limit
      query.deploy = this.deploy
      query.keywordsInput = ''
      severList(query).then(response => {
        if(response.status) {
          this.optionsServer = []
          response.data.list.forEach((item) => {
            let obj = {}
            obj.value = item.server_ip
            obj.label = item.iname
            obj.sid = item.id
            this.optionsServer.push(obj)
            this.optionsServer  = this.optionsServer.reverse()
            this.server_lable = this.optionsServer[0].value
          })
          // if(this.showAllOpation) { // 追加“不限”选项
          //   const objFirst = {}
          //   objFirst.value = 0
          //   objFirst.label = '不限'
          //   this.optionsServer.unshift(objFirst)
          // }
          this.$emit('selectVal', '', this.optionsServer)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    serverChange(data) {
      this.$emit('selectVal', data, this.optionsServer)
    }
  },
  watch: {
    server_lable(val) {
      if(val) {
        this.$emit('selectVal', val, this.optionsServer)
      }
    }
  }
}
</script>

<style scoped>
  .server-select {
    display: flex;
    align-items: center;
  }
</style>
