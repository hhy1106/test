<template>
  <div class="server-card">

    <el-menu
      :collapse="isCollapse"
      default-active="1"
      class="el-menu-vertical-demo"
      :unique-opened="true"
      :default-openeds="openeds"
      @open="handleOpen"
      @close="handleClose"
      background-color="#304156"
      text-color="#fff">
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-coin"></i>
          <span>服务器选择（共{{ serverList.length || 0}}台）</span>
        </template>
        <el-menu-item-group>
          <el-menu-item
            v-for="(item, index) in serverList"
            @click.native="serverChange(item)"
            :class="{ 'server-active':clickFlag == item.id }"
            :index='"1-"+index'
            :key="item.id">
              <div class="item-area">
                <span class="iname">{{ item.iname }}</span> -
                <span class="ip">{{ item.server_ip }}</span>
                <!-- <i class="el-icon-check"></i> -->
                <i>☑️</i>
              </div>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>

  </div>
</template>

<script>
import {
  severList
} from '@/api/server'
export default {
  data() {
    return {
      isCollapse: false,
      clickFlag:-1,
      deploy: 'clone',
      page: 1,
      limit: 10000,
      keywordsInput: '',
      serverList: [],
      openeds: ['1'],
      optionsServer: [],
      server_id: null,
      server_lable: ''
    }
  },
  mounted() {
    this.getServerList()
  },
  methods: {
    getServerList() { // 查
      let query = {}
      query.page = this.page
      query.limit = this.limit
      query.deploy = this.deploy
      query.keywordsInput = ''
      severList(query).then(response => {
        if(response.status) {
          this.serverList = response.data.list
          // console.log(this.serverList)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    serverChange(item) {
      this.clickFlag = item.id
      let obj = {}
      obj.value = item.server_ip
      obj.label = item.iname
      obj.sid = item.id
      obj.spiderConfig = item.spider_config?JSON.parse(item.spider_config) :{}
      this.optionsServer.push(obj)
      if(obj.spiderConfig?.proxy_host){
        localStorage.setItem('__FANZHANQUNHOST__',obj.spiderConfig?.proxy_host)
      }

      this.$emit('selectVal', item, this.optionsServer)
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    }
  },
  watch: {
    server_lable(val) {
      if(val) {
        this.$emit('selectVal', val, this.optionsServer)
      }
    }
  }
}
</script>

<style lang="scss">

  .server-card {
    float: left;
    background: url('../assets/bg-server.png') repeat-y;
    background-size: cover;
    border-right: 3px solid transparent;
    -webkit-border-image: url("../assets/bg-line-left.png") 3 stretch; /* Safari 3.1-5 */
    -o-border-image: url("../assets/bg-line-left.png") 3 stretch; /* Opera 11-12.1 */
    border-image: url("../assets/bg-line-left.png") 3 stretch;
    width: 210px;
    margin: 0;
    position: relative;
    height: calc(100vh - 58px);
    border-radius: 0 0 0 5px;
    .el-menu {
      border-right: none!important;
      background: transparent!important;
    }
    .el-menu-item {
      padding: 0!important;
      background: transparent!important;
      &:hover {
        background: rgb(178, 225, 76, 0.7) !important;
      }
      .item-area {
        display: flex;
        align-items: center;
        color: #fff;
        text-align: center;
        opacity: 0.9;
        span {
          // margin: 0 5px;
        }
        .iname {
          font-weight: 700;
          color: #b2e14c;
          margin: 0;
          padding: 0 5px;
          width: 60px;
          overflow: hidden;
        }
        i {
          display: none;
        }
      }
    }
    .el-menu-item.is-active {
      color: #000!important;
      background-color: rgb(255, 208, 75) !important;
      .item-area {
        color: #000!important;
        opacity: 1;
        .iname {
          color: #000;
          border-right: none;
          background-color: rgb(255, 208, 75);
        }
        i {
          display: block;
          position: absolute;
          right: 3px;
          top: 0;
          border-radius: 0 0 0 6px;
          font-size: 14px;
          font-style: normal;
          height: 13px;
          line-height: 13px;
          padding: 0 5px;
          background-color: #4c4c51;
          background: linear-gradient(#4c4c51, #bd959c);
        }
      }
    }
    .el-menu-item-group__title {
      display: none;
    }
  }
</style>
