<template>
  <el-dropdown @command="filterChange">
    <!-- <i :class="['el-icon-arrow-down', 'el-icon-arrow-up', currentValue !== '' ? 'active' : '']"></i> -->
    <!-- <svg-icon icon-class="ico-filter" /> -->
    <i class="el-icon-s-operation" style="font-size: 18px;"></i>

    <el-dropdown-menu
      slot="dropdown"
      class="ad-search-dropdown"
    >
      <el-dropdown-item
        v-for="(item, index) in list"
        :key="index"
        :command="item[filterValue]"
        :class="item[[filterValue]] === currentValue ? 'active' : ''"
      >
        {{ item[filterLabel] }}
      </el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script>
export default {
  props: {
    filterList: {
      type: Array,
      default: () => []
    },
    filterValue: {
      type: String,
      default: '',
      required: true
    },
    filterLabel: {
      type: String,
      default: '',
      required: true
    },
    currentValue: {
      type: String,
      default: ''
    }
  },
  computed: {
    list() {
      let { filterList, filterValue, filterLabel } = this
      if (filterList && filterValue && filterLabel) {
        let arr = [].concat(filterList)
        // arr.unshift({
        //   [filterValue]: '',
        //   [filterLabel]: '全部状态'
        // })
        return arr
      } else {
        return []
      }
    }
  },
  methods: {
    filterChange(id) {
      this.$emit('filterChange', id)
    }
  }
}
</script>
<style lang="scss" scoped>
.el-dropdown {
  cursor: pointer;
}
</style>
