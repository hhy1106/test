<template>
  <div class="server-card">

    <el-menu
      :collapse="isCollapse"
      default-active="1"
      class="el-menu-vertical-demo"
      :unique-opened="true"
      :default-openeds="openeds"
      @open="handleOpen"
      @close="handleClose"
      background-color="#304156"
      text-color="#fff">
      <el-menu-item index="2">
        <template slot="title">
          <i class="el-icon-coin" type="primary" style="margin-left: auto;"></i>
          <span @click="addForm">新增服务器</span>
        </template>
      </el-menu-item>
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-coin"></i>
          <span>服务器选择（共{{ serverList.length || 0}}台）</span>
        </template>
        <el-menu-item-group>
          <el-menu-item
            v-for="(item, index) in serverList"
            @click.native="serverChange(item)"
            :class="{ 'server-active':clickFlag == item.id }"
            :index='"1-"+index'
            :key="item.id">
              <div class="item-area">
                <span class="iname">{{ item.iname }}</span> -
                <span class="ip">{{ item.server_ip }}</span>
                <!-- <i class="el-icon-check"></i> -->
                <i>☑️</i>
              </div>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>

  </div>
</template>

<script>
import {
  severList
} from '@/api/server'
export default {
  data() {
    return {
      titleDialog: '添加服务器',
      tinyproxyConfig: '',
      isCollapse: false,
      clickFlag:-1,
      deploy: 'clone',
      page: 1,
      limit: 10000,
      keywordsInput: '',
      serverList: [],
      openeds: ['1'],
      optionsServer: [],
      server_id: null,
      server_lable: ''
    }
  },
  mounted() {
    this.getServerList()
  },
  methods: {
    getServerList() { // 查
      let query = {}
      query.page = this.page
      query.limit = this.limit
      query.deploy = this.deploy
      query.keywordsInput = ''
      severList(query).then(response => {
        if(response.status) {
          this.serverList = response.data.list
          console.log(this.serverList)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    addTab(targetName) {
        let newTabName = ++this.tabIndex + '';
        this.editableTabs.push({
          title: 'New Tab',
          name: newTabName,
          content: 'New Tab content'
        });
        this.editableTabsValue = newTabName;
      },
    addForm() {
      this.tinyproxyConfig = ''
      this.dialogCreate = true
      this.titleDialog = '添加服务器'
      // 0327新增内容
//打开父组件的新增弹框
      this.$emit('create')
    },
    editForm(row) {
      // console.log(this.formAdd)
      this.dialogCreate = true
      this.titleDialog = '编辑服务器信息'

      this.formAdd.alive_time = row.alive_time
      this.formAdd.create_time = row.create_time
      this.formAdd.buytime = parseTime(row.create_time)
      this.formAdd.deploy = row.deploy
      this.formAdd.id = row.id
      this.formAdd.desc = row.idesc || '备注内容'
      this.formAdd.name = row.iname
      this.formAdd.location = row.location
      this.selectedCity = row.location
      this.formAdd.host = row.ssh_ip
      this.formAdd.ssh_ip = row.ssh_ip
      this.formAdd.ssh_port = row.ssh_port
      this.formAdd.sshuser = row.ssh_name
      this.formAdd.sshpasswd = row.ssh_passwd
      this.arrChecked = this.formAdd.deploy.split(',')
      this.checkedItem = this.formAdd.deploy.split(',')

      // if(Object.keys(row.spider_config).length > 3) { // 非空对象
      // }
      row.spider_config = JSON.parse(row.spider_config)

      if (!row.spider_config) {
        row.spider_config = this.configData.firewall
      }
      // console.log(row.spider_config)
      this.formAdd.configData = row.spider_config.clone
      this.configData = row.spider_config.clone
      // console.log(this.configData.firewall.status)
    },
    serverChange(item) {
// 0327新增部分
      this.$emit('getServeInfo',item)
      this.clickFlag = item.id
      let obj = {}
      obj.value = item.server_ip
      obj.label = item.iname
      obj.sid = item.id
      obj.spiderConfig = item.spider_config?JSON.parse(item.spider_config) :{}
      this.optionsServer.push(obj)
      if(obj.spiderConfig?.proxy_host){
        localStorage.setItem('__FANZHANQUNHOST__',obj.spiderConfig?.proxy_host)
      }

      this.$emit('selectVal', item, this.optionsServer)
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    }
  },
  watch: {
    server_lable(val) {
      if(val) {
        this.$emit('selectVal', val, this.optionsServer)
      }
    }
  }
}
</script>

<style lang="scss">

  .server-card {
    float: left;
    background: url('../assets/bg-server.png') repeat-y;
    background-size: cover;
    border-right: 3px solid transparent;
    -webkit-border-image: url("../assets/bg-line-left.png") 3 stretch; /* Safari 3.1-5 */
    -o-border-image: url("../assets/bg-line-left.png") 3 stretch; /* Opera 11-12.1 */
    border-image: url("../assets/bg-line-left.png") 3 stretch;
    width: 210px;
    margin: 0;
    position: relative;
    height: calc(100vh - 58px);
    border-radius: 0 0 0 5px;
    .el-menu {
      border-right: none!important;
      background: transparent!important;
    }
    .el-menu-item {
      padding: 0!important;
      background: transparent!important;
      &:hover {
        background: rgb(178, 225, 76, 0.7) !important;
      }
      .item-area {
        display: flex;
        align-items: center;
        color: #fff;
        text-align: center;
        opacity: 0.9;
        span {
          // margin: 0 5px;
        }
        .iname {
          font-weight: 700;
          color: #b2e14c;
          margin: 0;
          padding: 0 5px;
          width: 60px;
          overflow: hidden;
        }
        i {
          display: none;
        }
      }
    }
    .el-menu-item.is-active {
      color: #000!important;
      background-color: rgb(255, 208, 75) !important;
      .item-area {
        color: #000!important;
        opacity: 1;
        .iname {
          color: #000;
          border-right: none;
          background-color: rgb(255, 208, 75);
        }
        i {
          display: block;
          position: absolute;
          right: 3px;
          top: 0;
          border-radius: 0 0 0 6px;
          font-size: 14px;
          font-style: normal;
          height: 13px;
          line-height: 13px;
          padding: 0 5px;
          background-color: #4c4c51;
          background: linear-gradient(#4c4c51, #bd959c);
        }
      }
    }
    .el-menu-item-group__title {
      display: none;
    }
  }
</style>
