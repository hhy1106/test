<template>
  <div class="group-select">
    <label>分组：</label>
    <el-select
      v-model="server_lable"
      :multiple="multiple"
      @change="groupChange($event)"
      placeholder="不限"
      style="width: 160px;">
      <el-option
        v-for="(item, index) in optionsGroup"
        :key="item.value"
        :label="item.label" :value="item.label">
      </el-option>
    </el-select>

  </div>
</template>

<script>

import {
  groupList
} from '@/api/group'

export default {
  props: {
    showAllOpation: Boolean,
    multiple: Boolean
  },
  data() {
    return {
      page: 1,
      type: 1,
      limit: 10000,
      optionsGroup: [],
      server_lable: ''
    }
  },
  mounted() {
    this.getGroupList()
  },
  methods: {
    getGroupList() { // 查
      let parmers = {}
      parmers.type = this.type // 网站
      parmers.page = this.page
      parmers.limit = this.limit
      groupList(parmers).then(response => {
        if(response.status) {
          this.optionsGroup = []
          response.data.list.forEach((item) => {
            let obj = {}
            obj.value = item.id
            obj.label = item.iname
            this.optionsGroup.push(obj)
            // this.optionsGroup2.push(obj)
          })
          if(this.showAllOpation) { // 追加“不限”选项
            const objFirst = {}
            objFirst.value = ''
            objFirst.label = '不限'
            this.optionsGroup.unshift(objFirst)
          }
        }
      }).catch(err => {
        console.log(err)
      })
    },
    groupChange(data) {
      this.$emit('selectGroup', data, this.optionsGroup)
    }
  }
}
</script>

<style scoped>
  .group-select {
    display: flex;
    align-items: center;
  }
</style>
