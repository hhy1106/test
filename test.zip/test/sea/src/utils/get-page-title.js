import defaultSettings from '@/settings'

const title = defaultSettings.title || '狂侠站群系统'

export default function getPageTitle(pageTitle) {
  if (pageTitle) {
    return `${pageTitle} - ${title}`
  }
  return `${title}`
}
