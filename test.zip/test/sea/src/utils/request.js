import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import { getToken } from '@/utils/auth'
import qs from 'qs'
// create an axios instance
let apiConfig = process.env.VUE_APP_BASE_API
if(window.location.href.indexOf('test.') > -1) { // 线上测试环境
  apiConfig = 'http://47.122.7.214'
}
const service = axios.create({
  baseURL: apiConfig,
  timeout: 30000 // request timeout
})

axios.defaults.headers.post['Content-Type'] = 'application/json;'
// axios.defaults.headers.post['Authorization'] = `Bearer ${getToken()}`

// request interceptor
service.interceptors.request.use(
  config => {
    // do something before request is sent
    if (config.service == 'fanzhanqun') {
      const FANZHANQUNHOST =localStorage.getItem('__FANZHANQUNHOST__')
      let hostUrl=''
      if(FANZHANQUNHOST){
        hostUrl=FANZHANQUNHOST.indexOf('http')>-1?FANZHANQUNHOST:'https://'+FANZHANQUNHOST
      }
      config.baseURL = hostUrl?hostUrl:'http://seoadmin.993tu.com'
      config.headers['Authorization'] = `${getToken()}`
      const methodType = config.method
      if (config.method === 'post'){
        const whiteUrlList = [
          '/yboss/website/data'
        ]
        let notNeed = whiteUrlList.includes(config.url)
        // console.log(whiteUrlList.includes(config.url),'config')
        if(!notNeed){
          config.headers['content-type'] = 'application/x-www-form-urlencoded'
          config.data = qs.stringify(config.data)
        }

      }

    }else{
      if (store.getters.token) {
        config.headers['Authorization'] = `${getToken()}`
        // config.headers['Content-Type'] = 'multipart/form-data'
        config.headers['Content-Type'] = 'application/json'
      }
    }


    return config
  },
  error => {
    // do something with request error
    console.log(error) // for debug
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
  */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  response => {
    const res = response.data
    return res
    // if the custom code is not 20000, it is judged as an error.
    // if (res.code !== 20000) {
    //   Message({
    //     message: res.message || 'Error',
    //     type: 'error',
    //     duration: 5 * 1000
    //   })

    //   if (res.code === 50008 || res.code === 50012 || res.code === 50014) {

    //     MessageBox.confirm('您已登出，请重新登录', '确认登出', {
    //       confirmButtonText: '重新登录',
    //       cancelButtonText: '取消',
    //       type: 'warning'
    //     }).then(() => {
    //       store.dispatch('user/resetToken').then(() => {
    //         location.reload()
    //       })
    //     })
    //   }
    //   return Promise.reject(new Error(res.message || 'Error'))
    // } else {
    //   return res
    // }
  },
  error => {
    console.log('err' + error) // for debug
    Message({
      message: error.message,
      type: 'error',
      duration: 5 * 1000
    })
    return Promise.reject(error)
  }
)

export default service
