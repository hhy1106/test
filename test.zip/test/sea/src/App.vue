<template>
  <div id="app" :class="{'zindex9' : zindex9 == true}">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      zindex9: true
    }
  },
  watch:{
    $route:{
      handler(val,oldval){
        val.name == 'Server' ? this.zindex9 = false : this.zindex9 = true
      },
      deep: true
    }
  }
}
</script>

<style>
  .zindex9 {
    /* z-index: 9999; */
  }
</style>
