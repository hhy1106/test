import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
* 接口名称：获取域名DNS解析
* type	A 解析类型：A、CNAME、TXT
*   domain	www.236tv.com 要查询的域名
*/
export function dnsQuery(data) {
  return request({
    url: '/domain/dns?type=' + data.type + '&domain=' + data.domain,
    method: 'get',
    data
  })
}
/*
* 接口名称： 克隆站点预览功能
*/
export function clonePreview(data) {
  return request({
    url: '/domain/preview?url=' + data.url,
    method: 'get',
    data
  })
}