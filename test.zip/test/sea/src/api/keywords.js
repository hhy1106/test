import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
* 接口名称：词库列表
* siteid	1
* file	[文件路径]
*/
export function keywordsList(data,form) {
  return request({
    url: '/website/cklist?token=' + getToken() + '&siteid=' + data.siteid + '&limit=' + data.limit + '&page=' + data.page,
    method: 'get',
    data
  })
}
/*
* 接口名称：导入词库
* siteid	1
* file	[文件路径]
*/
export function keywordsImport(data) {
  return request({
    url: '/website/importck?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：清空词库
* siteid	1
*/
export function keywordsClear(data) {
  return request({
    url: '/website/ckclear?token=' + getToken(),
    method: 'post',
    data
  })
}

/*
* 接口名称：词编辑
* siteid	1
* kwid // 词id
* word
*/
export function keywordsEdit(data) {
  return request({
    url: '/website/ckedit?token=' + getToken(),
    method: 'post',
    data
  })
}
