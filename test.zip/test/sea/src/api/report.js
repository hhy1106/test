import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
*   接口名称：获取蜘蛛记录
*   server_id	服务器id
*   domain 传空值就是当前服务器所有
*/
export function spiderRecord(data) {
  return request({
    url: '/nginx/everyday?domain=' + data.domain + '&server_id=' + data.server_id+ '&start_time=' + data.start_time+ '&end_time=' + data.end_time,
    method: 'get'
  })
}
/*
*   接口名称：获取收录记录
*   server_id	服务器id
*   domain 传空值就是当前服务器所有
*/
export function shouluRecord(data) {
  return request({
    url: '/website/today?domain=' + data.domain + '&start_time=' + data.start_time + '&end_time=' + data.end_time,
    method: 'get'
  })
}

/*
*   接口名称：蜘蛛单台服务器排行记录
*   server_id	服务器id
*/
export function rankingList(data) {
  return request({
    url: '/nginx/ranking_list?server_id=' + data.server_id + '&start_time=' + data.start_time + '&end_time=' + data.end_time,
    method: 'get'
  })
}
