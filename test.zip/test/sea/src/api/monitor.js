import request from '@/utils/request'
import { getToken } from '@/utils/auth'
// let apiMonitor = 'http://webaotuapi.cp0801.com'
let apiMonitor = 'http://webauto.yichadaodi.com'
/*
* 接口名称：获取域名列表
* limit	1
* page 1
*/
export function getDomainList(data) {
  return request({
    url: apiMonitor + '/domain/getlist?page=' + data.page + '&limit=' + data.limit + '&domain=' + data.domain,
    method: 'get',
    data
  })
}
/*
* 接口名称：域名监测结果接收
* limit	1
* page 1
*/
export function getDomainResult(data) {
  return request({
    url: apiMonitor + '/domain/detect?page=' + data.page + '&limit=' + data.limit + '&type=' + data.type,
    method: 'get',
    data
  })
}

/*
* 接口名称：数据展示接口
* limit	1
* page 1
*/
export function getDomainShow(data) {
  return request({
    url: apiMonitor + '/domain/show?page=' + data.page + '&limit=' + data.limit + '&type=' + data.type,
    method: 'get',
    data
  })
}

/*
* 接口名称：新增域名接口
* limit	1
*/
export function domainInsert(data) {
  return request({
    url: apiMonitor + '/domain/inst',
    method: 'post',
    data
  })
}
