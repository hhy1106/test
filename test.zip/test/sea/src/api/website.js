import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
* 接口名称：tdk列表
* 接口URL：GET127.0.0.1:5000/website/list?domain=com&status=1
* Content-Type：multipart/form-data
* server_ip	127.0.0.1		否	默认全部，否则传指定的服务器IP
* group	分组名称		否	 分组名称，默认填全部
* domain	com		否	 要搜索的域名关键词，可以为空
* status	1		否	 默认传-1，表示全部
* page	1		(必填)
* limit	10		(必填)
*/
export function tdkList(data) {
  return request({
    url: '/website/tkd?site_id=' + data.site_id,
    method: 'get'
  })
}
export function getTdkList(query) {
  return request({
    url: '/website/tkd',
    method: 'get',
    params:query,
  })
}
/*
  * 接口名称：维护站点TKD
  * site_id 站点ID
  * idxt
  * idxk
  * idxd
  * innt
  * innk
  * innd
  * innt_num
  * innk_num
  * innd_num
*/
export function tkdUpdate(data) {
  return request({
    url: '/website/update_tkd',
    method: 'post'
  })
}

/*
* 接口名称：站点列表
* 接口URL：GET127.0.0.1:5000/website/list?domain=com&status=1
* Content-Type：multipart/form-data
* server_ip	127.0.0.1		否	默认全部，否则传指定的服务器IP
* group	分组名称		否	 分组名称，默认填全部
* domain	com		否	 要搜索的域名关键词，可以为空
* status	1		否	 默认传-1，表示全部
* page	1		(必填)
* limit	10		(必填)
*/
export function websiteList(data) {
  return request({
    url: '/website/list?ser_id=' + data.ser_id + '&group=' + data.group + '&domain=' + data.domain + '&status=' + data.status + '&limit=' + data.limit + '&page=' + data.page + '&desc=' + data.desc,
    method: 'get'
  })
}

/*
* 接口名称：逐条新增（已存在则更新）站点
* server	127.0.0.1
* group	分组1,分组2,分组3
* qiye	企业名称
* qiyeStatus	1 是否开启jstitle，0表示关闭
* idxt	首页标题
* idxk	首页关键字
* idxd	首页描述
* innt	内页标题
* innk	内页关键词
* innd	内页描述
* cloneUrl	https://www.baidu.com
* cloneDeep	3 克隆深度，默认是3，一般填写不要超过5，否则会耗时很长
* domain	test.126.com
*/
export function websiteSaveone(data) {
  return request({
    url: '/website/saveone',
    method: 'post',
    data
  })
}
export function websiteSaveAll(data) {
  // url: '/website/all_in',
  return request({
    url: '/alone/all_in',
    method: 'post',
    data
  })
}
/*
* 接口名称：批量导入、更新站点
* file(必填) 	请选择上传文件	 站点存在时，更新部分字段；不存在时，新建站点，并等待建站
*/
export function websiteImport(data) {
  return request({
    url: '/website/import',
    method: 'post'
  })
}

/*
* 接口名称：删除站点，支持批量
* site_id	1,2,3,4(必填) 	 多个站点时，用逗号分隔要删除的站点ID；该操作不可恢复，谨慎操作
*/
export function websiteDelete(data) {
  return request({
    url: '/website/delete',
    method: 'post',
    data
  })
}

/*
* 接口名称：更新指定站点（不支持批量）
* site_id	1		(必填) 站点ID
* group	分组名称		(必填) 所有数据都是必填
* qiye	企业名称		(必填) 所有数据都是必填
* jstitle	1		(必填) 是否开启jstitle，0表示关闭
* idxt	首页标题		(必填) 所有数据都是必填
* idxk	首页关键字		(必填) 所有数据都是必填
* idxd	首页描述		(必填) 所有数据都是必填
* innt	内页标题		(必填) 所有数据都是必填
* innk	内页关键词		(必填) 所有数据都是必填
* innd	内页描述		(必填) 所有数据都是必填
*/
export function websiteUpdate(data) {
  return request({
    url: '/website/update',
    method: 'post',
    data
  })
}

/*
* 接口名称：开始克隆
* siteid	1		(必填) 站点ID
*/
export function cloneStart(data) {
  return request({
    url: '/website/clone/start?siteid=' + data.siteid + '&fanti=' + data.fanti,
    method: 'get'
  })
}
/*
* 接口名称：取消克隆（取消克隆并不会删除已经克隆的站点）
* siteid	1		(必填) 站点ID
*/
export function cloneStop(data) {
  return request({
    url: '/website/clone/stop?siteid=' + data.siteid,
    method: 'get'
  })
}
/*
* 接口名称：状态查询
* siteid	1		(必填) 站点ID
*/
export function cloneStatus(data) {
  return request({
    url: '/website/clone/status?siteid=' + data.siteid,
    method: 'get'
  })
}

/*
* get
* Query 请求参数
* 接口名称：404读文件
* type	404
* domain	www.236tv.com 域名
* path 要修改的url
*/
export function filesGet(query, data) {
  return request({
    // url: '/website/fileditor?type=' + query.type + '&domain=' + query.domain + '&path=' + query.path,
    url: '/alone/fileditor?type=' + query.type + '&domain=' + query.domain + '&path=' + query.path,
    method: 'get',
    data
  })
}
/*
* post
* 接口名称：404写文件
* Query 请求参数
* type	404
* domain	www.236tv.com 域名
* path 要修改的url
*/
export function filesPost(data) {
  return request({
    url: '/alone/fileditor',
    // url: '/website/fileditor',
    method: 'post',
    data
  })
}

export function newFileGet(query, data) {
  return request({
    url: '/alone/fileditor?type=' + query.type + '&domain=' + query.domain + '&path=' + query.path,
    method: 'post',
    data
  })
}

export function webSiteFilesPost(data) {
  return request({
    url: '/website/fileditor',
    method: 'post',
    data
  })
}
/*
* post
* 接口名称：申请https证书进度
* siteid
*/
export function sslSstatusProcess(query) {
  return request({
    url: 'website/ssl/process?taskid=' + query.taskid,
    method: 'get'
  })
}
/*
* post
* 接口名称：申请https证书状态
* siteid
*/
export function sslSstatusApply(query, data) {
  return request({
    url: '/website/ssl/status?siteid=' + query.siteid,
    method: 'get'
  })
}
/*
* post
* 接口名称：开启https证书
* siteid
*/
export function sslOpenApply(data) {
  return request({
    // url: '/website/ssl?siteid=' + query.siteid + '&dns_id=' + query.dns_id + '&ssl_status=' + query.ssl_status,
    url: '/website/ssl',
    method: 'post',
    data
  })
}
/*
* post
* 接口名称：证书申请日志回显
* siteid
*/
export function sslLogShow(query, data) {
  return request({
    url: '/website/ssl/process?siteid=' + query.siteid + '&ssl_status=' + query.ssl_status,
    method: 'post'
  })
}
/*
* post
* 接口名称：关闭https证书
* siteid
*/
export function sslCloseApply(query, data) {
  return request({
    url: '/website/close_ssl?siteid=' + query.siteid,
    method: 'get'
  })
}

/*
* post
* 接口名称：修改dns（克隆专用）
* siteid
*/
export function updateDns(data) {
  return request({
    url: '/website/update_dns',
    method: 'post',
    data
  })
}
export function websiteConfig(data) {
  return request({
    url: '/website/config',
    method: 'post',
    data
  })
}

export function changeLanguage(data) {
  return request({
    url: '/server/changelanguage',
    method: 'post',
    data
  })
}
export function changeDomain(data) {
  return request({
    url: '/website/change_domain',
    method: 'post',
    data
  })
}
export function readSoftConfig1(query) {
  return request({
    url: '/server/read_soft_config?server_id' + query.server_id + '&name=' + query.name + '&domain=' + query.domain,
    method: 'get'
  })
}

export function writeSoftConfig(data) {
  return request({
    url: '/server/write_soft_config',
    method: 'post',
    data
  })
}

export function updateSiteStatus(data) {
  return request({
    url: '/alone/site_status',
    method: 'post',
    data
  })
}
//修改服务器的sider_config配置
export function updateSpiderConfig(data) {
  return request({
    url: '/server/spider_config',
    method: 'post',
    data
  })
}
