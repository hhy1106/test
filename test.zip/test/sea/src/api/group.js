import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
* 接口名称：分组列表
* 接口URL：GET127.0.0.1:5000/api/group/list?type=1&status=1&limit=1
* Content-Type：multipart/form-data
* type	1		否	 查看我的分组
* page	1		(必填)
* limit	10		(必填)
*/
export function groupList(data) {
  return request({
    url: '/group/list?token=' + getToken() + '&type=' + data.type + '&limit=' + data.limit + '&page=' + data.page,
    method: 'get'
  })
}

/*
* 添加分组
* type	1		是	 分组类型：1站点分组；2服务器分组
* name	测试分组		是	 1
*/
export function groupCreate(data) {
  return request({
    url: '/group/create?token=' + getToken(),
    method: 'post',
    data
  })
}

/*
* 删除分组（清空分组）
* groupid	3		是	 分组ID，传0表示清空所有空分组；大于0表示删除指定分组
*/
export function groupDelete(data) {
  return request({
    url: '/group/delete?token=' + getToken(),
    method: 'post',
    data
  })
}

/*
* 接口名称：更新分组元素数量
* name	测试分组		是	 分组ID，传0表示清空所有空分组；大于0表示删除指定分组
* action	1		是	值只能是1或者-1,1表示增加了元素，-1表示移除了元素
*/
export function groupUpdate(data) {
  return request({
    url: '/group/update?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：添加分组元素数量
* name	测试分组		是	 分组ID，传0表示清空所有空分组；大于0表示删除指定分组
* siteid	1		
*/
export function groupAddItem(data) {
  return request({
    url: '/group/addItem?token=' + getToken(),
    method: 'post',
    data
  })
}
