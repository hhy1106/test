import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
* 接口名称：服务器列表
* keyword 	按名称关键字搜索服务器
*/
export function severList(data) {
  return request({
    url: '/server/list?page=' + data.page + '&limit=' + data.limit + '&keyword=' + data.keywordsInput + '&deploy=' + data.deploy,
    method: 'get',
    data
  })
}
/*
* 接口名称：添加服务器
* 参数名	示例值	参数类型	是否必填
* name	测试服务器名称		是
* desc	154.94.148.193-254 154.94.182.193-254 154.94.186.193-254 154.94.188.193-254		是
* host	154.94.148.193		是
* port	8154		是
* sshuser	root		是
* sshpasswd	5a1Fazu8AA54nxGko9WTAnF6hhy
*/
export function severCreate(data) {
  return request({
    url: '/server/create',
    method: 'post',
    data
  })
}
/*
* 接口名称：删除服务器
* serverid	1		是	 指定服务器ID
*/
export function severDelete(data) {
  return request({
    url: '/server/delete',
    method: 'post',
    data
  })
}
/*
* 接口名称：编辑服务器
* serverid	1		是	指定更新的服务器ID
* name	测试服务器名称		是
* desc	wqeqweqwe		是
* port	8154		是
* sshuser	root		是
* sshpasswd	5a1Fazu8AA54nxGko9WTAnF6hhy		是
*/
export function severUpdate(data) {
  return request({
    url: '/server/update',
    method: 'post',
    data
  })
}
/*
* 接口名称：配置服务器
* serverid	1		是	指定更新的服务器ID
* config	{ "firewall": { "status": "on", "warning": 5, "access_rate": 20, "block_area": true }, "spider": { "baidu": "on", "baidu_render": "off", "google": "on", } }		是
*/
export function severConfig(id, data) {
  return request({
    url: '/server/config',
    method: 'post',
    data
  })
}
/*
* 接口名称：安装服任务查询
* serverid	1		是	指定更新的服务器ID
*/
export function severInstallerStatus(data) {
  return request({
    url: '/server/install_status',
    method: 'post',
    data
  })
}
/*
* 接口名称：安装服务器环境
* serverid	1		是	指定更新的服务器ID
*/
export function severInstaller(data) {
  return request({
    url: '/server/installer',
    method: 'post',
    data
  })
}
/*
* 接口名称：杀死指定任务
* serverid	1		是	指定更新的服务器ID
*/
export function severKiller(data) {
  return request({
    url: '/server/killer',
    method: 'post',
    data
  })
}
/*
* 接口名称：客户端使用】版本升级
* version
*/
export function upgradeStart(data) {
  return request({
    url: '/server/upgrade?version=' + data.version,
    method: 'get'
  })
}
/*
* 接口名称：升级管理列表
* version
*/
export function upgradeList(data) {
  return request({
    url: '/server/upgrade/list',
    method: 'get'
  })
}
/*
* 接口名称：添加版本升级
* Body 请求参数
参数名	参数值	是否必填	参数类型	描述说明
file 要升级的安装包
version 20221021 升级的版本号
description 升级的说明信息
force 是否必须升级：1是；0不需要强制升级（强制升级可以用于客户机回退到指定版本）
biz clone 指定业务的客户机升级：all全部；clone克隆；tinyproxy多IP代理；adslproxy拨号代理
start 1234567890 时间戳，10位；升级开始时间，大于该时间，会推送给客户机
*/
export function upgradeCreate(data) {
  return request({
    url: '/server/upgrade/create',
    method: 'POST',
    data
  })
}
/*
* 接口名称：删除指定的升级推送
* verid 要删除的版本ID
*/
export function upgradeDelete(data) {
  return request({
    url: '/server/upgrade/delete',
    method: 'POST',
    data
  })
}
/*
* 接口名称：获取客户机已部署的程序和软件
* sid 服务器ID
*/
export function pluginGet(data) {
  return request({
    url: '/server/controll_status?server_id=' + data.server_id + '&name=' + data.name,
    // url: '/server/controll_status?sid=' + data.sid + '&name=' + data.name,
    method: 'get',
    data
  })
}
/*
* 接口名称：启动、停止、重载指定的服务
sid	 服务器ID
name	要管理的软件名称：nginx/redis/adminapi/admintask/proxy/kelong
action	 动作名称：启动start；停止stop；重载reload
*/
export function pluginControll(data) {
  return request({
    url: '/server/controll',
    method: 'POST',
    data
  })
}
export function serverControll(data) {
  return request({
    url: '/server/controll',
    method: 'post',
    data
  })
}
export function writeServer(data) {
  return request({
    url: '/server/write_soft_config?server_id=69&name=fluent-bit',
    method: 'post',
    data
  })
}
export function readServer(query) {
  return request({
    url: '/server/read_soft_config?server_id=69&name=fluent-bit',
    method: 'get',
    params: query
  })
}
/*
* 接口名称：[实时]获取服务器的负载
* sid	 服务器ID；宝塔面板的：:8888/system?action=GetNetWork
*/
export function systemLoadStatus(data) {
  console.log(data)
  return request({
    url: `/system/load?server_id=${data.server_id}`,
    method: 'get',
    data
  })
}
/*
* 接口名称：对接手动升级服务器版本
* sid	 服务器ID；宝塔面板的：:8888/system?action=GetNetWork
*/
export function manualUpgrade(data) {
  return request({
    url: '/server/update_version',
    method: 'post',
    data
  })
}

export function clientUpgrade(data) {
  return request({
    url: '/client/upgrade?version=' + data.version + '&access_token=' + data.access_token,
    method: 'get',
    data
  })
}

export function updateVersion(data) {
  return request({
    url: '/server/update_version',
    method: 'post',
    data
  })
}
export function clientSystemLoad(data) {
  return request({
    url: '/system/load?server_id=4',
    method: 'get',
    data
  })
}

// export function systemLoadStatus(query) {
//   return request({
//     url: '/system/load',
//     method: 'get',
//     params: query
//   })
// }



