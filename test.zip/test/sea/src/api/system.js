import request from '@/utils/request'
import { getToken } from '@/utils/auth'

/*
* 接口名称：防火墙列表
* sid	 服务器IP对应的
*/
export function firewallList(data) {
  return request({
    url: '/system/firewall_list?sid='+ data.sid + '&token=' + getToken(),
    method: 'get'
  })
}
/*
* 接口名称：删除屏蔽的IP
* sid	 服务器IP对应的id
* ip	IP
*/
export function firewallDelIp(data) {
  return request({
    url: '/system/firewall_delip?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：添加屏蔽的IP
*/
export function firewallAddIp(data) {
  return request({
    url: '/system/firewall_addip?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：放行端口
* sid	 服务器IP对应的id
* port	 端口号
* type	 tcp、udp
*/
export function firewallAddport(data) {
  return request({
    url: '/system/firewall_addport?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：删除放行端口
* sid	 服务器IP对应的id
* port	 端口号
* type	 tcp、udp
*/
export function firewallDelport(data) {
  return request({
    url: '/system/firewall_delport?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：增加防火墙
*/
export function firewallCreate(data) {
  return request({
    url: '/system/firewall/create?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：开关防火墙
* sid	 服务器IP对应的id
* command  start stop
*/
export function firewallSwitch(data) {
  return request({
    url: '/system/control_firewall?sid='+ data.sid + '&command='+ data.command + '&token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：重启防火墙
* sid	 服务器IP对应的id
*/
export function firewallReload(data) {
  return request({
    url: '/system/firewall_reload?sid='+ data.sid + '&token=' + getToken(),
    method: 'get',
    data
  })
}
/*
* 接口名称：ssh列表
*/
export function sshList(data) {
  return request({
    url: '/system/ssh/list?token=' + getToken(),
    method: 'get'
  })
}
/*
* 接口名称：开关ssh
*/
export function sshSwitch(data) {
  return request({
    url: '/system/ssh/switch?token=' + getToken(),
    method: 'post',
    data
  })
}

/*
* 接口名称：克隆负载
*/
export function cloneLoad(data) {
  return request({
    url: '/system/clone_load?server_id=' + data.server_id,
    method: 'get'
  })
}
