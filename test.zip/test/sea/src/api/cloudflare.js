import request from '@/utils/request'
import { getToken } from '@/utils/auth'


/*
* 接口名称：获取服务商账号
*/
export function cfUserList(data) {
  return request({
    url: '/dnsmanage/user_list',
    method: 'get',
    data
  })
}
/*
* 接口名称：dns添加服务商账号
*/
export function cfUserAdd(data) {
  return request({
    url: '/dnsmanage/add_user?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：dns删除服务商账号
*/
export function cfUserDelete(data) {
  return request({
    url: '/dnsmanage/del_user?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：更新服务商账号
*/
export function cfUserUpdate(data) {
  return request({
    url: '/dnsmanage/update_user?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：搜索服务商账号
* alias	 谷歌云测试2
*/
export function cfUserSearch(data) {
  return request({
    url: '/domain/search_user?token=' + getToken() + '&alias=' + data.alias,
    method: 'post',
    data
  })
}
/*
* 接口名称：同步云端域名列表到本地数据库【会删除本地存在，云端不存在的域名】
* dnsUserId	 1
*/
export function cfDomainSync(data) {
  return request({
    url: '/dnsmanage/domain_list?dnsUserId=' + data.dnsUserId,
    method: 'get',
    data
  })
}
/*
* 接口名称：dns删除本地域名信息
* dnsUserId	 1 body
*/
export function cfDomainLocalDel(data) {
  return request({
    url: '/dnsmanage/del_domain_list?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：搜索域名
* dnsUserId	 1 Query
* domain	 1 Query
*/
export function cfDomainSearch(data) {
  return request({
    url: '/dnsmanage/search_domain?token=' + getToken() + '&dnsUserId=' + data.dnsUserId + '&domain=' + data.domain,
    method: 'post',
    data
  })
}
/*
* 接口名称：同步云端域名记录列表到本地
* domainIds	 1 Query
* domains	 1 Query
*/
export function sycnCloudDomain(data) {
  return request({
    url: '/dnsmanage/record_list?token=' + getToken() + '&domainIds=' + data.domainIds + '&domains=' + data.domains,
    method: 'post',
    data
  })
}
/*
* 接口名称：获取本地域名记录列表
* domainIds	 1 Query
* domains	 1 Query
*/
export function localDomainList(data) {
  return request({
    url: '/dnsmanage/local_record_list?token=' + getToken() + '&domainIds=' + data.domainIds + '&domains=' + data.domains,
    method: 'post',
    data
  })
}

/*
* 接口名称：批量添加dns记录
{
  "dnsUserId": 398, //服务商账号id
  "domainids": "",

  "domains": "seo-98.com",
  "config": [
    {
      "type": "CNAME", //记录类型
      "name": "_18F349D3A4C985DD19934E062F69B11A.seo-98.com", //记录主机
      "value": "C1F6037A08FBE9C82623491EBA2C5D4A.B09F36BC73C63E01FD9D0EB423333F3E.0da5c97f0b8d1e7.comodoca.com", //记录值
      "ttl": "60" //记录缓存
    }
  ] //配置
}
*/
export function batchAddRecord(data) {
  return request({
    url: '/dnsmanage/batch_add_record?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：批量删除记录
  "dnsUserId": 7, //dns账号记录ID
  "domainids": "",

  "domains": "seo-98.com", //域名（域名记录ID优先）
  "type": "A", //记录类型
  "name": "", //主机记录
  "value": "", //值
  "contain": true //值是否模糊
*/
export function batchDelRecord(data) {
  return request({
    url: '/dnsmanage/batch_del_record?token=' + getToken(),
    method: 'post',
    data
  })
}
/*
* 接口名称：dns删除本地解析记录
Body 请求参数
  {
    "dnsUserId": 3, //服务商账号id
    "domainIds": "7" //域名记录ID，逗号隔开
  }
*/
export function localDelRecordList(data) {
  return request({
    url: '/dnsmanage/del_record_list?token=' + getToken(),
    method: 'post',
    data
  })
}
