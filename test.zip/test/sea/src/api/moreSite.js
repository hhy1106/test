import request from '@/utils/request'

export function postMemberConfig(data) {
  return request({
    url: '/yboss/member/config',
    method: 'post',
    data,
    service:'fanzhanqun'
  })
}
export function getMemberConfig(query) {
  return request({
    url: '/yboss/member/config',
    method: 'get',
    params:query,
    service:'fanzhanqun'
  })
}
//编辑站点TKD
export function postWebsitTkd(data) {
  return request({
    url: '/yboss/website/tkd',
    method: 'post',
    data,
    service:'fanzhanqun'
  })
}
//保存站点修改
export function postWebsiteSave(data) {
  return request({
    url: '/yboss/website/save',
    method: 'post',
    data,
    service:'fanzhanqun'
  })
}
//模板列表
export function getTemplateList(query) {
  return request({
    url: '/yboss/template/index',
    method: 'get',
    params:query,
    service:'fanzhanqun'
  })
}
//查询站点信息
export function getSiteInfo(query) {
  return request({
    url: '/yboss/website/info',
    method: 'get',
    params:query,
    service:'fanzhanqun'
  })
}

//上传词库&友链
export function updateKeyAndFl(data) {
  return request({
    url: '/yboss/website/data',
    method: 'post',
    data,
    service:'fanzhanqun'
  })
}
//清落地缓存
export function updatePurge(data) {
  return request({
    url: '/yboss/website/purge',
    method: 'post',
    data,
    service:'fanzhanqun'
  })
}
//清除反向代理的缓存
export function clearPurge(query) {
  return request({
    url: '/server/purge',
    method: 'get',
    params:query,
  })
}


export function batchPostFile(query, data) {
  return request({
    url: '/yboss/data/file?type=' + query.type + '&domain=' + query.domain + '&zone=' + query.zone+ '&site_id=' + query.site_id,
    method: 'post',
    data,
    service:'fanzhanqun'
  })
}
