import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/* Layout */
import Layout from '@/layout'

export const constantRoutes = [
  {
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path(.*)',
        component: () => import('@/views/redirect/index')
      }
    ]
  },
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/register',
    component: () => import('@/views/register/index'),
    hidden: true
  },
  {
    path: '/auth-redirect',
    component: () => import('@/views/login/auth-redirect'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/dashboard/index'),
        name: 'Dashboard',
        meta: { title: '狂侠站群系统', icon: 'el-icon-house', affix: true }
      }
      // {
      //   path: 'gauge',
      //   component: ()=>import('../../public/gauge.html'),
      //   name:'Gauge',
      //   meta:{ title:'rl',icon: '',affix: true}
      // }
    ]
  },
  {
    path: '/seo/index',
    component: () => import('@/views/v2/index'),
    hidden: true
  },
  {
    path: '/server/index',
    component: () => import('@/views/v2/server/index'),
    hidden: true
  },
  {
    path: '/tools/guide',
    component: () => import('@/views/v2/tools/guide'),
    hidden: true
  },
  {
    path: '/monitor',
    component: Layout,
    redirect: '/monitor/index',
    meta: { title: '域名监控', icon: 'el-icon-video-camera', noCache: true },
    children: [
      {
        path: 'index',
        component: () => import('@/views/monitor/index'),
        name: 'Monitor',
        meta: { title: '监测结果', icon: 'el-icon-bell', noCache: true }
      }, {
        path: 'list',
        component: () => import('@/views/monitor/list'),
        name: 'monitorList',
        meta: { title: '域名列表', icon: 'el-icon-tickets', noCache: true }
      }
    ]
  }
]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [

  {
    path: '/error',
    component: Layout,
    redirect: 'noRedirect',
    name: 'ErrorPages',
    meta: {
      title: 'Error Pages',
      icon: '404'
    },
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/error-log/index'),
    hidden: true
  },
  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})
const router = createRouter()

router.beforeEach((to, from, next) => {
  /* 路由发生变化修改页面title */
  if (to.meta.title) {
    document.title = to.meta.title;
  }
  next();
});

export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
