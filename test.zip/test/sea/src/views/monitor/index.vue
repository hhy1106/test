<template>
  <div class="app-container">

    <div class="btn-group">
      <label>结果过滤：</label>
      <el-select
        v-model="resultType"
        placeholder="请选择"
        style="width: 150px;"
        @change="resultChange($event)"
      >
        <el-option label="不限" value="0" />
        <el-option label="检测失败" value="1" />
        <el-option label="检测正常" value="2" />
      </el-select>
      <el-button type="success" :loading="loadingBtn" style="margin-left: 0;" @click="getList"><i v-if="!loadingBtn" class="el-icon-search" />开始查询</el-button>
    </div>

    <!-- 展示列表 -->
    <el-table
      ref="multipleTable"
      v-loading="listLoading"
      :data="dataList"
      stripe
      border
      fit
      highlight-current-row
      style="width: 100%;"
    >
      <el-table-column
        label="序号"
        type="index"
        width="50"
      />

      <el-table-column label="检测域名">
        <template slot-scope="{row}">
          <span @click="handleCopy(row.domain,$event)">{{ row.domain }}</span>
          <i class="el-icon-link" style="margin-left: 5px;cursor: pointer;" @click="openUrl(row.domain)" />
        </template>
      </el-table-column>

      <el-table-column label="检测结果">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.check_result == '网站首页'" type=""><i class="el-icon-success" />正常</el-tag>
          <el-tag v-else type="danger"><i class="el-icon-error" />异常</el-tag>
        </template>
      </el-table-column>

      <el-table-column label="检测时间">
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span style="margin-left: 10px">{{ scope.row.check_time | parseTime }}</span>
        </template>
      </el-table-column>

      <el-table-column label="检测到内嵌的首页标题" show-overflow-tooltip>
        <template slot-scope="scope">
          <span v-if="scope.row.check_result == '网站首页'" style="color: blue;">{{ scope.row.check_result }}</span>
          <span v-else style="color: red;">{{ scope.row.check_result }}</span>
        </template>
      </el-table-column>

    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="page" :limit.sync="limit" @pagination="getList" />

  </div>
</template>

<script>
import { Loading } from 'element-ui'
import { formatTime } from '@/utils/index'
import Pagination from '@/components/Pagination'
import {
  getDomainShow
} from '@/api/monitor'
import clip from '@/utils/clipboard'

export default {
  components: {
    Pagination
  },
  filters: {
    parseTime(value) {
      return formatTime(value, '{y}-{m}-{d}')
    }
  },
  data() {
    return {
      total: 0,
      page: 1,
      limit: 10,
      resultType: '1', // 0 全部 1失败 2成功
      dataList: [],
      listLoading: false,
      loadingBtn: false,
      optionsType: [{
        value: '1',
        label: '网站分组'
      }, {
        value: '2',
        label: '服务器分组'
      }]
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() { // 查
      this.listLoading = true
      this.loadingBtn = true
      const parmers = {}
      parmers.page = this.page
      parmers.limit = this.limit
      parmers.type = this.resultType
      getDomainShow(parmers).then(response => {
        if (response.code == '200') {
          this.dataList = response.result
          this.total = response.count
        }
        setTimeout(() => {
          this.listLoading = false
          this.loadingBtn = false
        }, 1.5 * 1000)
      }).catch(err => {
        console.log(err)
        setTimeout(() => {
          this.listLoading = false
          this.loadingBtn = false
        }, 1.5 * 1000)
      })
    },
    loadingClose() {
      const loadingInstance = Loading.service()
      this.$nextTick(() => {
        this.loading = false
        loadingInstance.close()
      })
    },
    handleCopy(text, event) {
      clip(text, event)
    },
    resultChange(data) {
      this.page = 1
    },
    openUrl(path) {
      path.indexOf('http://') < 0 ? path = `http://${path}` : path = path
      window.open(path)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
</style>
