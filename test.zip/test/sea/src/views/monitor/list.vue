<template>
  <div class="app-container">
    <div class="btn-group">
      <!-- <label>查找服务器：</label> -->
      <el-input v-model="domainInput" placeholder="请输入域名进行查询" style="width: 240px;" />
      <el-button
        @click="getList()"
        type="success"
        :loading="btnLoading">
        <i class="el-icon-search" v-if="!btnLoading"></i>开始查询
      </el-button>
      <el-button
        type="primary"
        @click="dialogCreate = true"
        style="margin-left: auto;">
        <i class="el-icon-plus"></i>添加域名
      </el-button>
    </div>

    <!-- 展示列表 -->
    <el-table v-loading="listLoading" ref="multipleTable" :data="dataList" stripe border fit highlight-current-row
      style="width: 100%;">
      </el-table-column>

      <el-table-column
        label="序号"
        type="index"
        width="50">
      </el-table-column>

      <el-table-column label="检测域名">
        <template slot-scope="{row}">
          <el-tag type="info">{{ row.domain }}</el-tag>
        </template>
      </el-table-column>

    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="page" :limit.sync="limit" @pagination="getList" />

    <!-- 添加/编辑服务器 -->
    <el-drawer
      class="pl-drawer"
      :wrapperClosable="false"
      title="添加域名"
      :visible.sync="dialogCreate"
      :direction="direction">
        <div class="domain-box">
          <p>请输入域名</p>
          <el-input
            wrap="off"
            v-model="newDomains"
            type="textarea"
            rows="16"
            placeholder="支持批量,一行一个并用逗号隔开
例如:
domain1.com,
domain2.com,
domain3.com"
            style="width: 100%;">
          </el-input>

          <el-button
            type="primary"
            :loading="btnLoading"
            style="margin: 20px 0 0 auto;width: 100%;"
            @click="submitNewDomains">
            <i class="el-icon-success"></i>确认提交
          </el-button>

        </div>
    </el-drawer>
  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import { parseTime, formatTime } from '@/utils/index'
  import Pagination from '@/components/Pagination'
  import {
    getDomainList,
    getDomainResult,
    getDomainShow,
    domainInsert
  } from '@/api/monitor'
  import clip from '@/utils/clipboard'

  export default {
    components: {
      Pagination
    },
    filters: {
      parseTime(value) {
        return formatTime(value, '{y}-{m}-{d}')
      }
    },
    data() {
      return {
        total: 0,
        page: 1,
        limit: 10,
        domainInput: '',
        newDomains: '',
        dataList: [],
        direction: 'ltr',
        dialogCreate: false,
        listLoading: false,
        btnLoading: false,
        optionsType: [{
          value: '1',
          label: '网站分组'
        }, {
          value: '2',
          label: '服务器分组'
        }]
      }
    },
    created() {
      this.getList()
    },
    methods: {
      getList() { // 查
        this.listLoading = true
        let parmers = {}
        parmers.page = this.page
        parmers.limit = this.limit
        parmers.domain = this.domainInput
        getDomainList(parmers).then(response => {
          if(response.code == '200') {
            this.dataList = response.result
            this.total = response.count
          }
          setTimeout(() => {
            this.listLoading = false
          }, 1.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.listLoading = false
          }, 1.5 * 1000)
        })
      },
      removeEmpty(arr){
        for(var i = 0; i < arr.length; i++) {
         if(arr[i] == "" || typeof(arr[i]) == "undefined") {
            arr.splice(i,1);
            i = i - 1; // i - 1 ,因为空元素在数组下标 2 位置，删除空之后，后面的元素要向前补位
          }
         }
         return arr;
      },
      getSetArr(arr) {
        return [...new Set(arr)]
      },
      submitNewDomains() {
        let newArrDomains = []
        this.newDomains = this.newDomains.replace('，',',')
        this.newDomains = this.newDomains.replace(/[\r\n]/g, "")
        if(!this.newDomains) {
          return this.$message.info('域名不能为空');
        }
        newArrDomains = this.newDomains.split(',')
        let unique = (arr) => {
          let newArr = [];
          for(let i=0;i<arr.length;i++){
            if(newArr.indexOf(arr[i]) == -1){
              newArr.push(arr[i])
            }
          }
          return newArr;
        }
        newArrDomains = this.removeEmpty(newArrDomains)
        newArrDomains = this.getSetArr(newArrDomains)
        this.btnLoading = true
        domainInsert(newArrDomains).then(response => {
          if(response.code == '200') {
            this.$alert(response.msg, '成功提示', {
              confirmButtonText: '确认'
            })
            this.newDomains = ''
            this.dialogCreate = false
            this.getList()
          } else {
            this.$alert(response.msg, '失败提示', {
              confirmButtonText: '确认'
            })
          }
          setTimeout(() => {
            this.btnLoading = false
          }, 1.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.btnLoading = false
          }, 1.5 * 1000)
        })
      },
      loadingClose() {
        const loadingInstance = Loading.service()
        this.$nextTick(() => {
          this.loading = false
          loadingInstance.close()
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
.domain-box {
  padding: 20px;
  lable {
    display: block;
    margin-bottom: 10px;
  }
}
</style>
