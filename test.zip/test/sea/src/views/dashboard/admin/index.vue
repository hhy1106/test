<template>
  <div class="page-home">
    <div class="btn-box">
      <router-link to="/seo/index" class="btn-bg">
        <label>SEO工作台</label>
      </router-link>
      <router-link to="/server/index" class="btn-bg">
        <label>系统设置</label>
      </router-link>
      <router-link to="/tools/guide" class="btn-guide" target="_blank">
        <label><i class="el-icon-info"></i>系统简易使用说明</label>
      </router-link>
    </div>
  </div>
</template>

<style lang="scss">
  .page-home {
    width: 100%;
    height: 100vh;
    position: relative;
    background: #000 url('../../../assets/bg-seo.jpg');
    background-size: cover;
    .btn-box {
      width: 400px;
      height: 400px;
      position: absolute;
      top: 50%;
      left: 50%;
      margin: -300px 0 0 -200px;
      .btn-guide {
        color: #f90;
        cursor: pointer;
        display: block;
        text-align: center;
        height: 40px;
        line-height: 40px;
        label {
          cursor: pointer;
          display: block;
          height: 40px;
          line-height: 40px;
        }
        &:hover {
          text-decoration: underline;
          color: #fff;
        }
      }
      .btn-bg {
        display: block;
        width: 360px;
        height: 150px;
        line-height: 150px;
        text-align: center;
        padding: 0;
        margin: 40px auto;
        background: url('../../../assets/bg-btn.png') no-repeat;
        background-size: contain;
        font-size: 50px;
        font-weight: 700;
        color: chartreuse;
        position: relative;
        cursor: pointer;
        label {
          cursor: pointer;
          display: block;
          font-family: cursive;
          background: linear-gradient(to right, #f3ff00, #9d85af);
          -webkit-background-clip: text;
          color: transparent;
          &:hover {
            background: linear-gradient(to right, #9d85af, #f3ff00);
            -webkit-background-clip: text;
            color: transparent;
          }
        }
      i {
        margin-left: 10px;
      }
      }
    }
  }
</style>
