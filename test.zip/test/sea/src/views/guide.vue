<template>
  <div class="dashboard-editor-container app-container page-index">
    <el-tabs type="border-card">
      <el-tab-pane label="建站流程">
        <el-alert
          title="特别说明：需要纯净的centos7.6左右的系统版本。使用HTTPS必须保证域名已经解析到该服务器。"
          type="warning"
          effect="dark">
        </el-alert><br ><br>

        <el-tag
          type="success"
          effect="dark">后台使用流程:
        </el-tag><br><br>

        <el-timeline>
         <!-- <el-timeline-item timestamp="第1步" placement="top">
            <el-card>
              <h4>账号注册</h4>
              <p>打开后台注册个人账号</p>
            </el-card>
          </el-timeline-item> -->
          <el-timeline-item timestamp="第1步" placement="top">
            <el-card>
              <h4>添加服务器</h4>
              <p>找到服务器管理-服务器列表-添加服务器</p>
            </el-card>
          </el-timeline-item>
          <el-timeline-item timestamp="第2步" placement="top">
            <el-card>
              <h4>系统安装/环境部署</h4>
              <p>添加完成后，在服务器列表，对应服务器的行最后一列，下拉菜单：系统安装，耐心等待系统环境自动安装部署成功</p>
            </el-card>
          </el-timeline-item>
          <el-timeline-item timestamp="第3步" placement="top">
            <el-card>
              <h4>添加站点</h4>
              <p>到网站管理，批量添加站点</p>
            </el-card>
          </el-timeline-item>
          <el-timeline-item timestamp="第4步" placement="top">
            <el-card>
              <h4>开始建站</h4>
              <p>添加完成后，点击对应站点的【开始建站】</p>
            </el-card>
          </el-timeline-item>
          <el-timeline-item timestamp="第5步" placement="top">
            <el-card>
              <h4>开启HTTPS</h4>
              <p>可根据实际情况自行选择开启HTTPS与否</p>
            </el-card>
          </el-timeline-item>
        </el-timeline>

        <!-- <panel-group @handleSetLineChartData="handleSetLineChartData" />

        <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
          <line-chart :chart-data="lineChartData" />
        </el-row>

        <el-row :gutter="32">

          <el-col :xs="24" :sm="24" :lg="12">
            <div class="chart-wrapper">
              <pie-chart />
            </div>
          </el-col>
          <el-col :xs="24" :sm="24" :lg="12">
            <div class="chart-wrapper">
              <bar-chart />
            </div>
          </el-col>
        </el-row> -->
      </el-tab-pane>
      <el-tab-pane label="标签文档">
        {页面网址}：获取当前页面网址<br><br>
        {创建时间}：获取页面的创建时间<br><br>
        {现在时间}：获取最新时间<br><br>
        {网页标题}：获取当前页面的标题<br><br>
        {网页关键词}：获取当前页面的关键字<br><br>
        {网页描述}：获取当前页面的描述<br><br><br>
        {句子1}：如果有配置句子库数据，则可以使用<br><br>
        {句子2}：如果有配置句子库数据，则可以使用<br><br>
        {句子3}：如果有配置句子库数据，则可以使用<br><br>
        {句子4}：如果有配置句子库数据，则可以使用<br><br>
        {句子5}：如果有配置句子库数据，则可以使用<br><br>
      </el-tab-pane>
    </el-tabs>



  </div>
</template>

<script>
import PanelGroup from './components/PanelGroup'
import LineChart from './components/LineChart'
import PieChart from './components/PieChart'
import BarChart from './components/BarChart'

const lineChartData = {
  newVisitis: {
    expectedData: [100, 120, 161, 134, 105, 160, 165],
    actualData: [120, 82, 91, 154, 162, 140, 145]
  },
  messages: {
    expectedData: [200, 192, 120, 144, 160, 130, 140],
    actualData: [180, 160, 151, 106, 145, 150, 130]
  },
  purchases: {
    expectedData: [80, 100, 121, 104, 105, 90, 100],
    actualData: [120, 90, 100, 138, 142, 130, 130]
  },
  shoppings: {
    expectedData: [130, 140, 141, 142, 145, 150, 160],
    actualData: [120, 82, 91, 154, 162, 140, 130]
  }
}

export default {
  name: 'DashboardAdmin',
  components: {
    PanelGroup,
    LineChart,
    PieChart,
    BarChart
  },
  data() {
    return {
      lineChartData: lineChartData.newVisitis
    }
  },
  methods: {
    handleSetLineChartData(type) {
      this.lineChartData = lineChartData[type]
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}

@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}
</style>
