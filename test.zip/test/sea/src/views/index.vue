<template>
  <div class="wrap-new">
    <div class="kx-main">
      <div class="kx-header">
        <h1>
          <label>狂侠站群系统</label>
          <div v-if="titleServer" class="title-box">
            <el-tooltip class="item" effect="light" placement="left">
              <div slot="content">
                计划任务：{{ unplanNum }} 进行中：{{ cloneLoadNum }}
              </div>
              <span style="color: #fff"
                >{{ titleServer }} - {{ valueServer }}</span
              >
            </el-tooltip>
          </div>
          <span v-if="!valueServer" style="color: #ffffff">未选择服务器</span>
          <span class="right-btn" />
        </h1>
      </div>
      <div class="new-content">
        <servers-card
        @create="openCreateDialog"
          :show-all-opation="true"
          :clone-deploy="true"
          @selectVal="selectServerFromSon"
        />
        <div class="new-content-right">
          <ul class="big-menus">
            <li
              v-for="(item, index) in bigMenus"
              :key="index"
              :class="{ active: item.name === activeSys }"
              @click="menusChange(item.name)"
            >
              <i :class="`el-icon-${item.icon}`" />
              <label>{{ item.title }}</label>
            </li>
            <li
              style="margin-left: auto; cursor: pointer"
              @click="menusChange('home')"
            >
              <i class="el-icon-s-home" />
              <label>回到首页</label>
            </li>
            <li style="cursor: pointer" @click="logout">
              <i class="el-icon-switch-button" />
              <label>{{ $store.state.user.name }}</label>
            </li>
          </ul>
          <div class="serve-inter-box" id="container" style="display: initial">
            <div class="top-info">
              <div>
                <span style="margin-left: 30px; font-size: 14px;">
            克隆有新版本了，版本号：{{ versionData.version }}<span style="margin-left: 10px; color: #3a8ee6; cursor: pointer" @click="viewDetail">查看详情</span>
                </span>
                <span class="top-info-3">立即升级</span>
              </div>
              <el-button type="primary" round @click="updateServeDialog"
                >编辑服务器</el-button
              >
            </div>
            <div class="right" v-if="isShow">
              <!-- 0323添加的内容 -->
              <div
                v-show="showConTab == 'site'"
                style="overflow-y: auto; height: 100%"
              >
                <div class="status-box">
                  <p class="header-text">状态</p>
                  <div class="progress-box">
                    <div>
                      <p class="status-p">
                        负载状态<i class="el-icon-question icon-que"></i>
                      </p>
                      <div>
                        <el-progress
                          type="circle"
                          :percentage="2"
                        ></el-progress>
                      </div>
                      <p>运行流畅</p>
                    </div>
                    <div>
                      <p class="status-p">CPU使用率</p>
                      <div>
                        <el-progress
                          type="circle"
                          :percentage="6.1"
                        ></el-progress>
                      </div>
                      <p>2核心</p>
                    </div>
                    <div>
                      <p class="status-p">内存使用率</p>
                      <div>
                        <el-progress
                          type="circle"
                          :percentage="50"
                        ></el-progress>
                      </div>
                      <p>1822/3645（MB）</p>
                    </div>
                    <div>
                      <p class="status-p">内存占比</p>
                      <div>
                        <el-progress
                          type="circle"
                          :percentage="50"
                        ></el-progress>
                      </div>
                      <p>20/40（G）</p>
                    </div>
                  </div>
                </div>
                <div
                  class="col-xs-12 col-sm-12 col-md-6 pull-left pd0"
                  style="isplay: flex; flex-flow: wrap; padding: 10px"
                >
                  <div class="pr8">
                    <div class="bgw radius4">
                      <div class="title c6"></div>
                      <div
                        class="setting-con"
                        style="
                          padding: 0;
                          height: 442px;
                          margin-right: -4px;
                          overflow: hidden;
                        "
                      >
                        <div
                          class="container-fluid soft-man interface-box-column"
                        >
                          <div class="interface-left-container">
                            <section class="interface-left">
                              <div class="plr20 f15 header-text">接口</div>
                              <div
                                class="interface interface-left-box row"
                                data-listidx="0"
                              >
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="webssh"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAoCAMAAACPWYlDAAAAA3NCSVQICAjb4U/gAAAAn1BMVEX///8epTogpDggpTghpTUepTggozodozcepTogpDgepTggozoepTogpDgepTggozoepDceozggpjkepTogpDgepTgepDcepToepTggpTogpjkepTogpTogpjkgpDgepTogpTogpTogpDgepTogpDgepTogpDggpTogpjkgpTogpDggpjkepTogpTogpDggpjkgpTogpDggpjkgpTogpTp1LbKxAAAANXRSTlMAERERERERESIiIiIzMzMzMzNERERERFVVVWZmZnd3d3eIiJmZqqqqu7u7zMzMzN3d3e7u/0sSBnAAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAcdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3JrcyBDUzbovLKMAAABIklEQVQ4jb2VXXeCMAyGX3VT3NwXTueYsAHDgRXtaP7/b1vgYjIm0HjO9l6kvchzkjZpikCJtEJGIu2wOwcowsDwEgUFkfZ80wt4wIrIB1yiOfDcAagKuAEcQ3fA0JDDtjfCx2T0znY8DIniwei1FyCtK5sf9z2AvSpApZZSpgJyWCuXAtm/A8FcBnBLvIiAR1MWugto3tI05ULfCgAgIjJrCYAnTmtzKQBwtSE6uAIAeOMecySAx+cQABcJ9/CDfUqLA1HSWovfgM/5R23uJwrHU+1z1u7fBFx+zdvrDv8mwPcZdrmXwP5HSrH3vZ2FNQ3agJrW9VExtQBcfVQ+tgDszvAXgDongp7Y+t8bjsATW2eWKsoPJZZN7xROIvl1t8svAA+gNlsNiaAAAAAASUVORK5CYII="
                                      />
                                    </div>
                                    <div class="sname">
                                      宝塔SSH终端 1.0<span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="nginx"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAX8SURBVGhD7ZhbbBRVGIB3Zmd2Lrs7u9vddnujQGlFoC0qWEGxwQeEIBRNjIZoSNREE1+Mr2o0agzxzZgYH4yoGE1IjErBIvRBEZWLgNAWWizSC/Te7o2Z2dmZ2Rn/Mx2EXmCX3VNJzH5JM5f/zHb+M//dUaBAgQJ3FKd9xA7hInmmjK+jfK4yQ0knHGlTs0VYwa4A4SRoVym3zNtQ1BzcXPmmpz7QTJgOw9CMpJFMxxxwbi/FAmEf84dwkHSQWcQt9q71rAo+7V7m30A4SQaJzLShSl2xQ+KpyT3J3qvHtMlULy5FsCjgFOgybpG30d0QaIYd30q6qSBBEKQttjBN0zAkPSJ2RFuk9miL0nf1hJ7Qhm1xzuSlAMk5fWyVZ5V7hX+zB0yGKmIWgwlRtnhOzLSp65FUn9ge2Sudix1QBsSTYFpxW3zb5KQAQZMsU8E3gJlsdNcHtrjK+XqSJjlbnBXIJ9QhuVPqiO4D8zqYGpTbTc1QbHHW3J4CpMPpKuZq+OX+TWjX2UWeRidH+W1pTqSTekzpE0/A12iVz8cOquPJHvCOtC3OSNYKQDgs55f5NrjrAo9x1d6HwO5LZ9p5riD/SCe00eSlq79KnbEf5K5Ymx5Xh2zxLcmoALJzrkZ4GGz8Ca5WaKKLmIUoVNpirIB/aFok1Z+8mPhFPBv5Hh0z+UfGPMAtEdYVP171PlfrW08JdJggiX+fgV0aTJwY/zJxbPwLZUA66eSpgBNFoBvWzMRQ07LcnWiL/Tz8oTqidFN+VwWYoQ/J0HPwfJErzN3NVvIr1eHkOW0idcl68CZkVICt9j7obyp9ea5djx8d+yz20/AHyZ7EYeWy9Kd6WT5Nh9hqykdX3EwJLaL2jX/T9yqYSqs6LJ8jecoHuWONLbZA/4sSXKVSd6xNBee2b89JXjacGpTOQlLqM3UzZch6RL4YPzK5b+ANbTzVYxrm7ERlOkwwiYTSL540dUPRYupgCiKRLc2JvBRANjsto8J5EiLKRMvAa5C0JsA5TVtyHXBYh2Hq1rlhpvOtkbBEkWnAy0nno4cmW6+8DS+nwp3ZSmAEvwIAmJQSPz62O3Z49KO5PgJOsCmASgjhgeIdUAcVoWvwCjFy4Mo7ENN/tBbMEzi/AOFbF35RWB3ajnoBdAOybHz0696X1JFkl7ViHsBqQgRFsKFtVTv5WmE9/LJV1Omx1JWR3Rd3pCV90lqEGew+ALvvKX22ZhdT4a5Dlyh0Qo44M/rV3y9AsSZPrcIHfgUAqJPCZTtqdkOWLbduosgE9c3E/stvoZxh3cMEdgWugUrs8Pbqj0nWKaBrUzXk+LGxz9GftQAT86YAAirXrcFNla+DWbnRNSS3yQSUH5YQE/OqAML/SOkrQmPxM+DgVn88LXNjYN4VcDgJV2jLgnf55YFHHeSt281cyEsBq0Ilpn5j6nx2g4OcGpJbqLh5wU52oed+WH+9ByFhfZ69RV4KMGXuFZSfqSBogmXg5cBhvbZoGlBak3QJWxtqrnoPNUck7wyASblQc8SU8yjc5kzGfoDy0iVMJX8PyVKCtcs3gMIkemlXiF3iW1vyPFPO1RFOcs4dRf0B5acr2SrPapKjBCbML/U0BLZ57w0+OVNxQ4WGf0TuEs9Evs3U0GTbUjZ5VkJLCbv3H7WUR6Cl/A5LS4kSjzam/JXql/7Q49oQqudR60gwpBvZt70sL+ymfkTujrclfh//NPHb2CepAelUNknv9l5gaqxSyy/3b/Ss8G9m8IxV4ql+8bgILebUWEXpsRqdLMlpBy2nrXA3uNF8qM4abNXlMNhS1CG5Q+qM7pfgxVF7amrmPA+2ZmCPFlfbo8WtWY0WoS7SoY8WOyItqLG/I6PFmVACXcYu9ja662853DVRKSF2RvdJ7dG91nA3foeHu9OABEUHmWqu2rvWc1/wqdnj9XibeHpiT7JXPKpNKJdQmW09lyf4FLBBIRaS1l3Q1DQJa0qeQ6kYCrhdck/8CESzC9YkAyPYFbgGqkBdYW4pOldHkxegnJYsQYECBQr8j3A4/gE/mb008TCrmQAAAABJRU5ErkJggg=="
                                      />
                                    </div>
                                    <div class="sname">
                                      Nginx 1.22.1<span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="mysql"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAWzSURBVGhD7ZjJb1tVFMY/O3EaZ7CTOImdqWnSTE3iTmlLQltagiilhXRRlUWFWCAWbGCD2PAXsIK/AAkJNggh6KYUtZUondSqaQltUjejM3uM59lxOOfmBQEK9nuJ0xTJv81T3n0vft+955z7nYscOXLkyLEZVNJ1fTTaIlQ3tUFXXYdELAKfbQ7exVkkohHpiW0nvYC6zgM4+cEn0OoN9NcKAk4bJu79ion7N4SY1PLy6oPbR550XZ/ajn2oNx/Cza+/hGP8KfSmBrT0voqqXa3YUVyK4opKFJbosZyIYzkepzdWVl98fqQXoNWVwVDfBOfUKCw3fsbs0D1EAz5UN7ejpt0MU5sZjfv7YGrvhrZUh4jfi0QkTG8+NyHpBSTjMeiqalC7Zz8cExYE3Q7YaSXmhgfhmh4XYZSMRVHZ2ILmIydgbO6gXInC71jASuq5hFd6AZyssVBQzDaHi318hOI+iQpalVKDEbOPH2D09lXMDz8UK8Ph1trbTwuwApd1VDy7xaQXwEQCXmh2aFHf3YMArUDAuYiSiirs7j2JkNdFqzCPaNAP2+gTOCafoaisAl39b1OOlNC9x1hOJqT/tCVkFrCSSokPNO7uoFWoEuET9rgonJwIOGyIh4PSkxAhtkgfnaSVOzBwETpjHeaeDIok3yIyC2AS0TD09DGGhtWE5nAJLTn/8fFrcBJzvkQDfhy58D7KaupF6eWJ2ALkCeCYzsvXwNTaJcqla3pMGlgf3h84yYMuO4699zEiPg8WLEPSaFaRKYDg2eZkLiozYGHkUcYE5SrknplAXkEB+i5+iOlHdxFw2aTRrCFfAMexWIX2vYhHQvAuzEgj/w2LcFnHsNN8GK19/bD8dkWU5iwiXwDDcc/JbGzpFLPLyZ2JOOWPZ26KQukjisQVWB/ekUaygjIBXBLzdxSSxdgrSqpnfloaSQ8LLa9rxJ6TZzBy7RJi6yT/BlFLV/lwGEVDftrgMs/+GgkKufvff4XCYh3Mp89Ld7OCcgF6KosRr4dmP3MOrMGhs0Rh9OzmFZhPnYemUCuNbBplAlQqFUppM+N9Iexdku7Kg8No8NK35GjrKJTOSnc3jTIBWl05VBRCsXCI/pIcJ4mSA29k7plJTFMS95x7F/lUXrOAMgF5mgLRAq35G3VePnYdfBml5FjlEPYt4ffL36FyVwvajr8h3d0UygQkEzGRxAVSDDf1HMW5z74Q1UVOXKeSSdjGRoSr3X/6ApnEQmlkwygTEKM4TtHmpNWXCyEttDlxl9b12gB5ngbpqfSw4Xty9RJMVIr3nXkHRfoKqNTKyvnfUPYiV5Py2kZh7HyOebLNA5TQIWp6TLDTzLpnp8Tumw62IBEygxVkDLtJeImhWpRZLgxil6bfUMAGlNMPcIemM9aivqsHY3evC8tsauuGi5wq9w+ZYDdrHbwFL3V0RjKIbUdfXxVCNpzHUvJ7COUC2E4UlxvQceJN0dj88csPGL72E5oPvyIqi3t6QlYTw62oY9KC0VtX4ZiyUG/di+ZDx8UKBZccYlwGG4u9pTmrsMg881MPb4s9gS12U88xITDkccsOBS6vfFwzM3SPqpoaTQePQluqFyK4nc3AxgTwDLPLtI0Nk83mPYFaT78Xfmo3dZUmcVXUD9NekqfRiElRqdXo7H9L2HY2jOx80yBvE1IC98QsRm4HxrHfeKDvr5aVSy0f54S9bjz48RsRZmnIvgCl7Nz3Es5++rkQbrlxGXZqR9nleuat8DsWM/UPGwuhbML+is+eCopKMH7nujhA442OV1HG0eX2C4iGAuLAWF9dg7Zjp0R55hMPYRYzF4LtF8CwR+I9hGe8wXxInMkGqX/2O+2ZRLwYAhjewBwTT8VuXkRWxdjaSeXYJcpyGl4cAQyXZ599Hk7rqDhf0ur0lAs+YTP+d6jz80WJzWL3liNHjhw5/gXwJy/Mvf/eLpbRAAAAAElFTkSuQmCC"
                                      />
                                    </div>
                                    <div class="sname">
                                      MySQL 8.0.24<span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="php-7.4"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAYNSURBVGhD7VZrbFNlGO7WtWu7a29rN9atu9GBbHZMHLCBXJQQUQExmhA0GNF4i1HUxGgMP7zExBh/GAWjGA3JTBQNojBQNNw62AJljO7CLu3Wrtu6rmu3rpetN9/n5KwMtsUQyw/jeZKT833f+53vfZ/39h0eBw4cOHDgwIEDBw4c/rdIYt8JQ36Jvla/ZvuzQpEkPRoJh458/fZOXiwWY8UJRzL7ThgKFlev1VVt2F6+fOOOPO1d95DxrOTOIOEEcvJLK/gpglSMHQNdrfS6owz47Dsh4PMFglWbd7+VIVUuSiKMOfo6o9FoRK4uKs9W5BaSXBjweUbZ7QnBgjWQKVNrVmzc+WrJstWb2SUG0Ugk7PeOjTiHzO3tzSe+H+rvuIxch0ymKlz8xCufNWQrFhWBwHTQ752e8k9CFotFo6GpgM/abTxjOHbwg3HXYL8kQ5ajr9v2zLKVD+7CntkITQV9XrfD7rBdv2JqPlHvcdrMVEpRVhzHghEgI4qr1z3+kkqj00vIpTceWU6WTF2oyl9cqV1ac79vwjXsdg70kqPDmrKqOl3Vuq2porRMnIFUomLOwIM1UVqWLFuRp01O5qdYOppOZSlytZW1j+zWlOrrbtYhVaZnyXOlSk1JbtGymuKlKx9wOfo7idDArSQWrIFUcXqmNEdTwk7jgGdJP5kmToOCilUPPUVGFUGmyC1eCgHGHqfdfKL+oxePH3r/ubO/7H834HU78a0wVZKRrcxnzhVLsqRSdnwrSAupEQiJeIYyr7RCX7d9T1qmXMWK45iXAL6kzWqRJFOGOVLh/LGv3vv45dVpn762XnH4873bBi2mJnDJK6pYKWEPVuQxBEQY2y2tF1obj3571XDkm8unf/jCPWo3Y50cGAlRXmFMQaGILGLIh0jJuaMH9jE69m5Q/nzgzR3D1k4jZMQlWbvk3o0z9szGvATIS+kyVUEZPIY55bzTMzLQCyUB37irt83Q4BzsbYMM+U/pHQVpWU5BGT9FyBBwWDuvRMMhyCI0TaJolWIdZ1BxdwkpxEinmf1MKo7aLYyOSc9od+u531zDfdchA5KIBj1zanYBAuJ0Sh9GIeCnAyco/9gpT0KqZ/LcT6kRpuok40uFtAbSlKcxh627FYWLZCAva8WU1NhPW/2uIUu7kEnRG06aHHc5vO6R2TqUqB12ChucEYodO41jXgICukVlSk0ZO2UI4HDkJXJcU1a9Vp5btATetXZdOkNnD8rV2nLUBfZTVKZHHZYOFBzZl6wuXFKNdRCbng74qIN1kI+yZqICIAJez4idqTChSFxYvmK9jHUiImxuazyJ6DObZ2FeAqlUaFRcxeyU0SzOyFbkl1Suurt269M1m3a9riAC1Ar7ek2G46TcIVcX6gTkMmx3j1h7QkG/D2Pkr7qgfDnGOIi6qtvjHDCLiAClaZwAcY2RVroH9aur6FekZtOTb8hUWh2c4HENWrpbTh8lAmPs9jhS2HccVPt8qi3l7IovrVyzBQ875ZGDp8Zdw/0X/zj0ia2nxYAWinRAAcNbdAO30H3B3A2IgKpAV4UxlcSUy9F3HTKqAHmmVKXBOkC/Ho/iYaeM02i7f2Js2Go4fvDDwf72S2w93YQ5BCh8EhiDPsaEPOibgIchw60K49EiTc0N9Zb2i7+T3AvZJKXAAJGBwWZT48l4vsZ4MR+s6Daeo6h4+zqa/6RIpUkpnjO/HNNTgUnUEvWnEHTCIWEq5hF7T+u1xl+/s1tMzdDLnHcL5lQ1eV+15uHn9y2/77EXwtQSzCZDg/Hs4S9xMB1CdMYcZI8N3YL95LaRTjdY7ZY97+CixBzEjWd+3I9ag/GhYGASTQOOw5z5aAHMqQHksZx+CTAOBrweW+/VRnPbhZPwtrXLeBat7d8YD1AAMkiHDmMEdXTI0tFp/Osn6EGE7JZrTSjofzIemEMgRSASz7TQIBWN22nrYQQJBO4ZSlNGB2I64R62UisOMsLbxJx/IfphZHqQw9bVYqO8hUcodd2sOCFAK0YTIh1XbT1Xzlvam05NjA31s2IOHDhw4MCBAwcOHP4T4PH+Bl/oKE5jUVDxAAAAAElFTkSuQmCC"
                                      />
                                    </div>
                                    <div class="sname">
                                      PHP-7.4
                                      <span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="supervisor"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAgAElEQVR42uy9WZcc53km+Hyx5r5nVta+oQBUobASAEmJIkVLpGzZsmR72nK3fSHrV0zftS96LvrMzM30mXNsn9MX9nGP5pzRuL10t8RtRErEQoAAC2vt+5b7vkVmxDcXkRkZERlZVeBiAep4pSIqszJjyfye792fl3z/P/yQwhZbbLEUxv4IbLHFBogtttgAscUWGyC22GIDxBZbbIDYYosNEFtssQFiiy2/ocLZH8G/jBAQqP/v/Ks+e7xQ0O6v6iOqe84WGyAvOjAYwmAoNIiwN4SwJ4SJ6BicohMOwQGX4ATDsD1QUaiCSr2CaqMGqSVBVmSkSxkc5BPYSe8iWUjBhokNkBdSeI6H1+HBUHAQIU8QYW8Yw6FBuEU33KILPpcXHMuBYzhwLKdpFYPeoBQtuYmm3IKsKKBUQV2qo1ArIVfOYflgFeV6GaV6GYf5BCr1Cppyy/7wbYA8p5qCEAicAKfggMfhQcwfw9mhGYyEhjASHkbMFwXP8WAZ9gudpyk30Wg2EPGFkS3nkC5lIPIiDnMJlOpl1KU6FKrYX4gNkOdLBE7AuZGzePXMK5iKTWA4OAiRF0EI+VLPw7M8eJbHtemXDKbY/Y0HeLK7iNurd1CoFm2Q2AB5PmQwGMdEZAzj0TFcmbqIkDsEl+iCwAkGcEiShHK5jGKxiMPDQ6RSKZRKJRSLRTSbTbRaLciyDJZlIQgCOI7Tfvd4PBgcHMSpU6fg8XjgdDoNmsspODE/Noeh0CBOD53Ch09+hf3cAVLFtP0F2QD59ZhTbtGNgMuH+bFzmIpNYCwyilPxaRBCVJ8CQLVaRaPRQK1WQzqdRiaTQTabxeHhIdLpNIrFIkqlEiRJgizLGkB4ngfP82AYxgCQSqWCYDAIn88Hj8cDt9sNp9MJnucR8gThcbjhd/lQrBbhFl0gAJI2SL7Yd233g3weM4fDmaEZvDR1BW9f/BZETgDH9u41Gxsb2Nvbw87ODu7cuYNUKoVisfj5TkoBr8+LQCCAcDiMudk5nD5zGuPj4wiFQj1+ytPdJXyyehf/9f7PQan9Fdsa5F9AGMKAZzl876XvYm7kLE4PzcApOKF3M1LpNHZ2dnDv00+xsLCAcrkMSZLQaDQgy/LJ0aDuX91nCFCpVFCr1ZBMJrG2tobgx0HE43G89tprmJubQygUAsuy4BgOZ4ZPYzw6Cpbl8HD7ETaSWzZQbIB8teDwu3w4FZ/CudFZjISH4XG4Nf+iVqthd3cX6xsb2N3ZwfLyMg4PD9FsNr+0hakoChRFQavVQqPRQLPZRK1WA8/zqFQqmJiYwOTkJBwOB0ROgMDyuDxxAQAFy7BYPVi3cyc2QL4aYVkWUV8E35j9Gs4On4ZTUB1lSqm2q9+8eRMLCwtIJpOo1+sGbUB12uCZ4lq035so6vUa6vU6UqkUUqkU5ufnEQ6HwfM8OI4DIQSXJi6AZzmInIj1xCYUqtiaxAbIl689fufSW7g8eQmXxs9r0SlKKe7cuYOPP/4YDx48QC6b692hqamopP1LZ40SQrvgod0gQPcxbb+NGBFDifpbO8e4sryMne0dfHr3U/zoRz/C2PgYIpEIAGBudBbj0TG4HW68++B97Gb27S/1pBvj2bfm/539MfQXBy/iyuQlvHzqGiZiY3CLLgBAsVjE3t4e/us//zM2NzeRy+chyy11/RLD2u7iQlv3VLfkCUh7kXf+NeKF6J7r/oHqAUNI+0mKZqupml+tJtwuN7xeLwhIOxzsQKlWRlNuoVAt2F+urUG+4O7BsPA4PHhp6jKm45OIeMOaz5FMJrG0tIR79+6h2VLLQUh39QLmBOHRD4+xsgiIwdai7X9o5xEAoCW3UC6Xce/ePUhNCS6nC5FIBBzHgWd5TMYmMDdyFlKzgf3sAVpyy/ZJbIB8fgl5QpiOT+Jb578JhnQ7A1ZWVnDjxg289957aEgNbTc3LDVKNZCQHl+CAITqFr/O4dBpCkLMB+0cg4C0tQjVDt49Sqlcwt27d/H40RMMDAwgHo8jEAgAAF6ZuY6Ay4/N1DZ2Mntoyk37iz7KvLY/AmshIJiMjePKxEUwhAEhBJIkIZPJ4J13fo6Fhc8gSZLqY1A9ANREIdHt7R1fobOGCTU64VQ7ADE485R2/0IpMfnt1HCt+msgIJBbMmrVKv7xH/8Ri4uLqNVq6o7IchgIxPCt82/C7XB/6aUwNkD+BxGv04OR0BAmYxPaIqrX69je3sba2hqSySQURbYAltl+OpkJQ/saXbTvo6OWNqUUrVYLS4tLWF9bx/7+fjvgQOB1eDE7fAZRXwQuwWV/2baJ9ezaYzw2hlPxaUzGxrXnC4UCPvnkE2QyWTQaDeu1TEyrV2da6ZSM7mna1Q7EyhzrqBliBUXV1CLWaCEESKfTePjwAQgBpqenAQAu0YmpgQnMDp+GoihYS6zbX7oNkGcACCF47cyrGAkPgWXV8vRUKoWVlRXcunUb9YbqdxAKo5NLjOaRvm9Q/zpq5cR3ntfpEoNrTqjBzNL7LMR0PKozwggBNjY3UKvXcfXaNQwNDcHtVhOc3zr/TTgFB9KlNArVov3F2ybW8SLyIoLuACai4/A5fZoLvbe3h62tLZRKJSiKcoSpBF0ijhojWye3uE5gkpl+OeK49UYDuVwODx8+RLFY1K4/4g1jKDiE8eiYIVRgiw2QvuISnBgIxDAWGYHX6dGe39zcwPr6OppNyQgAgu5PVw20nXV9ZKr/IibaD+12F5JO/3kXX9rrSFdPUOisLz1YtPcRKIqCSrWCO3fuIJPJaDVhbtGNwcAAzgzNwMaHDZATyWAwjldPvwwH7wDLsGi1Wtja2sLCwgKWlpbU6C1tEycQYliMhlWsW8AWrkMbDLT9P/3rKNTDk/bK7yJEC5hRs8dEQAlVf3TXQHQhNElq4snTJ/jlL3+J+/fva++O+CK4NH4BHMPZES0bIEcLz3LwO30YCg5qz0mShOXlZeRzebSaza6FT2DyLFSPmejBYnLO9Y58G2OGLd8MFBCqVy8Gu8rgcegRQ6hBe+jsPlBKsbO7g+3tba2I0ik4VDIJbxhO3mEvAhsgR/sfPpcPA/4oCCGglKLRaGBlZQXFUqlbrk76+AOm4JPVjkx6DKv+ZldXP5D+ZzvRpt99T+Iwgf39fTQaDVBKIXAC/C4fYv4onKLTXgQ2QPpLzB9DPDCAqC+iaY98Po+HDx6gVCz2AoGanXOj8qDmJ9Bbo3Xkkjabb0b9YhEd6PeH7q+5XA6Hhwns7x+oHYwMCwfvwPmxOa2UxhYbIJYyEhpC1BcBz/EA1ILEZDKJXC6HZqvVsxi/WECKnggpXS/lWOVwoj/KsoxisYClpSW1EqAto+EReJ1eQ0mNLTZADBLxhuHTLZJyuYx0Oo16o3FkaPdFEkopqtUqtre30OjcFwH8Lh+cvAMMYy8JGyCWNj9BzB+F3+XTnku322cVRd9kRJ67K6cn1iiqVKtVrK6uolqttv0qAifvgMAL4FneXgw2QHrBwTAMvE4PHIIayWk2m0gkEtjY2DiiGuqZrJsTGViaL0NP+qZnd9olSUIqlUI+n9eKGLUiSzvSawPEAiHtxcFoEaNGo6HxVn1uF+AZfI0TL3LyLMCksFIvCqVoNtXGqpbOt7LB0St2LZa2OIwJi3q9jnK5jFKpdHJtQcwLmfZ/nVURIyxac/UPyefDjIUjAqVd7XtyphUbILaYzBBJktBsNg1948TSA7CqJSG9q1//QAcAoitPMS9krWCF9OCqz4Nu7wjpVjL2Qomqm4KdPbdNrC9me5kWlcE3oCYT5khrylSTpU90WOUMaW8VIrXQRJT0Pym1OpyV5tS/xu7AtQFyEmFZFizLtMOe5IiFQ3oXOD2JD0ENmLEGRxdRxBJnFhqLHHE43QO1wJJ8Dp/KBogtAARBgMMhwuEQ2uYIBSHGFd3bqERM2qSjIdReDi2xTmi3vKpN30N7FnxHQxD1R7e7m1tu9W2/HYIH0kaSoVVX11xFiAp+0m58p1SdQQKbM8v2QazNEWOtRrPZhCQ10ZRaqhlD9UQKun5A3dZu8BF07zG2TplrGXUVuLodnpq0hZmYoXM2QjtXr3dqSB+DS0UHIQw4jtNY5G2xNcgzi6IoUGQFcp8M+klzI/QYWB7zK0769hP/qe2cc7zKIt/pmKTtyJZiG1m2BnkWrUKpiZiHmilJiEEzaKSIZpvIYCaZGOWo3mYzaRONxdGaA4h2hoLSLo0QNYChe6JOGzBDGIiiCFEUNQ2iKAoUqvzGlNTYGuQrjlp5PB74/X74/X6tV9zUEWU0mtp+hSELrndJKDVErXR9VbrT66ogafd91BxeIiYHiFJ0+qtU0462Q8Sd5itjzwjP8wgFQ3A4HKoGoUBFqqLRbKCl2HMObYBYBo4oFCpro8sEQUAgEEA0GunxG4zQoBY2Df38JlCfs32eI/X7C8dx8Pn82pAeAG1wyDaxtQ2QfuBQ0FKMAAmHwxgYGEBvsuOoBUn7aKaTwYAe+bZO8pH0BdFJnuF5HoFAwACQerOOlj0l1wbIUSDZTG4b5vqNjIxgbu4cCGHQm+igx5ppfRcp7fM6etzapv3PTU+qeChcLiemp6fA893K3b3sASr1ir0QbID0l8N8ArlyXtMiXq8XAwMxxGJRCILwDIbOSfbxz2V7ncyPOuIYPM/D6/VieHhYc9ApKPKVPBqthr0IbID0l0QhiWwlh2ZLJXR2uVR29LGxMbhczr51S19OyPf4wMGzqUTrp10uFwKBAAYGBsCyrGpeKgpylTzqTRsgNkCO0iC5Q+xl9rCXOwAFBcdxCIVC+MM//EOMjIwYTBL9GrSi8LFiAzIaZ5a5c4tkPNVIrM2mlKEUTHuuG9Hq6WsHxfT0NGZnZxGNRsGyLKSWhEKtiJ3MHsr1sr0IbID0l0ZLwn7uEPc3FrSVx3EcxsfH8corr+DChQsWfkIHFKSHpUere0I3U09AQSjVwsHE3CGli/KSTh6jQzGk+xvVlV7pXRqVwI52eeLbzBKEYeDz+XHhwgXMzc1pl1+sFbGR3ESukkejKdmLwAZIf1Gogkw5i8W9ZWTKWdSbdbXT0OvFzMwMZk7NwO129xIbUNLXtCH0pDYQOcY5/wJeCUMgiiKmT53CxMQEYrGYFpjIV1WANJoNyIrdG2ID5BhJFzNY2HqIh9uPkClltednZmZw/sJ5jIyOguU4jdeNtilGiYn5UE2ek94IU7uxo0M1CnSz3+YkvVps2Kn61YV2dclAq8iXgXoIBCzLIRAI4Lvf/S6mp6fh86l997Ii4zCfwKc6jWmLDZBjtUhTbuL//eSfsLD1ELlKXjO1wpEwrl2/CocoGPwHAzVPx9Tp41xQrfmqDZEjIr2dSYZmYml973jHFOtcAyVGx54AGB0dwZUrV3Dp4kUNHABwY+k2Pln9FOuHG/YoNhsgzxAAohTpYhpb6R1sJLfUWllCwLEcXC43CMN0HW1qZo/r1EXRnt1cv6q7pNMU/ROR+glTupAA7Q741F5FLd5P1Qm90WgUExPjcDhUWh+pJSFVTOPhzmNsp3cgtWzfwwbIM0pNqmM7tYPFvaXuzk1U9pPecnL9jm3RAWjVbE7M76bHRnNJb9P7sa4KwzCIxWKYmJgw3NtWegcPth5iN7Nnf9lHiF3Ne4Sk2lpEURQwhAFDGDgE0VSq2Lvja4uZoNdPIMbhnAb9oU2tta7looZeW2oJFXPVr8PpQCwWw/DwsGZCJgoJ/Ld7P0O+WrQdcxsgX8wfkeUWFErBEIBhGYgOEQzpzi5nWE4lljOVidN+3KTHUJaeLAdvnZokRC1l93g8YFm2fc0sWJbVytirjSqy5Tz22mOgbbEB8vntz3ZbaidRx7IsXC4XPB4PKKXgeR68IEBqNtGUJNRqNTSbzWN6KsgJANDvfTrPgxCDXyIIAgRB0LL/aiEigSzLcLu702ybrSYazQYazYZduWsD5ItJwB3AYGAQLMOAQK3wjcVieOvtt+H1ejE2Ngan04lCoYBkMomPPvoIKysrKBQKpuVPepttteYogqNYSYiu58PAlaUbLUUYYGbmFE6fPo2XXnoJPp8PHMeB4zgtj+NyqdNsvU4vxqPjeHP+Dbz74H2U7QLFI4U9+9b8v7M/hl4ZCQ/j1dPX8eqZ6wh5QpqDLooiHA4HeJ5HsVjEwcEBKKXw+XyYn5/XomDZbFZXY9LuH9cvfi0TTo7VG2bF04ETy7BwuZy4eOkiRkdHwfM8dnZ2cPfTT/HgwQM8fPQI1UoFhKgaxulU68lETkDMH8VGchNSS7JrsGwN8mxCCMF4ZBQTsXGMhIZBCEGr1UKtVkMqnUYikUA2m0Umk0GxWITf70cwGMTk5CQGBwdRrVZxcHCAarWmMoV8iaL3NxxOB7xeLzweD2q1GvL5PNLpNJKpFBRFAcdxaNTrqNVqqFaruHz5Mnieh1NwYDg0iPHoGCqNKvKVgv2l2wB5BoCA4PLkRQwHByHyIgCgVqthY2MDP3/nHTx+/BilUgmNel0zggRBwOkzp/Haa6/hzJkzODg4wNr6OiRJMvOv9/dBjMQlR3orLMsiFAoiFAohmUxia2sL5XJZAw/P83A4HPjkk0+wtLSEsbExTE5OIhAIqL3ohMOFsXOo1MtYT2zYX7oNkJODgyEMIt6wxvROKcXt27fx2Wef4ZPbtyE1JIgOEdFoFPVaHfVGA5IkYXFpCflcHj6/D4FAAIIgQG7JUKxCqRYRW2KKchn4eHXgIQAEjkelUkGj0UC+kEer1YLb48b42DjefPNNRCIRuN1uvPPOO1hZXsH21jZ+9t9/hm+/9W0t5DsUHETMH4PH4bZ9ERsgJ4xcMQwEjodTdIJjOVBKIUkS9vb2sLu7i1qthsmJSQwNDWF4ZBjFYhHr6+vY291DuVpBOp1GtVZFvV6HoiifizG9r9uuA4ksy6jX6gAhkCRJCyBcv34dZ8+ehc/ngyiKuH79OlqtFhYXF7G4uIgrL11BNKo2gDkEhzoXhBMA2ACxAXKSqAXDQuRFOAUnOIbTBnkeHh4imUiCIQwuXLiA8xfO49y5c8hms3j//fdRqVRQqVRQrdVQq9eRzxfAMN0CQ3piImsL7YFOkpBoIJEkyZCUdDldGBkewTe/+U0Eg0GN7+prX/sa8vkc0ukUVldXkMlkUKvVIAgCeI6HwAuaGWmLxYZpfwSmHYNl4RAcEDkBLMNAURQUi0UUCgUwLIP58/P4gz/8A7z88staqPd3f+938aMf/QjBUBC8wIOCQm61IElNtFqKJQevxqzert3q/Bj7m3R9I8QcxjLWcF28eBFXr15FJBLRwKFF5EZGMTd3DtV6HYeHh0ilUtaRMltsgDyrKIqCUqmEZrMJjuMQi8XAcZy2YAkh8Hl9GB4ZxrVr1xDw+3Umkm7+ObVumKL6VipC+raFmJN62jgGAvACj6HBIcTjcct74Hm+3VNP0WrJhqE5ttgAeSbpEK3pF2a9XkdLlsFyal+FedCl0+lENBLF5cuXEQ6HwPOcaWs+bo/+/Hs4YQgcDgdiAzFEo9G+fhXHdxgUZciyqSzGBD6GYcAyLDiWA8/yph8OLMP+DzMN1/ZBzBqDKhppQ0dDOJ1OsAwDlmEgCIIleYPD4cArr7yC5eVl1OsNbG5uoqfZA+Z0YceD0Lfbmv5OqMmsUpu0OqEvjmURj8cxODiIUCjUH/gK1Xh5Vd+oc78Usi5XwxAGPqcXDt6hAULvOimgqDaqqEo1VGqV3/g+kt9ogHAsB4/DjYg3Aq/DA6/TA7foBsMwxh2QAAwIpJaERkuC1JKgUHWyLcuxiEajCAQCqFarSCaThrFltD1wgBACjuMQj8cxMDCgAsQq/GT5uF/8ivRhbKS63Z5FOBzu0ohaiCRJqNfrGtidTqdmPvIsj4DLjwF/DAP+GKK+KEbCg+BYHhzDgmVY7R4791uXGqg36yhWitjPHyJVTGM3u4dMKfsbVx38GwcQQghcghMBdwB+lw8RbxjxwAC8Ti+8Dg/cjl6AkPb7pJaEmlRHTaqCZzitWNHtdiMYDCKTySCZTKLRaECW5S4zug4kPp8PXq8X1p4ETgCSZ7SRGQYejxc8z/elJeoAhGEYOJ1OOByOtrYgCHuCODt8GkF3sA2QCAYCsbYZpeaEqK6ijIKiJbcgtZqo1MsYzMeRLKQQ8YWxkdhEvlpAoVr8jWnC+o0DCMdwGAoO4mtnXsGp+BTGo2PwONzPbDPXpTp4Vl10DocDQ8PDSKZSWF5aQqFQgM/n03ZiPUhcLhdcbrfF7MHevpBeslJTHwihff2UzqEZhoHP5z1yzke9XkepVALP8/D5fPB4PAAAkRcxO3IGZ4Zm4HV6T/7htNmPQp4gRiOjkBUZUkvC/Y0HeLD9CPc2PkOykLIB8jyJS3RhdvgMZofP4NXTL8Pr9EDkRfAs1wOODteUJEnaIjMzJ4q8aFiTZ8+cRaVcwad3P8X9+/chyzJmZ2d7ig1FUYQoCNDNz9E8D62Al8JysRPzrE2qj1aZqLNJN8pWLBb7RqZkWUYymcTe3h6i0Sg8Hg9EUc17iJzY14fI5XIolUrI5/OoVqtgWRaCICAajcLtdsPpdGqfGcuwcPAOXJm8iInYGF49fR3/58//GqV6CdVGzQbIr1NEXoRLdOLq1BVMD0xhIjaGmD8KjmE1k6NSqaBaraJSqSCfy6MhNdBsNlGr1wGqEsS53W4MDw9rJpLZXIlEIojHB+Dz+bC+vo5IJIKZmZkTT2iin9vCOtoJbrVaODw4RC6XQywW08raOxvB9vY2Dg4OUCqWcGrmFLxerxaFI6RLCFEqlVAqlVAul5HL5XBwcIBCoYBSsYSG1FAjYe0ont/vh8/nw+DgoFbS4nA44BAcCJMQnIIT109dxfLBCrbSO6hLdRsgvxZ/AwRu0YV4YADfe+l3EPQE4XV4ejRFPp9HIpHA3t4+VpaXUSqVUKlWUKlWAUq1UQevv/46JicnVe4rUyg3FAoiHo8jNhDD+vo6hoeHIUlSD0C0WRy6jlvzzk+JbhQIMWmMPm3n+uMQXYtIs9nC9vY2EokEBgcHtZL2zrUsLS5hZ3sHlUoF586dg8/nMzjznetNp9PY2dnB7u4ulpaWsLW1jUKhgEajYbgcQRTg9/sRCUdw+fJlnD9/HoNDgxBFUS2l50WIvIhvnf8mKCiyldwLDRDy/f/wwxc2TncqPo2XZ67ht+ZfR9hjDHFms1ns7Ozg5s2buHnzJoqlEppSEwa6Hm3iK9FMhcnJCczPz+NP/uRPtL6PjqRSKXz66af4m7/9W4yPjeGNN97Ad77zHYO2eefn7+Du3bv41ccfG1kPdWFa0pk2ZeGe9MSx+vHJmYb0jAwN4/Tp03jr7bcwOTmJer2OTCaDv/iLv4DT6cTIyCj+7b/9nyGKogaQ7e1tLC4uYmFhAXfu3FXnwrdD3F0+ru60BcPERaJSD7lcLgwNDeHatWv43ve+p2lfCiBVSGEjtYn/9MHfIlfJv5CO+wvZMCXyIgb8MfzW+TcwO3wGA/6YobBweXkZt2/fxr1797C4tIRsJqu2wlLlyJ5wSilarRaKxSI6bax+v9+gTXiex8LCAhqNBkqlEmZmZqAoCmRZxtbWFm7dvIXVtVUUikXdYtKzVBnDveSIYnhissMIsUCKVryooFqtIpVMYmd3B48fP8bDhw+RTqdx7tw5XLt2FTMzM2BZFpVKBWurq/jggw/w6NEjTVvIcsvQv0Isrofqx5FSNY8iNZsoFotaL3wgEADp+HacAAKCfDWPaqOqMefbJtZXmNvwu3w4FZ/ClclLiHrDEHkRlFJUq1Vkszk8WFjA7Tt3sL+/j1Kp1LPb9rBJd1IOVEGhUECxWMTNmzfhdDoQDAYRiahTphwOB4aHhzEYH8TOzg6ePn2K5eVlhEIhCIKAp0+fYnVtFYlE8nhnQ58AJCdyN458TcfPOjjYRzAYBKUUzWZTo/yZmppCtVqFoihIpVJYWFjAzVu3kMvlIDWkHkSQHnVG+/pAhUIBxUIe9+4NAQQIhULwer1qwSfL4fqpl7Cd2UGpVtaI+GwT6yuS8egYzo/N4396+fvwObsOZ61Ww0cf/RK3b9/G7Vu3TNGZbt2Sebxyv25wAuDcuXlcvHQJf/qn/8bw19u3b+PjGzfwwQcfgCoUbrcbPM+jUMhrpgklOGbUbOdXYgBLT3Mu0fewG/MRRsdGf2yCUCiEoaFBfPtbb6FcLqFSqUCSJJTLZRweHuLBwgIMxEG69l9Ku6NANaZG0+BF0qZF7fpD6n2cOXMGV1+6ij/90z813PGvFm/i3sZn+ODRh7aJ9VU55ALH45vnXsdLk5cwFBoCyzJQZAXNZhM//elPcffup1hdXUG93oCRZ50eoT5IH8OeoFavoVIpY3p62uCPeDweBINBDA4NodVqodVqoVQqtU2Uo1QB6TFe2pPLrZ2OnvdatRvqkKhmPEHapiDH8tje3sLy8jJWV1exvb2Nvf19pNNpNBqNI/rhj7h+Ams7rw2ker2Gg4MDjI+Pg+M4LarGsRxacgvLB2toys0XpkTlhTGxGIaB3+XDRHQMI+FhtUaIUo1R5N69e0gkEsjn833ip0ZgMAwDl8sDp9PRrs5lIEkNNBoN1OtqGLhcLuPg4ACPHz/W4v4cx7XpddwI+AMIBAJt+10+BhzHxXYJvhQG6bb2akpNlEolJBKH7bL75glsueOu7/jQc6VcRaVcwYMHD7SwMMdxCLqDiPmjCLoDqEpVKLJiA+TL9j3Go+MYCg0i5AkCUJNka2tr+OCDD/D06VOTxrBafF3bpzP3Y3RsFD6fDzzHIZVK4fDwEHt7e8hkMqCK+oX//Oc/15Jsfr8fBwcHWFpaxGeffQZKKRhG7QHXJ+v0zU9Gg944Sppazi+kFlrDtHh7BnmS7i0CauNWrWqhtfR5e2r9GR0FDt0wH0Jh6BPuOliPCgIAACAASURBVPAE77//Pvx+P0ZGRuD3++EUHAi6AxgJDyFRTL4wpHUvDEAcvIirU5fhd3bZyVdXV7GwsIDbn3wCUAJKqGX0heoI1xiWwYUL53H+/Hm88cYbaqUuqyYVZVlGpVJBoVDAu+++iydPn2Jnewe7u3t49913sbe3h+vXr+MnP/kJtre3tcajVqulFjAesQFTUF0GnZqy5XocWS9gYgC+Pp5kjIWZ4l6GQkNzUUvXvbGIpVl2P7ZdEaIzq/QUqDpfKp3JYHVtDQMDA3j55ZcBAAInIh4YAMewdhTrSzWviBouHAjEDO2huzu7SCQSqNVq3e+R9AatNHAwDM7OnsWFixdxfn4esVhMA0dH3G43fD4frl+/Dl4QIPA8VtfWsb29g1arhXqjgY2NTeRy2XZPuH49kSMNkY4/Ti2SGuRI/wsGZocOrSkl1mfSb+yd1xMrU8z8wCJJSfuEfA1+j4XSkWUZhXze0L3IMgwcgqNvUaUNkC/gfwicgIg3DIHrJu42NzeRSqWsLRi9MUPVxiKWZfHqK6/g0qXLmJ6esjwXz/PgeR6vvvqqWvkqitjY2EQicYh0OoWV1VWUiyUDvSh9Fo/CIrx8EqvfvIMTw27eG9CiJoPzi9YO024M4Mi5ip2LIKAolcpIpzO6p4laAAobIF9uqI1htY42AoJmU3VAnzx5gr29fc3EICZHVS8+rw8D8QF897vfPXakc0cuXlQZC1OpNB48eIBsNoumVDC4BnptQPrPWwM5CicmN4KY1Y4xBmw9T93ieszgpbQbJFPLRkQosq4F10JdkOPuxYq+iKjGYaVSRj6fgyzLajie4ksn0vvKN+cX6WI7pSGtVgvlchnValWtyO04jqb0AdEtJsIQjencXGfVd1ETdbbfxMQEXC5Xd1HTIxaqbgLtiSKn+sGclj6yrq/9iIgshVWC3QIpuhd6PB7EB+M4NXMKgiiAYRmYZ4panUPrsTcB26Dl0O5WlOVuSy/BC9eq+0IWKyqKglqtpjYumcu8+5Rj0PaXJUmSVpl6nDSbTUiSBKfTAZZlDHYTPSJmRvtdCu1jUpmUxHH2kDnLbTa3rPwNq3PygtofEg6HUS6XUamofF6dNoCOxuF5HgzLgBCCZqsFRZahGNju+vtNCjUGGpgXyEF/YQHS2d0pTPPD9T3bOlVCKEGlXMGhfIAnjx9jYnJSm/R6lOzv72NpaQk//elPkc8XdHkOYnA0uklxatmHTkwT0khvPEkf6zIyLOp7SKiREki/QonuM6AWoWFqijRRSpBMJkEphdPpxA9+8AfY2NzA5uYmFp8uGrT25OQkvF4vHE4Htra2kMvlUS6XTdcBQ1SNUgqGEHAMoznlDKMme20n/SsERceRDgaD8Pl8KBaLqFZrRjXf2fp0IwJkWUa1VsPf//3f49r16zh//jxmZmZ6zlGtVlEoFHDjxg2sra1he3sbhXy+bafrPWSLUnZKDO2pxi3eCAJrR0G3mIlRjVADMLtAJJ0oFSW94QHTaczl94qiIJ/LoVGrg+cFTE9P4dSpUwgGAlhbWwfLspidO4s3Xn9DzRXxPNLpNHZ3d7G1tY1ffPgLtFotUEUxBqEJBaUErZYMqT0vRZ2zghduJskLARBKqTrtSZFBoTJ5dMKxDodTBUi/cA+69rDSamFlZRUOhwNyq6XNzuj0c5fLZaTTaezv7+POnbvY399vJwzlf+HCCHrEQ3pklOkZP1g0Gg1IDQnb29sIhYIIBoM4ffo0nE4nRFHEhQsXMDc3B5fLBYZhEI/HEY1GEQwG8ejxI2Qz2XbPSO91qRO6ZIP/+KLJCwEQWZHRkpsa2wjLsnA6nYhEokilUshmM9r8cauVpTcCKtUq7ty5i8ePH2N1bQ3z8/MIh8MghGBxcRHr6+tYXl5GsVAy8oDqbKRuPowYUnY9k2fNyQTDwSwaPQht94oQiypavQOk00bUwiWn1gwqtI+TRkGxt7eHcrmE9fV1/Nmf/RleffVV+P1+BAIBwyfqdrsxNTWFUCiEhYUF3Lt3H41Gw/LYlFJ1PN0LPMnqhQFITapjN7uPgNsPl6B2zQ0PD+Hw8BCbW1tqJrhjUhGrEoruFycrShsod7CwsKA1EEmShGaziWazacxoU2KaXksM0aWj0mkmz0J7nWaKmYBtdmr7aw59Vt1silLddZqz5KQnFN6BT6mkAuQv//Iv8fu///s4d+5cD0A64nA68do3voHt7W1ks1ljXqhdBqNNBX6B5YXxQWRFRrachaQjdRsaGsLm5hY4loMst9A/29C7ZBWFolaroVarPYux0wd4/d9NT/zuX/8uqygKJElCIpHAwmcLkCQJLMticHCwJ+rHsSziAwNtM9eBarXaczyGYXoqFfTgJ4RoIyY6mo5SqrGk2AB5JoAoyJSyBtbD0dFRxGKrEHgBVVk2MKJTSowh0SPCsNZLlvQZx0x66wcpOQEme8OindorPUs7MTnvhrHSmvNNe6iByLEXcPQuoCpetRW4UW/gzp07SGfS8Hq9CIfDPQBhGAahUAiBQABulwvVSsXU4wItnK4RdZsCLizDwuf0GgIbsiKj0ZRsgDyrSC0JT3YXcX36qlrwxnIYHR3F7NlZbF/Zxsc3bkCfpCCg6GNy9w6m6ez2hnxEN35L9IuYGksI9SZNTyNTN6xjKJg0RUd1rR3UogpYj0XSO3fdBG1iig0TC1NK7z8ZQdK9xnqjgadPF/Hk6VP8/vIyrl69iqtXr2omk9ou4EJsYADhaASpdLonk86yPHhe1LSIQhXUmw1wLIuXpi7ijblv4MLYvJbeJ20Tcy+zjw8ef4gbS7dQlWo2QE6kQaiMdCmDg/whIr4I4gE1jxEOhzE/P4+bt25pdKGGtUWNUdQe91VPmqAjKTB0HnaqXY2uTI/1b9Y43bVK+4aGrdhF9d6FoaTc6vVmZUBoX8+FmvyU3jC1Hphd0oaHDx+BKqrD/fLLLxuY7d0uF9wuF0B1nln7fTzPQRQFA8tKU27iwtg8pmKTmBqY1JlY3Y1jIBDDa2dfRaacxW5mD6li2gbISezjQrWI/dwB4oEBDSDBUBBnZ8/C5XapIUvppKq5N19A+seZ+kSijCYDpdSSUKHf2U/sefQLiH0u3+no67E6wMbGBmg7GjU/Pw+Hw6GZXB6PBx63x7ABdYDHcSwEge8519zILMajYxgKDgJQS4c6uRKWYxHyBBFw+/F4dxE1qf5rBcgLx2pCQMCxPGZHzmhkzJFIBHu7u6jXau0Z5RZMIBq7YR8eHXLEItbt4KQzw4MY3Q9qhg3RUY/C2E/eZs1pv6ZPbEFDKe3xc0hPYJd0nzOpD9KOJhEYg3uEdH96u3mpYVYJIUChUMDG+gbi8TgcDgf8fj8AtPtninj8+LGhEJISilhsAEODg7h48WLbTG6iXCvj4vg8ov4IOFYF2eHhIfb396Eoita1yRAGLbmFfLWAjeSmrUFOKnvZffhdPuxlDzDY9kUAaPxUxWKp3XZrxsDRWzCh/QOphpoParTfCLocVxQGu6xb8mGq4eo5h5l71ICr3nYnaoFq2uc+9KPfiIVj3n2PPl9ibce1ZBk///k7kGVFnYkSjSIWi2F4eAh+vx/lUrsNoH3dLMuC07UnuEQnTsWn4HV6wXM8KKVIpVL4xS8+xMOHDzAyMoLf+73vYXx8TItcKr9mtvgXDiAsw4Jh2J7kUzgcbrOL/AvdUp/kFzkSh6YFfQI76CuvWqJ9bDnL26XY3NzEysoKIpEwIpGIFuWKRMIqrZCunF2RFcOoCJ7lEfaGVK6stkm6t7eH9fU1LC4uoV5voFqt6M756w99v3BZnKmBScwOn0HMHwWrqwxNplIolctoajVTvQuAao51715MtT3f7NYa68T1Oz7VaY+jY6jmzLmFr9LDQUVN125dW096ro/20NNZ+yXUuvXdIkSmv8darYqHDx/gww8/hCzLcDqdCIfDmJqaas9n7B6hU9em39ycgpEa9cHDB0gkk2i1mqjXa4aEox3mfQYROB7TA1P47UvfxunBGYjtXajDQP5Xf/lXSKfTKGpfCD2B82p0thUt9EmNhX0G451alHLorHfaj0bI6rG+0NCq748e04xrfZfWZAxWJlm3srd/M30vs10ikUCrJePWrVs4d+4cvF4vLly4gLt3P1UThm1ts7e3i3q9jnfeeRdXrlzWCPgAIJ8v4PDwEB99+EvkcjnwvICzZ8/C7XZb+I82QI4Bh4CgO4Brp65gODQEr8MDQggajQZ2d3fx6NEj7O/vQ5Kk3h3IXPdHLJqJzC/Wk0pbOw3PYLfomKaJMQthDYMTmBV9Qmy0vzF3hAlF+qla0+9UC9+2mmrD2qNHjzA6OopQKITh4WG4XC6UyiW0mk1QAFKziXw+j9u3b6HZlDA4OAifzwdFUXBwcID19XXkciotrMfjxdTUlIGdvibVDYlhGyB9xCU6MRCI4fXZ1+Bz+rRkVblcxsrKCt577z2UKxVdZwS1zkB3YzQ6i4LoQpQWO77GLGihTbTj6d91zNAb03o09pCbmazJCXBI2glGYoEhekRo+tm2Z7MpKTUa+OyzBbz66quIxWIYHByEx+tFLp9Dq9nU3lSrVXHjxg2k02kMD49gYmIczWYTm5ubePz4cXv2CAen04nTp08bNEipVkataScKj5WXJi/ha2deQcQbVk0hRUGr1cJ//s//F548eYLtre32uqLdEKY5kgPaBYG+KJaYlzlMgzP7TL3Rh1L19KCkNzrVDS9TXcdgr59E2zHfbm+77lpB4HI5tM2hUqlo4WfSUzlADA6E9rp2rZMWrob1aGl97FnNiuvGObT/22w1sbW5idu3b0OWZVy5cgXz5+ZAFRnLS8vtPaWrPZeXV7CysmJQwlRRjzs4GMfs7CxmZmY0511WZCzuL2Mve2A76f0jOAQjoSGMR8cwGh7Rni8UCrh79y5WVpaRTqe1GeTWPjDFsWS8tLcfnBrcXmPWWd9DTo1tfsbG7b4GkOEEpvwFte4LR3fQT6c835zb6K5HajyA1ievBxHVPieqv0ZKdXChGl6I+Z7ax1tfX8fa+jparRbm5+cxOTEJh9OhM0U7M+EVKIoCRVZAZfV3tRyFxfj4OM6dO6fVbDVaDRzmk0jkEyjVyjZArMOlaqn01MAERsPDiPhU7dFqtZDNZnHv3j3s7u2hWCp2rRFDtqydhzjC/9QogWDKc5zEzLDivumX8CPEaNSQzvIjhrf2o73tJuzUIZzquGdT1SMh1l7QcQXOFvekAY/2CTvrbMrdvT1sbW2hUqlgcnISk1NqOzPHqkNASR9zrjOOOhAIYGJiAqdPn9aiW/VmA7vZfWTKOVSlqg0QK+FZHl6nF79/9XcxPTClsWGkUiksLi7ivffeQ61aNfI+tXc6QrqhTsuiQINbodMVpFuHRSxyG5qvTU3c0SY9oXMNtJ20b30UgaXW0XsNnaebzSZE0YF4PK7NOqea29LVPJ2bP44l2HrHAPopRStnJJ1KY2N9Aw8fPoTf78crr7yCH//4xwiFQhAdjh5fqOPycSwLl9OJH/7wh3jttdcwNdXlKcuV87ixdBPVRuXXngt5bn2QAX8MsyNnEA/E4WizKVJKsbCwgM8++wySJKnjw/SLyRB5oVbBqZ5dkPbZVanVzmu1gGm36JEwDASeByjQkBpGd79nWgG11ha0//lkWYYg8AiFwhBFBxqNBlpyq2fUgj6bbp5k1UN1qnd1SG+5DLX4/LR7aP+xUqlgZXUVFy5cQDAYhMPhwJ//+Z9ja2sLe/t7GjkEIQw4loXP70M0GsXw8DBefvll+HxdOtmdzB4W95bwZHfR0PtjA8SU84j5o5gbPguX6ALT5s3NZrNYXV3F5uaWZsM+2xZ5gkDq59mw2uBwOZ0QHQ7ILRkNqfFsfeInmESgKDJYhoXL5YLD4VBHL/QhgX5WrvgvknJoNOrY39uDJEnaFN2LFy8iHAljcGjQABCe4+Dz+9pDUeOIxWJaKXy5XsHKwSqWDlaRLeeei2lUzyVAfE4fxiOjuDRxAUzbvmk0Grh37x4ePXqE7e3tni2Q6lttrZqYaB/aQHp0SkSXwtAHhnoWFcuyiEajcDicqNVqaj0Y6UMGpzsgocSKKahnCA+BWrrBMKof4na724QLjV4taAohWzKwwFiLRfRRp46DTq3IsHulVqtjZ2cH1WpVG1kXjoQRjoRx8eLF7mBToG8LbrPVwnpiE//f419i5XD1uRnV9lwC5OWZazg3Ogtfe7h9vV5HIpHAP/7TPxnHm/XpX+jJPtM+dgvtR5FDjAFi3dBN/UqjOsde4AWcO3cOu7u7KBYLfc5LDGFOLWbVk/fotf8oAJkqYHkOHq8HbrcLpVKxW2RoVV1DcUR/PjGcJhqNoV5Xyfi6JAzom03Rc4Spcx3VEdKNRgM8zxv68K06CjWzUZGxm93D2uEGfnr7H5At59BoNp6btfhcAYRjODhFB6YHJjHgj2m7TTabxdbWFhKJBCSpYb3bP0O/BNMmM5Mth7hYRIOOmdPH8zzcbhdisRi2t7dRq9WPsJe+gDFD1Wvneb49tuGLf31qyTuDWCyGbDZjmHFy/LWStumnoF6vo1QqoV6vw+NR+0OKtSJKtTLK9YoWlgbaFExtGqdCtYidzC620ztIFdOqT/UcsaA8VwDhOR4hTwjTA1OI+qLa84lEAqurqygVS+hxMS3jmf0qAdUFyrAcGIaBojR0moEcGd61JqZWjyeKIrxeLyKRCJrNliWBwVEegr6d91hwtx1dp9PZblo6asScVRTC1HhLGLAsg8HBOJpNSR16avo8aZ/ZiAQMKBQoioxGo4FCoWC490wpi530LnYye2BIl2GxJbfQVFQap63UDhL5JHKV/HM5Afe5AkjYG8K3z7+JiC8EkRdAKUUmk8Hdu3fxi198eESoiaCHx4aaWQgJCEMwMT6BSrWCaq0KqVE3NWwfVaTeJ9NIKUZHRjBzekarD6vX693QltkJIeZySUaXuTe1XVEzZSiBoshtzuCmOsbMUikdSRff3RAIAc8LcLtdmJycRCqVQkOb76h/dT86I0U1waian1peXkEgEMDY2BgICDKlLJ7uLeNnC+8eqRWf53mFzw1AWIaFW3RhODQIjule1tOnT7G/f6BywdJuiQRFb37BuhxEtaGDgQCisSjcbjfqjbpmZxNynNlDulRbVgzQBIjFYhgbG0Mul0OzKaG3jpz2Ma5ITxXA0cYc1dhAOE71RQAgEovApZuhmEwmkclkkEqlj41nuVwuDAwMwOFwaFO20DOt6pgyhPbfs9ksSqVyO2JFtB+bOO5L8T9YuAQnot4I2HZDVKvVwtLSEhKJhLorW5goJ7HqnU4norEoTp06hXQ6rdZyNZtH+AbE+sgWTwk8j2gsiqGhIdy/f18lnbMMF1ED+WN3nt9JwdGtLuB4DsFQEDynTo6dmJyEv81PJQgiNjbWsbm5CUVRkMvl1X7yPkd1uVyIx+PqQlZUBnyLqc84yXBS1QepGa6XMAQvsjw3ABF5B1yiG26Huz1xVrWHb95Uh933DzJar2eq0ybXX76G6akpjIyM4H/93/53SI26xa5mHk5JdOFcqrPYulfBMMD4xDimpqYwNDSEv//7/9J20DsVtlQXnDJpEtqdQ24AjX72uP6eKQHLsZq/86//5E8gCEJ74q7LdC9v4uDgAGtra/g//uN/1GakQzdAp6NtQ6EgZs/O4vDwEJV2Nx+lxohat8ARPYlGw9RESvECK4vn3cRi2vU7jMrLVK8jm82iUMij3qh3w4b6L4v0MYnar3G73RgeGcYbr7+BdDqF9957D41GQ2e7m0KY+gK7rgWlUWkaYaS+YL4969DlcmF29ix8Pi9SqRT29w6QzeUgK61uZS/RObqGIuFuXQrROdbExJ9LCKOxFXbyDf3yCqFQCKIo4o//1R/j1q1bePz4cc8sFVEUEQgEMTg0iI9v3EA2m+sJjbddlXbBoXGSlznj7vV64XQ6DSHdF2nc2nMNEL3NCoL2nPIK6vW6oa/5pCIIAiKRCK5cvgK3243NzQ2sb2zA43ZDEHgwDINCsWTRZEX6u6bUeL0sy2FqagqBQACiKGJmZgaxWAyZTAax6A4ePnqkjmeoVa1NNFMy8sh5Z+0Qb+dHEARQUMiKgmq9jFqbYM3BO+BxuCGKIgRBwKVLl5BMJpFIJJA4PDQGRSIR+AN+8DyPg4MDlR3xC4jf74PL5TTc04s2cu25jmLppdVsoVqpqOXRisXuTfv5juru7Pf7cebMGfzxH/8r/OxnP8PS4hIKuTzOzZ9DJBKBKIq4d+8+UumUMeoEi+y3iSqEQC22E0URs7OzWv3R9evXAUCbofg3f/M3WHy6qPJKaYuG9ji+1HRwqmOtIxY+SEdrNFstVKUa9rJ72EptQ6EUo+FhzA6fgciLIIRgenoKFy6cR6VSwTuJQ8N9zM3NYSAWQ7FYRDqdMuSF9DVkBj1mlVttPx4YGNDogNT8iIyWLNsA+SqEQk0m9bb0WDTMmmeQUeD69Wu4evUqXC4XTp06hbGxMfzgD/4A4+NjaDabSBwmcPPWre7wFwKDrW2g46HoCX2GwmFMTk4gFouB543kaBzHwe/344/+6I/w0UcfIZfPI5/LWXg7JpBbsUDqvGVBECCKDjgc6i5dlarYTu/gL9/7T6g2aqCUQuRF/Nk3fojpgSkMh1RittOnT4NlWdy4eQP1Wg2Uqhr2+rXrmp+nKNRScxHaX6t1Lo1lWTgcDkxNTRkmd5XqJaRLGRsgXzVU+j46wmTx+fyanR6Px6Em9AQEg0Ec7B+0J1NV1SGTJ4wi6SUQCGBmZkad38cwUKiCUq0EgRPBsRx4lkM0GsXg4CBGRoZRyOcN1cdH25vmMDXVFqL6o2oQWZbRaDaQLqkZcEopGIbB491FiLyIuF+dA+/1ejEwMICR4RHs7u4AAIaHRyCKAvb3S9jc3OgJWlDax8WziuS1zdlQKKQFDOpSHflKEbly7oUGyIs9vEG385pNEYdDhMOh8r7G43HE4wMIBoMAgFQ6hY2NDZRLZbRacm/BIrVSUcbjh8MhzM7Oag6prMhIFdMo1UpaLZHD4UA0GsXU1FR7pqL18fpOkKJ6b4hq5lXHV1OogpYstyubadsnkfFo5zG2UtuQZEm7jmAwiOnpabicLrhdbpw5cxqtVguZTBpbW9tHfbS9P6bSG1EUMTQ0hGAwCKdT1W6VRhW5Sg6ZcrbNWk9sgHxhR123dFwuN+LxQbhc7hNMpDXxglCKdDqNdLqX07XRaGBpcQm3b39yrN6gxunrmkxMjGN2dhYXLlzQhokWayX85MZP8d8/excLmw+113o8HgwPDx9dzt4HoOYrYlm1LKTjg0gtCTWp1lO/tJfZx+LeEu6tf6Y9LwgC5ufPIRQOYSAex5tvvokPP/wQ9+/fNyQHj76w3k2DEIKBgRi++93fgcfj0TaMvew+eJbHeGQUF8bncW50FuPRcXAs90KB5bkxsdTiNUUjgHY4HIhEVDt/d3cP2WzWlEsgfXd4UIpMOoNMJmN6mmJ3dxf7+/tIpVNH2DWmAZqUGtpmZ2ZmMDQ0pAG32qgiXcpgO70DAoKAy2/IJndrpvqYjwTWfzfNQuA4DhzHaROxOrMbrSRXyWPpYAWvnL4OBl2TbHx8AhzHoVAsYm9vH7lc/gizlvS1q2jb5xsaGsTU1DTGx8cNvljMH8VLU5cwMzgNQhg1aVnJY2l/GZ+uf4aaVHsua6+eW4DIioym3ILUaoKCQhQFcJwfp06dQqVSRS6XO7kNDyCTySCdTqPVamnzKSil2N7eQSKZ0ErS+1GqWarb9mKfnp5ut72qC69YKyGRTyJZSMEtulCoFTWAdPIWx/lWRxYcaufvmlha/KtPZq5YK2ErvQ1ZkUFYFaiCIGBiYgLNZlPdJJIplEtlU7acWG865s6Q9mcxPj6OU6dOYWBgwJD/CHmCiHjDWpGiQlWA+F0+bKd3kSymUG1UbYCcVMr1CtLFNDbTW/C6vG0OXgZvv/02KuUK9vf3Ua1VrYfLUBNnASHY3tmBPxDA4eEh4vE4OI5TW3Y/+wzJZMqQJbcyrfTDOjt8VS6nC0NDQ7j60tW2469qvo3EJj7bWADLsGjJLUitBiS5CZEIWoTHMDijH06IPnjaJpqj3ZIUWZbVoALtzlps9SF3lloSCpUimnITDGEgiiKuXr2KVCqFRw8f4e/+7u9QKpcMnWC0wyqpb+IyjYXvXDDHqQOMfvu3f1tjJDE47pxgNA8Ji4g3jNfOvop6s4E7a5/i9sodGyAn9rUpRa6ax521ezgVn9aoRePxOM7OzSKXz+OT27cNQ2k6S4dYzEhvNBpIJpO4e/dTvPXWt9XISr2O7Z0dtaSb9tJe9Zuk1jHpQqEQ3vjmG/D5fWC5rpkzFBrENXIV03GVeCDsDWmLmGVZtYGoM6XKouxLnxHpyyQCAsIyYNobh9HU6ZWYL4pLExcgcqLGYSyKIh4+fIh79+6hWC63k3g6+tGOZrKozCS6T4LneYTDYfzRH/0hJiYmNcfcYOLl8jg42Ee+UMBAm1iuE+GaH51FuV7CdnoHh7mEXc17Uqk2alhLbCBdykDgeLhFN1wul1opm83iwcICGk1z5pv2Bubb9napVMLK8jJef/0bkGUZ6bRqdhkGd57wu/H5fBgaHsLc3BycTqdhkQbcAYiciPHoGBrNOnhO0P7e0SAMw0Ah/Uci0xNEfDsh3u65rZ3oiDeM8egYZofPgGVYrUo3k8lgbW0dm1tbaDabvdrTNNoBtJe0R43gRTA9PYVz584hGAxovpi+i3BjYwMrKytIJA4xPDSsZfY5jkPEG8ZIaBjTA5NI5JPPdbXvcwaQKtYTG1jcWwJDGEwPTAIApqemIAoC3n//A6QzGdTrdUNzkVqnpN/n1L+Vy2U8ffoU1WoV9Xodjx8/QTKZTMgLYgAAIABJREFU1CpW+4PDOH+cgGJ6ehoXL17qMSdYhkXA5UfA5bc8kiAI8Pv94FkOtDMOgBJDIWNPv7h+ECnp7vACz4Pn+a6Tbs7Ct+Xy5CVcnb6Ml6Yud7mm6nV88sknePzkCfb29nWMi7oZPT0ajBpogEDUmrnz58/h61//OoaGhgyajOqGDL3//ntYWlrC7u4u/D4/ItEIvD4f/D4fOJbDWGQUr89+HZ+sfoqm3HxuQfLc5UEopfjl05t4uP0Y1UZNi+MPDAzgO9/5DiLhsPrlwshhRS16kprNJtKZDPb39/H06VPcuHnDqH30JHOEdHmsdITNDEPg9frwtVe/huvXr/fY2oqioFAoIJVMWX7JoijC7/cjGAy266eMmXRKjwj9kt7tXd/fLctye9xDV3O8df5N/ODa7+Li+HntddlsFktLS/iHf/hHJBOJbt7IEE62JhDTRwsZhsFv/dabeP3113HlyhWDv5MuZdpJV/U4LrcbLMdBltXP51e/+hVu3bypvSfoCeDs8BnMxKf6bi42QPpIspjCTnoX68lNLTvscDhw9uwZRCORrs1Le7Mh+j21U/KRy+VwcHCAvd29o1IplgqFb0dqhoeH2oyGRjCvr6/jzp07+OiXH7X70Wum3IVqYrlcLnA8f7JNAqZFSztglKG0aTv1t8+xHCaiYzg/dg5Xp68g7A1pXGLFYhGLi0u4c+cu0un0yWY4WrAtsiwLURAwNzenjWEDgGw5h73sATZTW2gpLQ1Qk5OTCAaC4DgOsqJgc3MLa2tryOfzUBRF5R8QHBiNjMLr9Ngm1rNIvpLHdnoHj7Yfq3Y0UR3DmZkZxONx7O/v9yxEKxFFEYPxODKZDA4ODpFIJGDmZz6Cpw2EAIIoYnbuLAbiA/B43D3nWFh4gE/ufIKDgwO4XC44nU6tO09bWKIIl8ulTr/qqXEiRzupulSJLMtoyS2tulntLmTg4B2YHzuHi+PncW36igHAyWQK9+7dw82bN9v94laRCGKiIuotJOA4lY9rbm7OsFEc5g+xlz3AYT6BM0On4RTUg5ybm8PS00UIgoBWq4Xd3V34fD4cHh7C5XJBEASwDIvJ2AR2M/sAdp9LgDy3QzyrjSr2cgd45fQ1cCwLnuMhCAJ4gQfDslhcXLT2aHXffzwex7fffgv379/H1uYWyuWTEyETAB6vF6Ojo/jxj3+MSCTSk9FXFAV/9dd/jZ3tHWSzWTx9+lSbgdGh8e+YRI8fP0ahUEChUOw2GZL+Fe7m8SQEQDAQxOTkFGZnZ9UaMMIi4Pbj0sR5fP3sq5iKTWjALJfLSCQS+Pf//n/BkydPkMvnrJsmT/hh+LxeDA4O4vvf/77W81Fr1vH/3PovuLF8G8lCElenrsAlqAEMv9+PfCGPSqWKg4MDtRyGUkhSA3Nzc6oGIoCDF7GfP8BhPomm3Hzu1uFzW4vVlFso1yt4ureErK7gbXR0FDMzpzA0PNRbgqIrFAoGAwgGAyAAUskkisXiM9gV6qPx8XFcvnwZfr+/b7lLh11EUWRUKhUsLi5qNP/myE+nCpf22P/WJpbZ0mlIEiSpoVHzuEQnwp4QxiKjcOlGm6XTGTx48AD//M//jEw7qGF5wBN+FqCALCvamG1Ng0GlalIUBZlSFvu5feSrBe2eO4N1OlKr1bC1pW5UahSNwCk44BKcPfPSbYAcI7KiVqou7i0hXcxAbifEIpEIxsbGMDk52VNmrh/VHAqF4ff7UalUkMvlUXnGZiCXS2X6OH9+Hi6Xq082HAj41WYpdXeUsLq2hpWVFZTLFUNAIBKJwOVy6Zx8imflOa3X66jX24QTlELkBHidHkS8YQicAFmWUa1Wsbm5iQcPHuDjjz/WFuMXlVarhVqtjlqtpgGUIYzanMWLKNZK2MvsI1fOG0Lj0Wh37Fqj0cDBwSGKxSIaDbWgU+AEiLwI0ZRYtH2QE4hCFfzy6U0E3SHEAjGtfHtwcAg/+P4PsLK8orbQKoqh4YllWZw6dQpOpxMffvihgavJyIZiXc9FCME3vvEaXnvt67h06VL/3YVhcOHCBWTSGezu7IISYHFxCbVaDX5/AG+99RY8HjcIITh79gyePn0Ch+hQ/SdLou2jRm8S5PN5LZejn/fXkVwuh/v37+MnP/m/kUqlTuSnHZ99odru32q1cHh4CJ7n4XK5IPIi5sfmIMkSNpKbWNh6BI/Tg5nBaTXAwfMQRVGLwEmShFQqha2tLbjdbng8Hh0tqR3m/VxSb9axfLCCu2v3dLu7E1NTU7h27RomxsfbMf1uCcTQ0CAkqYFUKoWDg0MDW6DeTaEWBo3L5cLg4CDefvttjI+P96XM7MjU9BQi0Qgc/397Z/Yc13mm9985p/cFvaEbSwMkVpIASFoUKVIUJcuy7EnKFU8yrtiucuVCufRN5r/IVOXGVfkDkqrkIi5nMuVMlJmxLY+WUAslcxWJlVgaa6N39L6eLxen+/QKQnbJFij3W8ULsAmwcfp7v3d73uexWvUFp2gkyj/90z/y3nvvsrq6SrVaZXR0lLNnzzJ+ZlxvDoiOVnNb7tXiyqKFwTCdTrOzvaO3lIUQlEol7ty5w9tvv83f/u3/IhKJtNCHip5JW/sERZzoLEJoUJfFxcU6cFSzMW+QicEzOCx2vE4PdrO9rYXdmCc1ofKCcrnSweB4eu3UL0zV1BoHyTB2i51MIYvVbMFgMDAw4OTixYsUCgXCh4fk8rm2xaJEIkmhUKhHj84b+vgK1eVyMT09zeTkZFs3qufRkST8fj9DQ0P4/YPs7Ow0c+3tbe7du0c+X6BcLhMMBnG53IyOjrK6unpi2n+cZbNZdnd3NbWmOuXn5uYm9+/fZ3l5mc2NzT8SdEOgqirr6xtMT09TqVQwGo24bAOMeIaZHZnhjG8Mt70506hUKhRLxZ6zLp4T9pPnQqMwnDqkUquwGQ0x6T+r981feeUmtVqVnZ0d1tbW9FsumUwRDh+ecEv12koQjI0Fef3119t2G55lPq+X2VmNb2tnZ1ubkgtBVdT44IPbLC4u89mnn/FXP/g3mM0mZmdn+eCDD/SuTnsS1SlkIrqYH5NJbeinsSuWiUQi/PznP2dlZaWuSd5KOiF1sbO3OqTULnnVnNofs7EhhMqTJ49ZWJjnwoULGlmF0cyZwTP84Ppf4nf5cVqaESSby2oo7I4s0mAwICty30G+zFoknU/zi4/+jh/d/CvOjcxgMVmwWq1cvnwZ14CL//g3f0OlHrrT6XTHVLuJkNXa/S3wwJai+dzsLJcvX+bq1Rd7TswbdUenNbTCV1aWOQxHKBQK9cxJkEolyGbTbP/nbQZ9PswmM7IkIyRVT3WOT21Ei0Co9lfJZJJcLsfPfvYzcrkc6XSarc0Q5foWYxuyuU16WmrfcZc6msgtww+pgziu9XCnUkcsLS3j9nh489vfBsBusXF+dFbHfQHk83merq3x4N4D/Vk0mGA09hObHk20vRbRd5BnloUn3NZVtcZeYo+18FMsJgvnRmaQJAmXy8Xk5CTz8/Nsb+8QjUS6tdK74kTLHVmf1BsMRi5dutSl1d3I8dfW1sjl8zjsdqampnQAImj8W8PDw9y4cYPPPv2Mg4MwhTrDYAOiXiqXqZQrmM0mjYzixCxD9PyrWq1GsVhkZWWFUqnc5AKW2uEr0nFFdwsVqLYno4EfO1nzW52klUdOrans7Oxgf2hndmYGv9+P1Wptg7cLIXT14XhLvSLXSbftdjsmk6l++QlqoqZ3KfsOcoxzaPT4x5Ak1zfnkrlUnZDAom2qIWGz2bDZbFy/fp1SSUs52tOHbsVwaOe2luXmvsTU1FRblFBVlXw+z8cff8xBOMzw0LDOZNL4d0ajEY/Hw5tvvkkkEiGdzZAv5ussjEK/hTOZNA3y9IaKYi+mYYnWVKdJ4FanXgEEe/v7bWKIUsfBFo1Lp4WpUXe7+t83NxQNlEvl9myuJciIDr3D7e0dcrkc8/PzOnqg9bMSQvDpp5+yGdoinUkj1YGRiqJgs9l1FSpAd47T6iBf6SRdkiSNzl82oMgycv3rZthV21CiAAfJMLFMHIOsMOIZxmjQZiHT09MUCwWy2SyxeKz97hRdgrP1gyVhqMsQ//BHP+LGjRttvE6Ngvv27dv89rfv8ujhIxaXFjmMHCKEYHJyUt9UlGUZj8fD/Pw8kxOTxKIxUulU84MXnX20VjrPprO0TtmbbS6pY+outU3b24NEyyuSaMukGj/OoGhy0n/91/+BV27dYmpqivv37rWQX4i2RnjnH1Wtkctm+eiTj9nd2WVnZ5dCPs/q6hq3b9/ml7/8Jb/61a9JtjA1Skg4HU5mZ6d54403dF3Cg1SYR6HHrIc3+vIHx0eP5u1TEzVsJis2kw2HxYFBUdoEmIrlIl6HW4NId8wkDEYjJqOp7UAeyy/X6HgZDTgGnExMnO05LRdCUCgUUNU6sYGAvd09oodardE+/NPSrYmJCb73ve9heOc37O3tEY1Eu1nWWtKhXkrqbUtUdOKjRPe/FXSTgorun6mRYQxx5cqLTE1NoSgKPq8Xl9tNLpejVCrVnaqHunuPsiW0FSKVSvF0bY1KtUo2m20qbHWktWaLxn5iNBr1iyWVTVEoF6ipp3M/3fDVO0f7DociKQQG/AwODOIf8GMyGFtuW5lMIYPFaNaZA1tv+kql3DtUS8do9KFNgzWFKHvPAlwIQaVSbatropEIsViMbDaLzWZr26OwWCwMjwzjcrs4jBxiNBgpl0pkslmE2kIE/YzuriQ6i+gvNtxrCzodP1ySJKwWCyMjw5w/f57XXnuVYDCIJEl4PB4CgQDhcFifcH/Bzi/hcJhwONyyNyJ6OLl2gVltVsbGxtsWrBLZJIVy8dQSOHy1DtLCl1Sr1bCYrIy6R/h3r/6YMV8Qr9PTdWjVFir/1tfef+997nxyh6XFxV5Qot5fCM2xtrdCvP1/3uatf/8Wbre77XtlWSOKNhqN+iHI5/NEYzG2tkL4/X49h5YkCYOi5fVOp5Of/OQnrK+v8+DBA/7Hz39OsVCkWqlwrIu0+kR956WV6b2XnKKkd2nFMyc8VquVmzdv8t3vfpfp6SmdIwy0tuurt27x0ScfkzpK9YA10xPL1Uq2JI77nkZkddgJBoNcv/6SDpUXAjaiWxzl05xWOxVFelWt4XV6mfJP8MbC65wNnMFutvXsbEmyhKSvgkoUCgVyuRy/eecdwuEw6jHdn85PTjSY1oXgKJ3m7t27XL9xnenpaYaGhtq6OQ1C7WbbWetsNQCQVbVGppBhcXeZcyMzeB0ezEYzsiwTDAZxOp0YTSaWniyyvr7O9s5O7w060RrtOgTPxPGivKINOt/+CweDo8zMzDA9PcONGzcYHPT1kEuAay9dI55IkEgkCB+Ej31+EsdjHtte60jvLi4s8MILL+B2u5Flmapao1gushPdJVPI9B3kuO6UkLRezbgvyIXgOS4EzzFgcyJLWnSIxmJU6gzsDZLoBnCwWCwSiUTY3t4mFNqiVCr/Qe+jgRF68uQJRqNRZ2tvRKx0+ohqpdrBxq42WecFlKsVlvdWUIXKmHeUcd8YZqMZu13bq3/xyhXsVhtutxu73U48kSCbzZ4Movw9sixJ0qJq4/90OBzMz88xOzvL1NQU09NTzVpPrbU1SkZGRjh3bpajoxTpIw1MWPsSiKcVRcHtdnP+/Hlmpqf151ooFohl4sQyMQrlYt9BnnUADIqBa1MvcmXiMh6Hu/kh1mrcvXuXWDRKtVrllVduEQyO6rsWsViM+w8e8P7772sHTXyRNQfRliI00pNqrcZvf/vP1Go1zpw5o0eRcrnM6upq10HW1Ga1x6fIMkKoPN5ZYi28ztTQJH959XsMuQIak6AkaTis8XFe++ZrrK2t8f77H7C8vMzqykr7OxO9C/FedVSz/VsvmmWN+2pqaorZ2Vnm5i5w/fr1tj32Rmu1WC7WBUENmAwm7HY7N27cYHR0lFAoxMFBuKcYqeg9XenN1irAbDZx5coLvPzyy0xNTekvx7NxHm8vEs3ET5xb/flGEE0jFZNswmK0YDZquWmlUmFpaYk7d+7wm9+8Q7VaxWAwsLGxyfe//69wu92sra3xzjvvEA4fkjpKnaBs1FuvvPMTTyaT3L79IdvbO/zFX3yXdDpDOBzms88+6xGdJL0GahC4ybLMYSpCOBVhaXeFf/nCdzg3MsNUYBJFUfTV4fPnz+Pz+Xj48CHhcJhMJnPyITnm91NkBa/Xy9WrV5mcnGRi4izBYFAb3plMmM3tzYxw6pD1w03ee/L/8Do8XD57kZvnrmvQdYeDyclJfvrTn/KLX/xPlpeXO/ZoOhgnnxU5ZIXZ2Vnm5+f54Q//LQMDA/rzimcSPN5Z5FeP3tGlLfoOckyK1agDWj/EXC7H7u4uDx8+IlFnVDQYFEKhEHfu3MFqtRIKbRMKbZPL55rpj3SyQx5PMKo1ClKpFNVqlQ8//JB8oUD6KN29qkqT76rN2dUaqhAIoVKuVtiN72MyaKulAZcfs9GMUdEg4IODg3WE7xmWl1e+wK54LzpQ7X0MDw+zsDDP9PQMfv+gzmrfsGKlRL6U5yAZ5ml4nc3oNpuRLaLpGAZFwWlxcOnMgu7AZ8+e5dq1q1itFp48WSSZTLalk8c9Z1mWsVqtOJ1OZmZmOHfuHLOzM3i93rrstkqpWubR9mNW958SzyRONSfWqUixGg9IbRkIptNp9vf3WVlZ0XcFNF6rGO+++y6qKshkMm363b0PUUuBK2s3fgNJKo6hEykWCxSLRd59971j0wlA0wvUuzHNoabJYMSkGBly+Yln48iyTE2tYjKacNtcOnmz2WzG5/Nx4cIFNjY2KZfKvel5W/FR9ffYijgwGBTGxsa4cOECk5OTXRdQQ5bhMBXho9VPeBh6TDQdazKRqBozytzYeQyyQR943rp1i8HBQTLZLPl8nlKx2I6X6lxtlyRMJo1QbmxsjO9///uMj48TCDT17svVMulCmo9WPmErsq2rYvUd5ART6wx/jWfucrkY9PsZHhkmvB9Gre8VFEulZp++k+dH6tj0aMGSOJxOLl++zM2bL3P37j3W1tbY29vr4R7S8Ze31N4y9bjdjNTVYWtqDaNi5NuXvsX00BT+gUEGnV79tVqthqwoGGQFVVV1pkOfz8ebb77Jxx9/TLFYpFqtdGX2UgtEX+p6r4JSucyDB/d56aVreL1eHQmQyCY4SIb59aN32YnvcngUoVAX2Wm9tXfje+wnD3DbXFybvsK50VlAk7YeHBzk2rVrfP7556yvr7O6ulZXCW7sotRw2B24XC5GRka4/I3LjIyMMDw83LWBeZRPs7q/xt99+vesH25SrpZ5HuxUOEgTWtI8gBNnz/LqrVu8/fb/pVwqU61V2yRhOwUku1InScMa2e12XvvmN5mbm2PuwgVcLjc+n4+lpSVWVlZaYOeiSzbzOHWeoaEAgUBAP4wGxYDD4uSFs5dw2VxYzVaMipZ+KZKCKqsgSchIbamkyWTC79ckpAuFArFYrB1I2ZwaHptyqXXeqd2d3bb31OhUPQ2vk65rlvQaxon6nse9rQdIkkS5VmFhfE4n3jabzRqFj8fLzMyMFrnrarZCqBqLi9mC3WHHP+jHZrfpZOFaC7xK5CjKw9BjVg/WOEiFtc/yObFT0cUSQqVUKVOulvSDEwwGuXbtGnfv3iNRb4lWK9WOtuZxcmxgNJlw1rU5bt68ycTZswwNDREIBDAYFEwmI8lkst7SLOofWm/6n1bslEQwGCQQCOjdNEVWsJutuGyTbQ7fIDio1WptjiGEQFEUDAYDDoeDM2fOkEodEY/HdQZ76VkhTH+fEqoQ5PN59vb3CAaDnD9/vn64FQyKkUQ2SblafiYYUCB4Gt7AZNCEQYPeUawmC0ZF634FAgFdWq1cLuu/nxACk8nUwTivRfdStUylWiZXyrN6sM7djftsRUKkckc8T3YqaH9UoTJgc2I1WjjrPwNomKaRkREmJyeQFZlcLs9RKtlMgyRJpx9tLgYJXQ12Zmaal19+mbfeeotzs7M6OM5gMBAMBllYWGBmZoZ8IU+hUNRkAFrGbVI3BBZZVjCZTPzoxz/mwtycfls3ZAlai/1cLseTJ09YXFzk3r17rKyssry8wvLyMp9//phoVOMIHhhw4vV6KRaLrK2td80e2viz2gQ0JR18KYQWmRr7MZIkYTFZ8Do8rOyvUa6Wv5DUQDQdYyOyRTQdx2QwYTKYcVjsXc2JBgq4gWhufVaajEWF1YOn3Fn7Hb/9/F3+9+/eZi+x/1zIHZzKFAvgyc4SpUoJu8XOwticjrWamJjA4XBw9cUXefjwIU+eLBIOh0kkEggkZFmq6/A5cA248Pq8fOMb32BmZpbh4SEGBwd7MpIYjUamp6f5wQ9+wMbGBh/e/oiHjx5RKhabNY7Ukv1LWmr1yq1XmJ+bw+fz9fw9Dg4O2Nzc5PaHH7KzvU0hX6RcKWsO3WgJqwKzyYzT6WRkdATfoI/9/X2sFotWY0mtVUazIpZaNg0bsgiNWiwcDrOxscHGxgYTE5Oa1LUkc3F8XhP4Sce/UMeoXC3x+fZjwqlDAgODTAbOMuQewqgYdaK6zugqhDZHShfSpPJHJLIp1sMbZItZcsUcNbV2qgmqnwsHiWcSKLLC/c2HeOwe/AM+HBYHTqcTm81GIBDAbDZjtdrY3d3l4OBAn4+YzSZ8Ph8ej4fBwUEuX77M6Kg2UGx8gLlSjnQhg8Wo8TCZjWYGBgawWCw4HA7K5Qr5Qp54Ik4hl9fYUuofqtFgxOfzMjU9zbWrV/H5fE08UUvNUKvVCIVCusRAMp6oyyBLHazp2pcmk5mD8AHBYJBsNtsyC3lG/0zqfdBy+RyxWIzNzS2CwTFMJiMSEiPuIRwWO7IkUfsCh7SmqiSySTKFLJGjCIlckmHXEEbDMQ5Sb9NXVc1BjvJpkrkjwsnwMwV++g7yB6RZh0cR/uH+r7GabXzjjKZr1wjrdrudK1eusLCwQCaTYX9/n2wuh8Ws3cSBQACLxaJvqnX+7N34Hg+2PmfMF2QqMMGIZ1ivd8bHxxkfH8fvH2RtbY2n6+uED8I6n5TH4+Gbr73G3Pwc8/PzXQ2GxlVfKpX49LPPuHv3bhPiXk/Z9Bu/ZYe1XCkRi0aJRaOdJVT9Z7esAhyz+KURWmuFduooxYMHD3nppWvYbFaQNKUnm9mGQTFQ+z06R5VahWQupS2p7Szx52qnaie9sQ/yj/d+xfLeCgu7c7x24RVcNhd2s01PjdxuN06nE1VV22TOOsGNjeHYhyufsH64wcbhFkbFyPngOeaC5/jW/Dexma0YFO0xXL16lcuXL1OpVJoS0QIcDrs+me4cvg1YnciyTKVcYW1tjc2NDY0DuMUZGqQFoqeaVXeDoRk3xDFQ5PYd8gbsN5vNsby8SCwW0wmz7RY7VpMVk9FE6TlprfYd5ATLFLPsxvf03DXoGWHIPUTA5cdi1BSTZEXWmTEkJCq1CuVqRVd+TeWPiGfibEa2WNpb1SSai1kkJDYjW5QqJSxGC+dHZxkc8GE3a07QWB8dGBhoU4httUg6Sq6Yp1Au4LINIKEJ1OzvH5DN5Tq6bb/vXkd3FvXFvltQq2kLS/l8nnK5rDHKywbteUly/7R/XRxEG3QlSWSTbEVDnBueZXZkmqvTV/A6PFiMdWYQ0De7C5UimXyGdCFDJB3laXiDnfguawdPqbTIJAsE4dQh8UycZC6JVI8+VpO1Y0JtaE+jWlqi29Ed0oUMlVqFuaDWVq1Wq+zt7VEoFNojhU6c1lJutyx6SK0AGB3u3rob2Gu1SjRRii3E7EJVKZfL9eUxLT2UZVkT0nxOdcr7DnKC5Yp5HoQe8TD0OX//u3/AYbFrBWPb0ZIoVUqUqiVK1XJTyEUcT6tTqVXZioT4L//83/APDHJxfJ6gdwSb2YbVZG1zCknSYO+ZYo7d+C4fLH3EmHeUa3WpgQbzyfr6Uwr5gvbepPrhl7qjQlu7VmqtLJoUDqKzPhcd+Zdohdlog7taTdVa1tkcxWKpY9Ih+qf9eXUQCam7YdNyuBvwiEqtQqaYRZHklpVUSe+/N/580c6JQMMHJbJJnuwuEYpuaxuBiqEDyqJ9WalVyBSyFMp5BKIrbVFVodNt6jGjg8xR9Cw8Wg5xB4KmXVCz7g5Nid42AKYsy1isFux2G2azqfcz7ttzGkGk7q8l0S4u88egh6mpNbLFLNli9vf6PoEGgGxGmWO2zFv2y8UJP++E/013Mi1Cde+4KopBX5RqLCb17Tl2kJ6R4wQnOUUtN31uofN6Sa0pTWc07LgLpN7MI+3f1rolJdp3XjpTNrTlpAZvl9Pp1Nu1VbVKTdT6p/3rWIN8KQ7YkY1/GaYKtS2aSZKExWJFaXDOSs2TK8sy3/rW69psAnj69Cnh8CG5XO4E7Q7RFWR7UjMIkGUJn8/Hq6/eahuQxjJx0vkMxXKpf9r7DvKny7lb97obDmK321GU9kcqSRIGg8LFiwu43ZqmuNfrJRTaJpFIkEqlyGWzOpT/D9kDlySJQCDA1NQkc3Nz+hahEIJoOka2mKOqVvunve8gJzuHxJeTsglog48rioLP52tuGdarcUXRAI4XL14iEPDjdDq5desW4fAh4XCY1dUVlhaX2N/f5yAcfiaJw3F6HpIkcf36dV566SUWFhbaouVWJMRR/ui5h3z0HeQ5iRwNK1dKHOXTOhargabtBYyUJAm1o7vm9w/i8biZmZnmO9/5DkdHRyQSSRYXn5BKpTg6OiKZTJFMJslkMhwdHbVFF5PJhMvlwu/388Yb3+LFF19keHhYfz2eSbCX2OPj1U/JFnP9k/48Oog4VonidDuHVvxWyZVyOhZLkjRGkU64SyOCmM3mNudRFEWXiAYN3q/RDZnI5XLk83lyuRyp1BGZTJp4PE4ul0cIFZDqIqU9nQhEAAADgUlEQVQaOPPSpUv4/X4dQJnMJVk/3OBR6DHpQua5WlDqO8gf2Un+dA5SIVfM16cX2v5IK+N7qyM0cFGN6byKqrdrGxHGbDZjNpvbGA+FEBSLRbLZLNFolFgspi9fjY+P65i0ViiMEIKD5CGPd5b4YOnD52a1te8gJxS8x0ofnNIJcEOFV1VVZEmui4uOYLVadQYP0Lh6vV6vXqBXahW2Y7vc33xIqVpmemiSmeEpHBYHFqO5KzVr4MN6iXZ2Rqt0IcN6eJP/+t5/J3IUpVgp9k/416UGed6gEDVVpVzVGB+FLFAUA4GAH4/Hg91uJ5Np0mnKcnMXXVVVUrkU64cb2gbf4SaLu8sMWJ04LQ4GbANYTRasJitehxeL0YSiGJAlqSudVIVKVa2RK+aIpGPsJ/Z5tP2EZDZJpVbpn+5+kf7VpWs1tUaxUqJcraDIWj3h9XrxeNw4HE0H0WqQZmRQhUq6kOYgGWYrug3ARmQTp8XJgNVJwOXXHMXqZMwXxGF1YjaYMMhKV/SoqlVK1TLxdILNaIhQdIfHO08oV8v9rlXfQf4wJ/myIlWxUiSRTRLLxhl0+rQI4HQSDAbZ29vjoE4A7XK5mJqaakYQIcgW81RbZijJbIpkNqV9sdOMEAbFgNPqqBPOGbpaEhrEv0w8k+if5L6DnK50TatBiuzGd7EYzQxYNWjHpUuXkGWFQqGIJMHFi5d45ZWbTdYPIShVmxQ8Up0RTnTJ+wiqapVMIUuulO9KsRrOdlp1NfoO8mdujT3sg2SYEXdz/jAyMkKtppLNZpEkTRpufHy8SW6gVklmU1Sqla6aostJhIZgpg+j6jvI82rr4U2mh6Z0fmGPx4Pb7WZhYV6PEM30SqVYLvI0vK5T4DQYUwSC/spG30G+dlHk0fYTFFkhlonzL174jj5V72zB1tQadzfuc2/jAZuRLapq7UTp6771HeS5t2KlSCimVdb+AT8u2wAmg7ED7i6IpKM8DH3OysFTytXKM2Wv+9Z3kK+V7ScPSGSTSJLMROAMToujvZhG8Cj0mK1IiMOjSJs2Y99Ot0n/+j/9uJ/5flkPsxEVpN7pWGtB3vX614BkrR9B+nZiTfKsYluiuzY5iVyib1+t9cmS/lTR5RnbjX3n6EeQfnRpYWjpWz+C9K1vfQfpW9/6DtK3vvUdpG9961vfQfrWt76D9K1vX579f4aUtAO4A4BNAAAAAElFTkSuQmCC"
                                      />
                                    </div>
                                    <div class="sname">
                                      进程守护管理器 2.3<span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="redis"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAArOSURBVGhD7Vhpb1xnFT53nXtnnBlv8Ro7tuPEiUlLaOgS0ZVvfACBxCoQQv3EN0QFAgHic4VAqkDiH7BICAlVVdmqFpGmabqkTdI4tpPY8RZv8e6529yF57kzk06SCU3S8Ak/yus7c+d9z3uec55z7nsjO9jBDnawg/9rKJXrfYWpKFa7afS2GUZ3TlMLQZJ4K6VwfiEoTW9F0Vpl2n3BfSOg4l+rYXT1WubQPss6fChrPzxoW59s0bUOJ062r3j+yIjjvDXmeKenfH8UZKZKSRJUlt8zPjaBnKrmeyzzwKBlP0CnD+fsYwP5/HBheNjwZqaVcH1dzPYOURRFnLnZcBFZOOc4b4w47qlxxzsDMhfWw+haxdxd454IaIro7YbRsx8RHsraRw/Z9sNDWeuhvKa1qIqiqrmc9H3/BxKHJQmWliXT2SWrr/5TNk6+ka5P8M+J4q1Lnnd2pOicGnW9d8cc9/R8UJq826zcFYEGVS3029YnhrP2Iwez1tEh236oyzQGTFW10gmIsrW3T/JHPiVtX/6KNBwcliSBu1Eki3/+k6y88g8pjpyX2PfT6QQdXgpKs+Oud3rUdd+54LhvX0RmNqJopTLlv+IjCWiCaJtGz+Fc9hgdR9SP9FuZ4YJptmiWpSqaJnEQSIJBZLq7JXdgSPTGRrH3DUrnV78hSy+9KMXRC7J97qw4ly6mc2MQczGCOBGLxDU12Y6i9SnPH7vk+u9DYm9/4Dgn5/xgAiQ/ZHwTbkvAVpUcInz0SEPuSUabTrdbVm+hf8DKH/202H39ouXzAsFIEoYSXFsWZ2xU1k+elGhrM7VhtLRI3w9/LNO/fiH9nZEPcR9FLUUkxsV1rRRKERnabWjSYehS0GBPJFguleamvGB03HXPnNzcfnnUcd/xk8RNDdegLgG0v96v7W557sGc/eiejDmY1/UWTFTsgX3S8fVvStMTT6bOqYZRWQGVOI74iwuy8Mffy/KLf5HY89L7dv+AuJMTacTX4fAWRkAPMXgP8pEpP2DApFXXZJ9lyB7YNfGdQFY2x1zv7K9m57+LTnY+vVkDdL9b0ajrXU81Fp4dzmUfK+h6K53n/TjwJYkj0VCktc4TWjYrmp1NiaS6r4DOEzSQgVTMSsyqM/iNznci+r0ZQ5ohSTSJFJyDnpBvNjKPmYraVL57IypTb8SgbT/+o96e43mkswnWsriSqaLrYnZ0SnZwv9goVqO1VRRsHLue+HNz4l6ZEOfiuISbkFCFBMmaHR0puS3UACVUwk+Uj4M5Ma46vMhjHxty1EGSmaHM1qJyxjA3emFm5pnLrns8NVqDugQGQOB7PT3HUcB4qgoIKNIE47vYP7GBMEpwSM2YsADNQsMKSJpt7ZLp6kbb7KyMbjGaEDismf/D72Tlby+n9pmhGNcIgw7ovGJOiPvbcHotiqVYkRrn8PKb2xCoKyFskERJUuJiF6vXwkSm8e2yj3aIq4/CC7e3pLSyIiUUZ7i2KuHGhuj5gjQ//Yx0fuvb0vaFL0nj409IwwMPprLaOHmibBygsxoGjhxiYJRwbzmMZSKIZAr2V0GC+3J/Yt73z7txvFH5egMY5FuAFJawidJumocMVbVhKzXGiGwjMhvYAB0BkStnBP+wKAaha7J15j3ZPnsWoVHF6u2VGM5f+vlPILFZmr4O2vRgawkOz5fiVC5exWn+RiRouLOed/yllWs/m/H808haldN11JXQLk1r/lxz43e+2Nr8HIqom8ap21owdWSfQwG2QMRsf4wqoWi6qLmsGM0tOEa0y+bbb6UEiWr/X0ZWN1O7ZTnVgu2BtdesqwksujxHPT8z9+yE558rz/gQdQngTPPoL/p7X27UtQK+aow8dbmKTbn5zSCZDCw1Y9NWXU1lQZmkQL3wSUzHt+DwEuzwSqdvtmRhCdc3sp7wmXYT2FkoReFPJ6eewXHj9fLMD1G3BuCwsRhJE6SCoOIpCWOdMDxkoU+bmuQR9dqFdIaavQqC5z3qGEUIR+l0CfWygu9jqJ+L0Pg6nK+VCWk2wN4A7B60dOnAPtyPYObHvVCulmIFpit3b0RdAjSOLqCwqEZgYAkFxixQMkztgQw306Qd0mGkqpa5jm2SBTkCh991Q3kf6yegc9ZO1WmCnYcZY1CGYI+feY8FvQRvL2DdZezPNspA3A71CVS6EJexX08jgjQ4A0fY3hhBG5npwTNgGFHrRfRYC3U7Qg1IlIQ7QJzRHsjo0gA73MfBn9nKPux4zCgB56PNKFpErZQf7Teh7p5ob3ZnJnOoWdd7ICGSVCiTIv6UW1wC5myFMIBBCbTiLJPFlfvWtgo6zU0oi3ZDlb2mDo2X1zJbzAy70BwGo127luu8JF56dW3t+fGi81o9EnUJIChRk67q+3GAwwtLE/xWKgFJHWS7S5+SLEZ8ht/pyGJhM84zrBGdA7NJige1HkSb9wnKcQNdCdqWBciN0aZdgjMoJWa0DfWAs1G21dCbzhSdf+HFZzmdVIOyxZuALnTslwN7X0FrzDLybHfVpyN1xXu1YNtjVEE6PRobsErDbACpY8gYI+tj4SbsrGBUJVIF08x1JNyMLsSjBe9xv9UojtGFnsaJ9M6exFikLYZJlnKhgQKM9UPnA0g/o8Lo0Okq+/RJirkXUbhTKDw6SE3zQcVBmSwg2peDUGYrEa+C0abTbJ992KMfe3C/suNJ+mSGvMoFWQd1CTDC1COd4biGTXm4ymB2N+TAltcJPRewMbVdNcI9NjDvShDLJMiw6Kex/hI+z8OGX3GCxFnMlFQ7HGdwemCPp1IcGdL9qnvzqY+Gcts+VJcApselOHarRGYQvSswxihuILrEbm6M9rcHhFrSrNxYUCx09vxNrGexEnSchCm3Ljjch/UduHId5y3CPp3mfmn7xH12oaVSadyP4y3auBl1ixhPLyNvGB1ZFDDed9HpFLXaMVi4PAfFcIcap5zoEGXAcxEuaSZquwmjZOMP57WhyNmNOJ+yoOMr6Pt8dvCFh3Ik4Hi4HoZzk5534vX19d9Oed5bOK3e8mrJoNwC3FSb0EIPNzR8fp9tP9WVyTzQZBh7cUQov7wDdIrO78LIwTGmny8rJLcFGWyDAc854JQWNouS7ZbkmNoi5jAYDEo1Q0QYx95qGE7P+f77OD7/e7RY/PtKqXQFS2qnXUddAlXgRw1vZ914P/hMP0ZPJnMUJ9SDtpaeka6vpSx2oXOQEAe/88lPAiTK7sLd2cV43qc8WFNlMZbhQSJLQTA643nv8Nw/4bqvMwMgXDvtFlx34qOQxQl1TyZzpM+yju21rEd6LOsoTq0dqqJclyHfrPhkbahIiud97l7uROWI13Yg1hoysYIj83tXPO/NSdc9MeP7p/GSf8f/0XXHBKqgjHab5v5ekAAZjmOthrEf7w03yMuGZYOSgcMe/lQ7EIGuEm5U9A2n34C+Ty34/oUgSYqVKXeMuyZQBRaqeOHvQn08SDKolcd7M5mHM6q6C8Vd1y7PV5DJ2EXXfQ0SOYHIn4a+J2+n7zvBPROohaWqhTbTHKLEBrPZpw5ks59tUNU2di/8nLAVzvr+eyPF4l8pk/kg+AAZuFpe/fFwXwhUgfZrthhGX4dpDqNOHm3GZzxPnKtBcG4axbkQBCNOFK1Wpt8X3FcCNVAaNK3VxnME3TTYDsPle9H3Dnawgx3s4H8Mkf8AKHyWFR0zLP4AAAAASUVORK5CYII="
                                      />
                                    </div>
                                    <div class="sname">
                                      Redis 7.0.4<span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3"
                                  data-id="phpmyadmin"
                                >
                                  <span
                                    class="spanmove sf-hidden"
                                    style="cursor: pointer"
                                  ></span>
                                  <div>
                                    <div class="image">
                                      <img
                                        width="48"
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAqMSURBVGhD7VlZbFxXGb77NncWz3hmbM94Ge/77jhxiLM0xc1SQgy0VFXagiIkNoEQiDckHipAvICQQAJFoLRqoUK0EaqCgFKlS0hJlZqkWRxncRxn8TJexrPddfj/8bVjx854PM4DD/7k0T3LPff+37+ec01sYhOb2ERWIEmClAVKtrqPDZR1fWygKJqjaYa3uovgaJKrLeLqre5jA21dcwZJUrTbXdToyiuq51jR4fWHupxOf5Wixqd1TYml74G/fAft6wiJXRdHlQsMTbBmijDTD9ggNmwBiqKYPHegobikaV9pWctBv7+ix+0ONImC3QvTIDtBgMBMe0joZBmCE1hKKPawJTj+fwWW5eX8/JI2vGKfYThbegJg40nbz5/3/uqL3fbn8myUe1+r7Wm3THms6Q1hQxZgaZKlyPlnaJoSZUD4QLB+b1Ggdk91Tc8Rn798K865bLS7p1rckVDNuGYQGq7ra5YP4NxGsSECQQ9T7JAop9VFK9gcDm8lWKIdYoNhGd6GBLvKhe4CF1MYV1KxuGLGwlFjsq/FdiDkYyuspTkjZwKYFhuDfIvPwfitIeL2yKd/uzp4+vfDwwNvXbr47m/u3Ln8Dk0R9NMdcn8KEAcLYPDOxIxpl43KO9xp/xILAW0tzwk5Eyh0MYFyH1spcaRkDaWRTEbDkdnxayCvgf18O+3dWSftAcGBQCqdlaJJc24qaoT7WqQDrWVCB47lipwJtIf4Tr+TKdBNQreGVsXuBtter4P2p4BAQjHjOBZNpqI3x7Xr9QGuqb9LfsYhUo70zTkgJwIYhJ3g13ky5Vb1lGoNr4rntjtexCsQMMEC8wQUM3p9TBuyi7RjZ730xI5acTeO54KcCJR52fL6AN+I7UwE6oq4ho4Q341tdKGkmkqI4HKqllLGI/qYbqa0Cj9bdbBdPhxwM8H0onUiJwJtZXxnZQFbE4OMkolAf7f92YUYgZgwoayRHSGhKwVdJAOxEIXCJoIFdj3ZZNu/kJLXg3UvQIFaS/n2oJstjoEva48gABs3e/8W+Vlso/9DrGjQImqKuLraANeAYwvbCUwIT0FA1we5tFXXg3UTqC7kausCXCPHkDxmE7CAYk0tw4E226GgmynGNsiaghoQx3vRlV7qdR4Fyc0EjOE8Q5PMtipxBxS3gwJLijiWLdZNoLmEb6sJ8PVYBzAYFWOlBSiKoF4EIWEHypMA1DbUgJiipdSJWX1sV724F1yp+860NmotIZwS5XoKilt3pbjNGsoK6yKA+5jGEr6lwEkXYj8GPryaC/XWSLsxRSJJayhtAdhGqHdnjNEgbObQZQbvqheteSiMJNlaxndgbYDakW8Nr4l1Eagt4uuh+jbTFEmj4AlIi4ZJpAvWUhzZ4fiqDQ4vKBT2FyyAbdgPJeYSZqTUy4YcNtqFBQ3HEeCW3IE2+fPba8Rd1tCaWBeBhiDf1BDkmrEdQ5dYxf+bSvhWEGDn0i1CmgBkLGxj1hqfNcaCeUxxqYcN/f187O30TfMgS/KZsoNAAtOrNZYRWRMoymOCLaVcO/oq9jEDgU8vI4Au840nXd/BAregfQSkTQJTLrY1I6VNxYwwTFNBN11MgTXf/iR6wjBTOhKlYHx/m+1zu+ulvTwkClyTCVkTwPTXXCq0LQiGAj1sgY5yYQvk9D2Y262hNOZdaD7jGAahR8CFkKwXNoKYqd48G33jj6fnXoFnRk2oF5iC8eyAMQEvW1TEasiKALoDpM6G2sIHZ1p82dIUivd8Zafza6sFIMiPQZy2AGjawLXpCQBmtRb4vfxW+Ec/PTH14+v3tasYJ92VQs9nm2373TKd8eCTFYESD1vaVip0CNyDHB1TlrtQZ7nY3VMt9IoctWx3ilgaA1iFDXCj9AQAtd1bJ+6B2Gr69T+mf3H0d/eff+NM9NWRsH4LAvpQZ4XQjUdS6/YVyIpAZQFX0wa7T6ubxlIXgiOj/EKv42iBkylKTz4EFDpmbaWRDGSuZQf6OthXQeAeRm0PDCvnfvDq+Le/fmzspVOX4+/UFHJ1HpnG8/WqWJOAjafkuiDXgHt/aygNrAHoQujLeLraXi32SvxK7SNQ6IWtNN6PhS49YQHT52dqpZ1PNNj6GIpgUDGnrybe/+FrE999/cPI8dm4OWPdugJrEoC0Vgpb562Q+5eZEVwIK6uC2enLPY4jRW4mYE2tBBBAi2ETsgwtcdTigR8AFkkZBS66CP3e53xwwkNMzBnjqkHpeESF7oqAzkgAd4cVPraqvUzosoYWYQViqr/L/gwEYTucEbj5meXAXSimTtw3YR+yjDEeMcY+vpH86P0r8XehDpz867n4m38+q/3l5pQ44fX4G92e4ha/v2Kb11e2xeH0VfC8LY9hWAFIrJD3kcGBwJwPhakFtLxCu6hRDOp8B+29AluCS6PqBdjf67qR0sHHdWxjlYa+hmnz5oR+g4FDvkaI0slL0plTN8ShqMpqcyqnqSmB5nl7vig5CtylzhcKq0SXqiZmwuHb5ycmhj8OT97+RJv/SIYlZRky5lj0+2/15X0PTLsd/R2rqHVVXjsdOf7hYOIUnqpokqA1gwR5GcokOdYkWCZF8iy2SYqXOE50wM8piHavKDr8kuTw4xUFxivHSU78QIbvTMQjY/fuDb134/rZP925c/lfqhKfTgvzCGQkgAdyLCb4XVPRSU1LcZRB8KxBCMx0gonHdc5kWdHOsgIKmBaS40XXfFtycbyUJwhyvgg/XpA9FEVn/AIRi06PXrv2n9cHr3xwbHZmbAgUvubnx0cSwFIv2z2l6IsoCG8JhP7Ip6/Q56wr9PGLHCzJ+VtrNDp1++rg6T8MXv7gWDQavmUNr4mMBPwFlT2dWw6/7PEEm8F/5QUzPwzD0JKqmoyA386apq5B7GO8sfhhi+V4GX0fn2fdvgLJZHRy6Oq/j396/p+/BCIj1nBWyOhCks0VaGnp+3594+5vLjU/CKzAi27NzNwfVJT4VMo0dEw3hmmomHVomubAtRwi+DxaBvc3mpqImIahgos5IbNUSZKzAB5FIvGR4YETAwMnfzY9dXfxfJAtMhIArdGFhdW9XVv7f+LzhbZggI2P3/woHp+9xzCclEhE7kOGGJibC4/ouoJpFRVN4w//R0DTmPpI0jB0Fe/H4JVlTwmQyEMyLCfY8RN8LDY9Gg6P/ncqPHoBrTH/9uyQkQACAzNU3vEFnz+0dXLy9jkWvzqDUInE3EQMzD0XmRxOKtEwCBJNf3lYHSQEuoyxg1ckBGOp4pLGfQVFVb00xXAzM/cuDw2eeWV6+u6l+SXZYU0CCAhcN7zYrqrxGVl2F7shJnRNjWm6EoN2C7iKT9fV+JVL7/0WrWMtWwRa0ukqrOE4wYFWkSRXIa4xTF1VktEwuOE0an4uMnED48halhWyIoDuINvzS/GloGRDkvIC/oLybeD6yuTErXMJeDmOhydHsOAsbpUXgP92Kgu1HbIBeRQ0Ci6XBAsqoBC8mhA71q3rRlYE0LEdTn+Vx1PcisEM2o6h5kDb9+Pxmbuofbzv0S5EkkgeFQHuo4CWI5AIEtbkhpAVAQRkUJ5lOQn3kqBsA4XeiOY2sYlNPA4QxP8AX3W5wncWsPcAAAAASUVORK5CYII="
                                      />
                                    </div>
                                    <div class="sname">
                                      phpMyAdmin 5.2<span
                                        style="color: #20a53a"
                                        class="glyphicon glyphicon-play"
                                      ></span>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-sm-3 col-md-3 col-lg-3">
                                  <div class="recommend-soft recom-iconfont">
                                    <div class="product-close hide sf-hidden">
                                      关闭推荐
                                    </div>
                                    <div class="images">
                                      <img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAoCAMAAACPWYlDAAAAA3NCSVQICAjb4U/gAAABZVBMVEX///8Lmt0Ql9wSl9sSl9oLmdsMmd0Pl9sSldoOl90Ol9kQltkSldwQlt8QldsNltsJluALlt4Old8Qld0QldkUlNgSk9sOlN0Rk9kJltsOlNsQkt0NktkOmd4Sl9sSl9oQl9wQl9sSldoSldwOl90SldsQlt8QldsOld8Qld0QldkSk9sOlN0OlNsQl9wSl9sSl9wSldoQltkOl90SldwPl9sQldsQld0Rk9kOlN0Qmd0Ql9wSl9sQltkSldwSldoSldsQldsSl9sQl9wQl9sSldoSldwQltkQldsQldkQl9wSl9sSldoSldwQltkQldsSl9sQl9wQl9sSldwSldoSldsSl9sQl9wSldoSldwSldsSl9sSldoSldwSldsQldsSl9sSldoSldsQldsSl9sSldoSldsSldwSl9sQl9wSldoSldsSldwSl9sSldoSldsSldwSl9sSldoSldsSl9sSldoSldvbAjwjAAAAd3RSTlMAERERERERERERERERERERERERERERERERERERESIiIiIiIiIiIiIiIiIiIiIiMzMzMzMzMzMzMzMzRERERERERERVVVVVVVVVVWZmZmZmZnd3d3d3d4iIiIiImZmZmZmqqqqqu7u7u8zMzMzM3d3d3e7u7v///zKVmDUAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDYvMjgvMTjVuRCmAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M26LyyjAAAAzdJREFUOI2FVYtfG0UQXgGloELrA6it4Fmx9UVMrVAlIElJi5CWo5Frmgv0ghs8g3s4l9n9+93duVdCqPP7JfP6vr2ducmEsVFZqp70+gNElP1XvyxcSY/KcjuKBe8E6qIbClCXu85b4as+gl+7w9g0utrdcLmE5t3r8e5ANJet5aBHoVqo+E/XwO+cy/ZiYmcEdutQxfWx+PdC/D1zcgJj9/rqcAz+Rh/2cq+M3nzmLHTV86uELlStnmSzmx6PpBJ8fz1NnmNlFH9Ij20E/JQjhhzDIETsPKTsO0JMDuO/j/+0NDRyvM5uQ5O9+5svoUb5x9IfJgQwaxQ3+DAveuUvPCZAS64V8V/Y95QSJvMuLQZIHVqFoEhowwdUuSG4rNhWDlT6K/lljv84phtuYY9ze4dF6Sa5z6FvdRkLrV1TVBuPksBOR4pWmewDSe8nvMgJnvjMHqIOEj/uwz8xkPeRoNu35Y2M0AutasJ3Vp9ert0HbyrAXaKjnb4nuJERoq5VAbeqLtdpvAN7zt4AB6agb+BpRhicOVpK/3KjHC5KThV9x9nHPcfZik3ndrQBRxlB4ZBI/bEhqRKDpJ0RkLtG4G+rhHBdz4Q89M2XEU8b4GaEiF7DObXjj9icobP7YJrX1Q80iQ/Ffka46CXdfd+oFeGzCU14iB0b9mmeKrCZEd5QW6uSpn4Xzmpw0lR0TNIs5qoHGaEGj4z6NB2wn3u6NaJFzoqkge1Gn2SEWUnJI3yURHZUkG6XAOxvZ16csFy69NQlkQ7TNKYtqSFNyJ7cLhB+VbRJtpI68/HeGtAUMC7mCoSpkKaCHUJnqkhoYJLYli9ZUXblEzLqENXvMzZjr1QK8HTGhu+G4tshgi7tKzIe96Rer3XwK65eHemqeqOeDePZ3CD7fVS8cBArPUThUbrt6ziyNLRsyLPMXlqtY7BTvp36DQzH/FFUJJ/InBnMJ03jo+WreD0ZEJVSu7CMF44xXB2H16i+av0wQpjevpDBzfF4La8lHH9tjAm60r1GKMPGtXAtZQ+At+qlauw5NY+DvDyYfxveXObFuUAABAF6e2/O/Q/cysTG85b3+ujpj5Njkv8BnbT3wlqUKqAAAAAASUVORK5CYII="
                                      />
                                    </div>
                                    <div class="product-name">网站监控报表</div>
                                    <div class="product-pay-btn">
                                      <a
                                        class="btn btn-sm btn-default mr5 preview-btn"
                                        href="https://www.bt.cn/new/product_website_total.html"
                                        target="_blank"
                                        >预览</a
                                      >
                                      <a
                                        class="btn btn-sm btn-success preview-btn home_recommend_btn"
                                      >
                                        购买
                                      </a>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-sm-3 col-md-3 col-lg-3">
                                  <div class="recommend-soft recom-iconfont">
                                    <div class="product-close hide sf-hidden">
                                      关闭推荐
                                    </div>
                                    <div class="images">
                                      <img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAlCAMAAAADS4u8AAAAA3NCSVQICAjb4U/gAAAAY1BMVEX////Dw9K/v8+9vca3t8cAsgC9vca3t8e3t8u3t8e3t8u9vca3t8e3t8cAsgC3t8e3t8cAsgC3t8cAsgC3t8e3t8cAsgC3t8cAsgC3t8cAsgC3t8cAsgC3t8cAsgC3t8cAsgBGgHCJAAAAIXRSTlMAEREREREiIiIzM0REVVVmd3eIiJmqqru7zMzd3e7u//9EOJoZAAAACXBIWXMAAAsSAAALEgHS3X78AAAAFnRFWHRDcmVhdGlvbiBUaW1lADA4LzI0LzE4z1DUQwAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAADpSURBVDiN7dXhDoIgFAXgo2ZlWZqYQlmX93/KwELJ5ZW1fnamTLePcbluCCDa5fPJEoypiM85crIkurbzUcY6qqgEl+RG2euRKMHarLExRW1iYPteKlBTMVDgphBRi9istZ1UWpi9lB6tKjO57O94Ums+oWx8ynTVpvboYkbKdNXm+l2tf/o7mlf7UDpmkaanpjmlITTtdGeuNIAKfQSOWgTQ5m7HexNApRzGn9GLHnJhqD2AtBSvSM3QlaXCvQmORo72hbIUjnZdMBXiSRXlofRApD4fAAN125o/tXvqNwuY+xVYKr1P8ACdkzLePUU0NwAAAABJRU5ErkJggg=="
                                      />
                                    </div>
                                    <div class="product-name">
                                      堡塔企业级防篡改
                                    </div>
                                    <div class="product-pay-btn">
                                      <a
                                        class="btn btn-sm btn-default mr5 hide sf-hidden preview-btn"
                                        href="http://47.122.7.214:37351/"
                                        target="_blank"
                                        >预览</a
                                      >
                                      <a
                                        class="btn btn-sm btn-success preview-btn home_recommend_btn"
                                      >
                                        购买
                                      </a>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-sm-3 col-md-3 col-lg-3">
                                  <div class="recommend-soft recom-iconfont">
                                    <div class="product-close hide sf-hidden">
                                      关闭推荐
                                    </div>
                                    <div class="images">
                                      <img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAMAAAAp4XiDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAEtQTFRFj9Kcra6tyMnIWLxr1e7aLqtGdMeEx+jOq921uePB8fnz+Pj44/TmSrZfZsF4wsLCPLBTndeop6engs2R1tbW5OTkIKU6kpOS////J7Q5JgAAABl0Uk5T////////////////////////////////AAE0CrcAAADHSURBVHja7NXbDoIwDIDh4s6cQVd4/yeVQYJGt9EmJhrDf/8ldOsCzOzgJD9MqnE6bqyeiZ8o+Rfij3onhyPEiSy5xKKSTGIwZ+IfZnMmMX7OpE5sMYJJNOKVRxahebPkRJwMm7CwVlOIVEFI3GqJ4y+VrVhzdMK8yo+RWguha+8rMpEqnMZjkQikx8aZFhWdGFTh5TVoGGRdVMCBT4BKXIMq3GyP6IgEcE98hVyi3XIkXpEkc1fE69Iks2GwJ8/f65+RuwADAAYi264yyG39AAAAAElFTkSuQmCC"
                                      />
                                    </div>
                                    <div class="product-name">堡塔防入侵</div>
                                    <div class="product-pay-btn">
                                      <a
                                        class="btn btn-sm btn-default mr5 hide sf-hidden preview-btn"
                                        href="http://47.122.7.214:37351/"
                                        target="_blank"
                                        >预览</a
                                      >
                                      <a
                                        class="btn btn-sm btn-success preview-btn home_recommend_btn"
                                      >
                                        购买
                                      </a>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  class="col-sm-3 col-md-3 col-lg-3 no-bg"
                                ></div>
                              </div>
                            </section>
                          </div>
                          <div class="interface-right-container">
                            <section class="interface-right">
                              <header class="flow-header">
                                <span>流量</span>
                                <select name="" id="">
                                  <option value="0">全部</option>
                                </select>
                              </header>
                              <div class="flow-count">
                                <article class="flow-count-article">
                                  <p>上行</p>
                                  <p>100k</p>
                                </article>
                                <article class="flow-count-article">
                                  <p>下行</p>
                                  <p>100k</p>
                                </article>
                                <article class="flow-count-article">
                                  <p>上行</p>
                                  <p>100k</p>
                                </article>
                                <article class="flow-count-article">
                                  <p>下行</p>
                                  <p>100k</p>
                                </article>
                              </div>
                              <div
                                class="flow-chart"
                                id="mychart"
                                style="height: 273px; width: 100%"
                              ></div>
                            </section>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- 0323添加的内容 -->
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加/编辑服务器 -->
    <el-drawer
      class="pl-drawer pl-drawer-select"
      :wrapper-closable="false"
      :title="titleDialog"
      :visible.sync="dialogCreate"
      direction="ltr"
    >
      <el-form
        ref="form"
        v-loading="listLoading2"
        :model="formAdd"
        label-width="120px"
      >


        <el-form-item label="服务器名称：">
          <el-input
            v-model="formAdd.name"
            wrap="off"
            placeholder="格式:组别+编号+站(例如:A12站)"
            style="width: 100%"
          />
        </el-form-item>


        <el-form-item label="主IP：">
          <el-input
            v-model="formAdd.host"
            wrap="off"
            placeholder="输入一个主要的管理IP"
            style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="SSH端口：">
          <el-input v-model="formAdd.ssh_port" wrap="off" style="width: 100%" />
        </el-form-item>
        <el-form-item label="SSH用户名：">
          <el-input v-model="formAdd.sshuser" wrap="off" style="width: 100%" />
        </el-form-item>
        <el-form-item label="SSH密码：">
          <el-input
            v-model="formAdd.sshpasswd"
            wrap="off"
            style="width: 100%"
          />
        </el-form-item>

        <!-- 多ip段时显示 -->
        <el-form-item label="附加IP段：">
          <el-input
            v-model="tinyproxyConfig"
            wrap="off"
            type="textarea"
            placeholder="配置IP可以实现建站自动解析DNS
  例如:
  154.94.148.193-254
  154.94.182.193-254
  154.94.186.193-254
  154.94.188.193-254"
            style="width: 100%"
          />
        </el-form-item>

        <!-- 拨号模式时显示 -->
        <el-form-item
          v-if="
            arrChecked.indexOf('adslproxy') > -1 ||
            formAdd.deploy == 'adslproxy'
          "
          label="ADSL账号：">
          <el-input
            v-model="adslproxyUser"
            wrap="off"
            placeholder="拨号代理账号"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item
          v-if="
            arrChecked.indexOf('adslproxy') > -1 ||
            formAdd.deploy == 'adslproxy'
          "
          label="ADSL密码："
        >
          <el-input
            v-model="adslproxyPwd"
            wrap="off"
            placeholder="拨号代理密码"
            style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="购买日期：">
          <el-date-picker
            v-model="formAdd.buytime"
            type="date"
            value-format="yyyy-MM-dd"
            placeholder="选择日期"
          />
        </el-form-item>


        <el-form-item>
          <el-button
            v-if="!loadingBtn2"
            type="primary"
            style="width: 280px"
            @click="startCreate"
            >提交</el-button
          >
          <el-button
            v-if="loadingBtn2"
            type="info"
            :loading="true"
            style="width: 280px"
            >IP验证中,请最多等待30秒...</el-button
          >
        </el-form-item>
      </el-form>
    </el-drawer>
  </div>
</template>


<script>
import * as echarts from "echarts";
import Cookies from "js-cookie";
import EventBus from "@/utils/eventBus.js";
import serversCard from "@/components/servers-card";
import serversSelect from "@/components/servers-select";
import VueDragResize from "vue-drag-resize";
import siteList from "@/views/v2/website/list";
import toolList from "@/views/v2/tools/toolList";
import systemConfig from "@/views/v2/system/config";
import page404 from "@/views/v2/system/page404";
import allowIP from "@/views/v2/system/allowIP";
import robots from "@/views/v2/system/robots";
import shouluPage from "@/views/v2/report/shoulu";
import tools from "@/views/v2/tools/index";
import serverPage from "@/views/v2/server/index";
import upgradePage from "@/views/v2/server/upgrade";
import taskPage from "@/views/v2/server/task";
import firewallPage from "@/views/v2/server/firewall";
import siteAdd from "@/views/v2/website/add";
import pageConfig from "@/views/v2/website/page";
import addSite from "@/views/v2/website/add";
import setSitePage from "@/views/v2/website/setsitepage";
import toolsPage from "@/views/v2/tools/index";
import codePage from "@/views/v2/website/code";
import BatchUpdate from "../tools/batchUpdate";
import { clientSystemLoad } from "@/api/server";

export default {
  components: {
    dialogVisible: false,
    VueDragResize,
    siteList,
    systemConfig,
    page404,
    allowIP,
    robots,
    serverPage,
    shouluPage,
    tools,
    serversCard,
    siteAdd,
    pageConfig,
    serversSelect,
    addSite,
    upgradePage,
    taskPage,
    firewallPage,
    toolsPage,
    setSitePage,
    codePage,
    toolList,
  },
  beforeRouteEnter(to, from, next) {
    // 添加背景色 margin:0;padding:0是为了解决vue四周有白边的问题
    document.querySelector("body").setAttribute("style", "margin:0;padding:0");
    next();
  },
  beforeRouteLeave(to, from, next) {
    // 去除背景色
    document.querySelector("body").setAttribute("style", "");
    next();
  },
  data() {
    return {
      titleDialog: "添加服务器",
      dialogCreate: false,
      versionData: {},
      unplanNum: 0,//杂项任务
      cloneLoadNum: 0,//正在处理：
      waitNum: 0,//等待处理
        formAdd: {
        name: '', // 测试服务器名称
        ssh_ip: '',
        server_ip: '',
        ssh_port: '22',
        desc: '备注内容',
        group: '未分组',
        host: '',
        location: '',
        sshuser: 'root',
        sshpasswd: '',
        buytime: '',
        config: {}, // 	服务器附加配置，如蜘蛛防火墙，adsl账号密码；多IP号段
        deploy: '' // 部署程序：无：none；克隆站群：clone；多IP代理：tinyproxy；拨号代理：adslproxy；多个用英文逗号隔开
      },
      tinyproxyConfig: '',
      listLoading2: false,
      arrChecked: [],
      loadingBtn2: false,




      webOriginalConfig: [
        {
          id: 1,
          title: "状态",
          name: "config",
          active: true,
        },
      ],
      bigMenus: [
        {
          name: "site",
          icon: "monitor",
          title: "系统摘要",
        },
        {
          name: "shoulu",
          icon: "folder-add",
          title: "CC防御",
        },
        {
          name: "spider",
          icon: "data-analysis",
          title: "WebSSH",
        },
      ],
      currentConfig: {},
      currentGroupName: "",
      currentSiteId: "",
      showUpdate: true,

      activeTools: "toolsUpdate",
      activeMoreSite: "siteconfig",
      activeSpider: "spider",
      activeShoulu: "shoulu",
      siteType: "edit",
      title: "保存修改",
      pageType1: "friendlink",
      pageType2: "footjs",
      pageType3: "headjs",
      pageType4: "404",
      pageType5: "other",
      pageType6: "nginx",
      showSiteList: true,
      isShow: true,
      showConTab: "site",
      direction: "btt", // 抽屉方向
      openDrawer: "",
      winLeft: 200,
      winTop: 20,
      activeSite: "config",
      activeServer: "serverList",
      activeSys: "site",
      activeName: "add",
      winWidth: 900,
      winHeight: 640,
      row: {},
      sid: null,
      valueServer: "",
      titleServer: "",
      spiderConfig: {},
      webConfig: [],
    };
  },
  watch: {},
  mounted() {
    this.webConfig = [...this.webOriginalConfig];
    // this.getCloneLoad();
    this.timer = setInterval(this.getCloneLoad, 5000);
    this.setChart();
    //  this.fun1()
  },
  beforeDestroy() {
    EventBus.$off("order");
    clearInterval(this.timer);
  },
  methods: {
      startCreate() {
      if (!this.formAdd.name) {
        return this.$message.info('服务器名称不能为空')
      } else if (!this.formAdd.host) {
        return this.$message.info('服务器主IP不能为空')
      } else if (!this.formAdd.ssh_port) {
        return this.$message.info('端口不能为空')
      } else if (!this.formAdd.sshuser) {
        return this.$message.info('SSH账号不能为空')
      } else if (!this.formAdd.sshpasswd) {
        return this.$message.info('SSH密码不能为空')
      } else if (!this.formAdd.desc) {
        return this.$message.info('备注信息至少3个字符')
      } else if (this.formAdd.name.length < 3) {
        return this.$message.info('服务器名称至少3个字符')
      } else if (this.formAdd.desc.length < 3) {
        return this.$message.info('备注信息至少3个字符')
      }

      this.formAdd.config.tinyproxy = {}
      this.formAdd.config.adslproxy = {}
      this.formAdd.config.clone = {}

      // if(this.arrChecked.indexOf('clone') > -1) {
      //   this.formAdd.config.clone = this.configData
      // }
      // if(this.arrChecked.indexOf('tinyproxy') > -1) {
      //   this.formAdd.config.tinyproxy.ipsection = this.tinyproxyConfig
      // }
      // if(this.arrChecked.indexOf('adslproxy') > -1) {
      //   this.formAdd.config.adslproxy.username = this.adslproxyUser
      //   this.formAdd.config.adslproxy.password = this.adslproxyPwd
      // }

      this.formAdd.config.adslproxy.username = this.adslproxyUser
      this.formAdd.config.adslproxy.password = this.adslproxyPwd
      this.formAdd.config.tinyproxy.ipsection = this.tinyproxyConfig
      this.formAdd.config.clone = this.configData

      this.formAdd.name = this.formAdd.name.toUpperCase()
      this.loadingBtn2 = true
      this.titleDialog == '编辑服务器信息' ? this.submitUpdate(this.formAdd) : this.submitCreate(this.formAdd)
    },
    viewDetail() {
      this.dialogVisible = true
    },

    openCreateDialog(){
      this.titleDialog='新增服务器'
this.dialogCreate=true
    },
    updateServeDialog(){
      this.titleDialog='编辑服务器'
this.dialogCreate=true
    },

    setChart() {
      // 基于准备好的dom，初始化echarts实例
      let mychart = echarts.init(document.getElementById("mychart"));
      // 监听屏幕变化自动缩放图表
      window.addEventListener("resize", function () {
        mychart.resize();
      });
      // 绘制图表
      mychart.setOption({
        title: {
          text: "",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross",
            label: {
              backgroundColor: "#6a7985",
            },
          },
        },
        legend: {
          data: ["Union Ads", "Video Ads", "Direct", "Search Engine"],
        },
        // toolbox: {
        //   feature: {
        //     saveAsImage: {},
        //   },
        // },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
          },
        ],
        yAxis: [
          {
            type: "value",
          },
        ],
        series: [
          {
            name: "Union Ads",
            type: "line",
            stack: "Total",
            areaStyle: {},
            emphasis: {
              focus: "series",
            },
            data: [220, 182, 191, 234, 290, 330, 310],
          },
          {
            name: "Video Ads",
            type: "line",
            stack: "Total",
            areaStyle: {},
            emphasis: {
              focus: "series",
            },
            data: [150, 232, 201, 154, 190, 330, 410],
          },
          {
            name: "Direct",
            type: "line",
            stack: "Total",
            areaStyle: {},
            emphasis: {
              focus: "series",
            },
            data: [320, 332, 301, 334, 390, 330, 320],
          },
          {
            name: "Search Engine",
            type: "line",
            stack: "Total",
            label: {
              show: true,
              position: "top",
            },
            areaStyle: {},
            emphasis: {
              focus: "series",
            },
            data: [820, 932, 901, 934, 1290, 1330, 1320],
          },
        ],
      });
    },
    // fun1(){
    //   clientSystemLoad().then((res)=>{
    //     console.log(res,'resdddd')
    //   })
    // },
    submitDomain(domain) {
      console.log(domain, "domain");
      this.$refs.siteListRef.getList();
      this.$set(this.row, "domain", domain);
    },
    menusChange(name) {
      // 0323新加的内容
      this.showConTab = name;
      EventBus.$off("row");
      EventBus.$off("order");
      if (name === "home") {
        this.$router.push("/");
      }

      this.activeSys = name;
    },
    getCloneLoad() { // 查询克隆负载
      console.log('getCloneLoad', this.sid)
      const parmers = {}
      if (!this.sid) {
        return false
      }
      parmers.server_id = this.sid
      cloneLoad(parmers).then(res => {
        console.log(res, 'cloneLoadres')
        if (res.status) {
          this.cloneLoadNum = res.data?.process+'' || '0'
          // this.activities=[
          //   {
          //     content: '影响等待建站的任务执行，如长时间居高不下，请尝试重启克隆服务',
          //     timestamp: res.data?.wait +'' || '0',
          //     size: 'large',
          //     type: 'primary',
          //     icon: 'el-icon-more'
          //   }, {
          //     content: '正在克隆的任务数量，达到指定深度后停止。',
          //     timestamp: this.cloneLoadNum,
          //     color: '#0bbd87'
          //   }, {
          //     content: '未推送的克隆深度任务',
          //     timestamp: res.data?.unplan+'' || '0',
          //     size: 'large'
          //   }
          // ]
          this.waitNum = res.data?.process || 0
          this.unplanNum = res.data?.unplan || 0
        }
      }).catch(err => {
        console.log(err)
      })
    },
    changeRow(id) {
      this.$refs.siteListRef.getList("", "", id);
    },
    handleClickSite(tab, event) {
      // if(tab.name == 'config') {
      //   EventBus.$emit('domainActived', this.row.domain); //传递更新列表指令
      // }
      EventBus.$off("row");
      EventBus.$off("order");
      this.activeSite = tab.name;
      this.webConfig.map((v, i) => {
        return (v.active = Number(tab.index) === i);
      });
    },
    selectServerFromSon(msg, list) {
      console.log(msg,list)
      // 来自公共组件传值
      if (msg && list) {
        list.forEach((item) => {
          if (item.value == msg.server_ip) {
            this.sid = item.sid;
            this.valueServer = msg.server_ip;
            this.titleServer = msg.iname;
            this.spiderConfig = item.spiderConfig;

            // this.menusChange('site')
          }
        });
      }
    },
    getToolsBatch(val) {
      this.toolsWebList = val;
    },
    getRowData(row) {
      this.row = row;
      this.currentConfig = this.row?.config || {};
    },
    get_init: function () {
      var _this = this;
      _this.reander_system_info(function (rdata) {
        // 负载悬浮事件
        $("#loadChart").hover(
          function () {
            var arry = [
                ["最近1分钟平均负载", rdata.load.one],
                ["最近5分钟平均负载", rdata.load.five],
                ["最近15分钟平均负载", rdata.load.fifteen],
              ],
              tips = "";
            $.each(arry || [], function (index, item) {
              tips += item[0] + "：" + item[1] + "</br>";
            });
            $.each(rdata.cpu_times || {}, function (key, item) {
              tips += key + "：" + item + "</br>";
            });
            // '最近1分钟平均负载：' + rdata.load.one + '</br>最近5分钟平均负载：' + rdata.load.five + '</br>最近15分钟平均负载：' + rdata.load.fifteen + ''
            layer.tips(tips, this, { time: 0, tips: [1, "#999"] });
          },
          function () {
            layer.closeAll("tips");
          }
        );

        // cpu悬浮事件
        $("#cpuChart").hover(
          function () {
            var cpuText = "";
            for (var i = 1; i < rdata.cpu[2].length + 1; i++) {
              var cpuUse = parseFloat(
                rdata.cpu[2][i - 1] == 0 ? 0 : rdata.cpu[2][i - 1]
              ).toFixed(1);
              if (i % 2 != 0) {
                cpuText += "CPU-" + i + "：" + cpuUse + "%&nbsp;|&nbsp;";
              } else {
                cpuText += "CPU-" + i + "：" + cpuUse + "%";
                cpuText += "</br>";
              }
            }

            layer.tips(
              rdata.cpu[3] +
                "</br>" +
                rdata.cpu[5] +
                "个物理CPU，" +
                rdata.cpu[4] +
                "个物理核心，" +
                rdata.cpu[1] +
                "个逻辑核心</br>" +
                cpuText,
              this,
              {
                time: 0,
                tips: [1, "#999"],
              }
            );
          },
          function () {
            layer.closeAll("tips");
          }
        );

        $("#memChart")
          .hover(
            function () {
              $(this).append(
                '<div class="mem_mask shine_green" title="点击清理内存"><div class="men_inside_mask"></div><div class="mem-re-con" style="display:block"></div></div>'
              );
              $(this)
                .find(".mem_mask .mem-re-con")
                .animate({ top: "5px" }, 400);
              $(this).next().hide();
            },
            function () {
              $(this).find(".mem_mask").remove();
              $(this).next().show();
            }
          )
          .click(function () {
            var that = $(this);
            var data = _this.chart_result.mem;
            bt.show_confirm(
              "真的要释放内存吗？",
              '<font style="color:red;">若您的站点处于有大量访问的状态，释放内存可能带来无法预测的后果，您确定现在就释放内存吗？</font>',
              function () {
                _this.release = true;
                var option = JSON.parse(JSON.stringify(_this.series_option));
                // 释放中...
                var count = "";
                var setInter = setInterval(function () {
                  if (count == "...") {
                    count = ".";
                  } else {
                    count += ".";
                  }
                  option.series[0].detail.formatter = "释放中" + count;
                  option.series[0].detail.fontSize = 15;
                  option.series[0].data[0].value = 0;
                  _this.chart_view.mem.setOption(option, true);
                  that.next().hide();
                }, 400);
                // 释放接口请求
                bt.system.re_memory(function (res) {
                  that.next().show();
                  clearInterval(setInter);
                  var memory = data.memRealUsed - res.memRealUsed;
                  option.series[0].detail = $.extend(option.series[0].detail, {
                    formatter:
                      "已释放\n" + bt.format_size(memory > 0 ? memory : 0) + "",
                    lineHeight: 18,
                    padding: [5, 0],
                  });
                  _this.chart_view.mem.setOption(option, true);
                  setTimeout(function () {
                    _this.release = false;
                    _this.chart_result.mem = res;
                    _this.chart_active("mem");
                  }, 2000);
                });
              }
            );
          });

        // 磁盘悬浮事件
        for (var i = 0; i < rdata.disk.length; i++) {
          var disk = rdata.disk[i],
            texts = "基础信息</br>";
          texts += "文件系统：" + disk.filesystem + "</br>";
          texts += "类型：" + disk.type + "</br>";
          texts += "挂载点：" + disk.path + "</br>";
          texts += "<strong>Inode信息:</strong></br>";
          texts += "总数：" + disk.inodes[0] + "</br>";
          texts += "已用：" + disk.inodes[1] + "</br>";
          texts += "可用：" + disk.inodes[2] + "</br>";
          texts += "Inode使用率：" + disk.inodes[3] + "</br>";
          texts += "<strong>容量信息</strong></br>";
          texts += "容量：" + disk.size[0] + "</br>";
          texts += "已用：" + disk.size[1] + "</br>";
          texts += "可用：" + disk.size[2] + "</br>";
          texts += "使用率：" + disk.size[3] + "</br>";
          $("#diskChart" + i)
            .data("title", texts)
            .hover(
              function () {
                layer.tips($(this).data("title"), this, {
                  time: 0,
                  tips: [1, "#999"],
                });
              },
              function () {
                layer.closeAll("tips");
              }
            );
        }
        _this.get_server_info(rdata);
        if (rdata.installed === false) bt.index.rec_install();
        if (rdata.user_info.status) {
          var rdata_data = rdata.user_info.data;
          bt.set_cookie("bt_user_info", JSON.stringify(rdata.user_info));
          $(".bind-user").html(rdata_data.username);
        } else {
          $(".bind-weixin a").attr("href", "javascript:;");
          $(".bind-weixin a").click(function () {
            bt.msg({ msg: "请先绑定宝塔账号!", icon: 2 });
          });
        }
      });
      // setTimeout(function () { _this.get_index_list() }, 400)
      setTimeout(function () {
        _this.net.init();
      }, 500);
      setTimeout(function () {
        _this.iostat.init();
      }, 500);
      setTimeout(function () {
        _this.get_warning_list();
      }, 600);
      setTimeout(function () {
        _this.interval.start();
      }, 700);
      setTimeout(function () {
        bt.system.check_update(function (rdata) {
          index.consultancy_services(rdata.msg.adviser);

          if (rdata.status !== false) {
            var res = rdata.msg,
              beta = res.beta,
              is_beta = res.is_beta,
              ignore = res.ignore;
            if (ignore.indexOf(is_beta ? beta.version : res.version) == -1)
              index.check_update(true); // 判断自动升级
            $("#toUpdate a").html(
              '更新<i style="display: inline-block; color: red; font-size: 40px;position: absolute;top: -35px; font-style: normal; right: -8px;">.</i>'
            );
            $("#toUpdate a").css("position", "relative");
          }
          if (rdata.msg.is_beta === 1) {
            $("#btversion").prepend(
              '<span style="margin-right:5px;">Beta</span>'
            );
            $("#btversion").append(
              '<a class="btlink" href="https://www.bt.cn/bbs/forum-39-1.html" target="_blank">  [找Bug奖宝塔币]</a>'
            );
          }
        }, false);
      }, 700);
    },
    reander_system_info: function (callback) {
      var _this = this;
      bt.system.get_net(function (res) {
        _this.chart_result = res;
        // 动态添加磁盘，并赋值disk_view
        if (_this.chart_view.disk == undefined) {
          for (var i = 0; i < res.disk.length; i++) {
            var diskHtml =
              "<li class='rank col-xs-6 col-sm-3 col-md-3 col-lg-2 mtb20 circle-box text-center'><div id='diskName" +
              i +
              "' class='diskName'></div><div class='chart-li' id='diskChart" +
              i +
              "'></div><div id='disk" +
              i +
              "'></div></li>";
            $("#systemInfoList").append(diskHtml);
            _this.disk_view.push(
              echarts.init(document.querySelector("#diskChart" + i))
            );
          }
        }

        // 负载
        var loadCount =
          Math.round((res.load.one / res.load.max) * 100) > 100
            ? 100
            : Math.round((res.load.one / res.load.max) * 100);
        loadCount = loadCount < 0 ? 0 : loadCount;
        var loadInfo = _this.chart_color_active(loadCount);

        // cpu
        var cpuCount = res.cpu[0];
        var cpuInfo = _this.chart_color_active(cpuCount);

        // 内存
        var memCount =
          Math.round((res.mem.memRealUsed / res.mem.memTotal) * 1000) / 10; // 返回 memRealUsed 占 memTotal 的百分比
        var memInfo = _this.chart_color_active(memCount);
        bt.set_cookie("memSize", res.mem.memTotal);

        // 磁盘
        var diskList = res.disk;
        var diskJson = [];
        for (var i = 0; i < diskList.length; i++) {
          var ratio = diskList[i].size[3];
          ratio = parseFloat(ratio.substring(0, ratio.lastIndexOf("%")));
          var diskInfo = _this.chart_color_active(ratio);

          diskJson.push(diskInfo);
        }

        // chart_json存储最新数据
        _this.chart_json["load"] = loadInfo;
        _this.chart_json["cpu"] = cpuInfo;
        _this.chart_json["mem"] = memInfo;
        _this.chart_json["disk"] = diskJson;
        // 初始化 || 刷新
        if (_this.chart_view.disk == undefined) {
          _this.init_chart_view();
        } else {
          _this.set_chart_data();
        }
        $(".rank .titles").show();

        var net_key = bt.get_cookie("network_io_key");
        if (net_key) {
          res.up = res.network[net_key].up;
          res.down = res.network[net_key].down;
          res.downTotal = res.network[net_key].downTotal;
          res.upTotal = res.network[net_key].upTotal;
          res.downPackets = res.network[net_key].downPackets;
          res.upPackets = res.network[net_key].upPackets;
          res.downAll = res.network[net_key].downTotal;
          res.upAll = res.network[net_key].upTotal;
        }
        var net_option = '<option value="all">全部</option>';
        $.each(res.network, function (k, v) {
          var act = k == net_key ? "selected" : "";
          net_option +=
            '<option value="' + k + '" ' + act + ">" + k + "</option>";
        });

        $('select[name="network-io"]').html(net_option);

        //刷新流量
        $("#upSpeed").html(res.up.toFixed(2) + " KB");
        $("#downSpeed").html(res.down.toFixed(2) + " KB");
        $("#downAll").html(bt.format_size(res.downTotal));
        $("#upAll").html(bt.format_size(res.upTotal));
        index.net.add(res.up, res.down);

        var disk_key = bt.get_cookie("disk_io_key") || "ALL",
          disk_io_data = res.iostat[disk_key || "ALL"],
          mb = 1048576,
          ioTime =
            disk_io_data.write_time > disk_io_data.read_time
              ? disk_io_data.write_time
              : disk_io_data.read_time;
        $("#readBytes").html(bt.format_size(disk_io_data.read_bytes));
        $("#writeBytes").html(bt.format_size(disk_io_data.write_bytes));
        $("#diskIops").html(
          disk_io_data.read_count + disk_io_data.write_count + " 次"
        );
        $("#diskTime")
          .html(ioTime + " ms")
          .css({
            color:
              ioTime > 100 && ioTime < 1000
                ? "#ff9900"
                : ioTime >= 1000
                ? "red"
                : "#20a53a",
          });

        index.iostat.add(
          (disk_io_data.read_bytes / mb).toFixed(2),
          (disk_io_data.write_bytes / mb).toFixed(2),
          disk_io_data
        );

        var disk_option = "";
        $.each(res.iostat, function (k, v) {
          disk_option +=
            '<option value="' +
            k +
            '" ' +
            (k == disk_key ? "selected" : "") +
            ">" +
            (k == "ALL" ? "全部" : k) +
            "</option>";
        });
        $('select[name="disk-io"]').html(disk_option);

        if (index.net.table)
          index.net.table.setOption({
            xAxis: { data: index.net.data.aData },
            series: [
              { name: lan.index.net_up, data: index.net.data.uData },
              {
                name: lan.index.net_down,
                data: index.net.data.dData,
              },
            ],
          });
        if (index.iostat.table)
          index.iostat.table.setOption({
            xAxis: { data: index.iostat.data.aData },
            series: [
              { name: "读取字节数", data: index.iostat.data.uData },
              {
                name: "写入字节数",
                data: index.iostat.data.dData,
              },
            ],
          });
        if (callback) callback(res);
      });
    },
    clsoeDialog() {
      this.dialogCreate = false;
      this.dialogAddShow = false;
    },
    logout() {
      const that = this;
      this.$confirm("即将登出后台（程序会继续后台运行）, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          that.$message({
            type: "success",
            message: "登出成功!",
          });
          sessionStorage.clear();
          localStorage.clear();
          Cookies.remove("Admin-Token");
          that.$store.dispatch("user/logout");
          setTimeout(() => {
            that.$router.push(`/login?redirect=${that.$route.fullPath}`);
          }, 1000);
        })
        .catch(() => {});
    },
  },
};
</script>
<style lang="scss" scoped>
.wrap {
  width: 100%;
  height: 500px;
}
</style>

<style lang="scss" scoped>
//  <!-- 0323添加的内容 -->
.serve-inter-box {
  margin-right: 20px;
}

.top-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px;
  margin-bottom: 10px;

  .top-info-2 {
    background: #ccc;
    padding: 5px;
    margin: 0 10px;

    a {
      color: #409eff;
      cursor: pointer;
      margin-left: 10px;
    }
  }

  .top-info-3 {
    background: #55a030;
    padding: 5px;
    cursor: pointer;
    margin-left: 10px;
    border-radius: 3px;
    color: #fff;
  }

  .btn {
    border: 1px solid #ccc;
    padding: 5px 10px;
    border-radius: 3px;
    cursor: pointer;
  }
}

.header-text {
  font-size: 16px;
  font-weight: bold;
  margin: 0;
  height: 37px;
  line-height: 30px;
  border-bottom: 1px solid #ccc;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both
}

.box-card {
  width: 480px;
}
.status-box {
  padding: 10px;

  .status-p {
    margin: 5px 0;
  }

  .icon-que {
    margin-left: 10px;
    color: #ccc !important;
  }

  .progress-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    text-align: center;
    width: 90%;
    margin: 20px auto 0;
  }
}

.interface {
  display: flex;
  flex-flow: wrap;
}

.interface > div {
  width: 25%;
  height: 100px;
  text-align: center;
  margin-bottom: 20px;

  .image {
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .preview-btn {
    cursor: pointer;
    border: 1px solid #ccc;
    padding: 5px;
    font-size: 14px;
    margin-right: 10px;
  }
}

//  <!-- 0323添加的内容 -->
.interface-box-column {
  display: flex;

  .interface-right-container,
  .interface-left-container {
    width: 50%;
  }

  .interface-left,
  .interface-right {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
  }

  .interface-left {
    margin-right: 10px;

    .sname,
    .product-name,
    .sf-hidden {
      font-size: 12px;
      line-height: 20px;
    }
  }

  .interface-right {
    margin-left: 10px;

    .flow-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 37px;
      border-bottom: 1px solid #ccc;

      span {
        font-size: 16px;
        color: #55a030;
        padding-bottom: 10px;
        border-bottom: 3px solid #55a030;
      }

      select {
        font-size: 14px;
      }
    }

    .flow-count {
      display: flex;
      justify-content: space-between;
      align-items: center;

      .flow-count-article {
        p {
          margin: 0;
          margin-top: 10px;
        }
      }
    }

    .flow-chart {
      margin-top: 20px;
    }
  }
}

/*.new-content-right {*/
/*  width: calc(100vw - 210px);*/
/*}*/
.bg-green {
  background: url("../../../assets/top-bg-50.png") no-repeat;
  background-size: 100% 100%;
}

.bg-yellow {
  background: url("../../../assets/top-bg-70.png") no-repeat;
  background-size: 100% 100%;
}

.bg-red {
  background: url("../../../assets/top-bg.png") no-repeat;
  background-size: 100% 100%;
}

.title-box {
  padding: 0 20px;
  height: 50px;
  min-width: 200px;

  .item-title {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 50px;
    background: #0dff0d;
  }

  .icon-green {
    background: #55a030;
    width: 100%;
    height: 6px;
  }

  .icon-yellow {
    background: #e6a23c;
    width: 100%;
    height: 6px;
  }

  .icon-red {
    background: #f56c6c;
    width: 100%;
    height: 6px;
  }
}
</style>
<style lang="scss">
@import "~@/styles/box.scss";
.pl-drawer-select .el-date-editor .el-input__inner{
  padding:0 25px !important;
}
.pl-drawer-select .el-drawer__body{
  padding:10px 20px;
}
.right-closed {
  background: rgba(0, 0, 0, 0.7);
  width: 100%;
  height: 100%;
  position: absolute;
  left: 200px;
  z-index: 999;

  p {
    color: #fff;
    font-size: 30px;
    margin: 0;
    text-shadow: 2px 2px 3px #c6ff29;
  }
}

.vdr.active:before {
  // outline: none;
}

.vdr-stick-tm,
.vdr-stick-ml,
.vdr-stick-mr,
.vdr-stick-bm {
  display: none;
}

.main-box {
  position: relative;
  display: flex;

  .el-tabs {
    .el-tabs__header {
      padding-bottom: 10px;
    }

    .el-tabs__content {
      overflow-x: auto;
    }
  }

  .el-input--medium .el-input__inner {
    height: 30px;
    line-height: 30px;
    border-color: #eee;
    color: #409eff;
    font-family: monospace, monospace;
  }

  .el-select .el-input .el-select__caret {
    color: #0a51e0;
  }

  .el-input__suffix {
    right: 2px;
    top: 2px;
  }

  .is-focus {
    .el-input__suffix {
      top: -4px;
    }
  }

  .el-input--suffix {
    .el-input__inner {
      padding: 0;
    }
  }

  .box-footer {
    display: flex;
    align-items: center;
    font-size: 14px;

    p {
      padding: 0;
      margin: 15px 0 0 15px;
      cursor: pointer;

      &:hover {
        color: blue;
      }
    }
  }

  .right-btn {
    i {
      cursor: pointer;
      margin: 0;

      &:hover {
        font-weight: bold;
      }
    }
  }
}

.active-server {
  color: #ebff10;
  animation: blink 1s linear infinite;
  -webkit-animation: blink 1s linear infinite;
  -moz-animation: blink 1s linear infinite;
  -ms-animation: blink 1s linear infinite;
  -o-animation: blink 1s linear infinite;
}

@keyframes blink {
  0% {
    color: #ebff10;
  }

  50% {
    color: red;
  }

  100% {
    color: #ebff10;
  }
}
</style>
