<template>
  <div class="robots-page">

    <div class="robots-top">
      <!-- <p v-if="domain">域名{{ domain }}百度收录量</p>
      <p v-else="domain">左边域名列表选择要查看的域名</p> -->
      <div class="btn-quick">
        <label>快捷链接：</label>
        <el-button size="mini" icon="el-icon-link" @click="openHref(`https://www.baidu.com/s?wd=site%3A`)" title="点击去看百度site收录结果">百度site收录</el-button>
        <el-button size="mini" icon="el-icon-link" @click="openHref(`https://www.so.com/s?ie=utf-8&amp;q=site%3A`)" title="点击去看360 site收录结	果">360 site收录</el-button>
        <el-button size="mini" icon="el-icon-link" @click="openHref(`https://www.sogou.com/web?query=site%3A`)" title="点击去看搜狗site收录结果">搜狗site收录</el-button>
        <el-button size="mini" icon="el-icon-link" @click="openHref(`http://seo.chinaz.com/`)" title="点击去看站长权重">站长权重</el-button>
        <el-button size="mini" icon="el-icon-link" @click="openHref(`https://www.aizhan.com/cha/`)" title="点击去看爱站权重">爱站权重</el-button>
        <el-button size="mini" icon="el-icon-link" @click="openHref(`https://seo.5118.com/`)" title="点击去看5118权重">5118权重</el-button>

      </div>
      <el-date-picker
        @change="dateChange"
        v-model="date"
        format="yyyy-MM-dd"
        value-format="yyyy-MM-dd"
        type="daterange"
        align="right"
        unlink-panels
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        :picker-options="pickerOptions">
      </el-date-picker>
    </div>

    <el-table
      v-loading="listLoading"
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        prop="domain"
        label="网站域名"
        width="180">
      </el-table-column>

      <el-table-column
        prop="bd_record"
        label="百度收录">
      </el-table-column>

      <el-table-column
        prop="bdyd"
        label="百度移动权重">
      </el-table-column>

      <el-table-column
        prop="bdpc"
        label="百度PC权重">
      </el-table-column>

      <el-table-column
        prop="qh360_search"
        label="360权重">
      </el-table-column>

      <el-table-column
        prop="sg_search"
        label="搜狗权重">
      </el-table-column>

      <el-table-column label="数据更新时间" width="120">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.create_time | parseTime }}</span>
        </template>
      </el-table-column>

    </el-table>

  </div>
</template>

<script>
  import { parseTime, formatTime } from '@/utils/index'
  import EventBus from "@/utils/eventBus.js";
  import { shouluRecord } from '@/api/report'
  import LineChart from './components/LineChart'

  export default {
    filters: {
      parseTime(value) {
        return formatTime(value, '{y}-{m}-{d}')
      }
    },
    props: {
      sid: Number,
      rowData: {
        type: Object,
        default: ''
      }
    },
    data() {
      return {
        listLoading: false,
        date: [],
        tableData: [],
        domain: '',
        pickerOptions: {
          disabledDate(time) {
            return time.getTime() > Date.now();
          },
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }]
        },
      }
    },
    created() {
      this.getTimeFn()
      if (this.rowData && this.rowData.domain) {
        this.domain=this.rowData.domain
        if(this.date[0]) {
          this.getList()
        }
      }

    },
    mounted() {
      EventBus.$on('row', (row) =>{
        this.domain = row.domain
        if(this.domain && this.date[0]) {
          this.getList()
        }
      })
    },
    methods: {
      dateChange(val) {
        if(val[0] && val[1]) {
          this.date = val
          this.getList()
        }
      },
      getList() {
        if(!this.domain) {
          return this.$message.info('左边域名列表点击选择要查看的域名');
        }
        let query = {}
        query.domain = this.domain
        query.start_time = this.date[0]
        query.end_time = this.date[1]
        this.listLoading = true
        shouluRecord(query).then(response => {
          if(response.status) {
            this.tableData = response.data
          }
          this.listLoading = false
        }).catch(err => {
          this.listLoading = false
          console.log(err)
        })
      },
       /**
       * 设置默认时间
       */
      getTimeFn() {
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
        this.date[0] = this.formatDate(start);
        this.date[1] = this.formatDate(end);
      },
      /**
       * 格式化时间
       */
      formatDate(date) {
        var myyear = date.getFullYear();
        var mymonth = date.getMonth() + 1;
        var myweekday = date.getDate();

        if (mymonth < 10) {
          mymonth = "0" + mymonth;
        }
        if (myweekday < 10) {
          myweekday = "0" + myweekday;
        }
        return myyear + "-" + mymonth + "-" + myweekday;
      },
      openHref(path) {
        window.open(path + this.domain)
      }
    },
    watch: {
      sid(val) {
        console.log(val)
        this.tableData = []
      }
    }
  }
</script>

<style lang="scss">
  .robots-page {
    width: calc(100% - 20px);
    margin: 5px;
    padding-top: 5px;
    background-color: #fff;
    .robots-top {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      line-height: .2;
      p {
        color: blue;
        font-size: 14px;
      }
      .btn-quick {
        label {
          color: #999;
          font-size: 12px;
        }
        .el-button--mini, .el-button--mini.is-round {
          padding: 7px 7px!important;
          margin-bottom: 10px;
        }
      }
    }
  }
</style>
