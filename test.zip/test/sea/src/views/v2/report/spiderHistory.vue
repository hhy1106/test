<template>
  <div class="robots-page">

    <div class="robots-top">
      <p v-if="domain">域名{{ domain }}蜘蛛访问走势</p>
      <p v-else="domain">站点所有域名的蜘蛛走势</p>
      <el-button
        class="btn-save"
        type="success"
        icon="el-icon-search"
        :loading="loadingBtn"
        @click="wholeServer"
        size="mini"
      	style="right: 10px">
        站点蜘蛛
      </el-button>

      <el-date-picker
        size="mini"
        @change="dateChange"
        v-model="date"
        format="yyyy-MM-dd"
        value-format="yyyy-MM-dd"
        type="daterange"
        align="right"
        unlink-panels
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        style="margin-top: 4px;margin-right: 110px"
        :picker-options="pickerOptions">
      </el-date-picker>
    </div>

    <div v-loading="listLoading">
      <line-chart :chart-data="lineChartData" :dateList="dateList" />
    </div>

    <div class="table-two-row">
      <el-table
        v-loading="listLoading2"
        :data="top10Data"
        border
        style="width: 46%">
        <el-table-column
          prop="domain"
          label="前10蜘蛛量域名">
        </el-table-column>
        <el-table-column
          prop="count"
          width="100"
          label="蜘蛛数量">
        </el-table-column>
      </el-table>
      <el-table
        v-loading="listLoading2"
        :data="low10Data"
        border
        style="width: 46%">
        <el-table-column
          prop="domain"
          label="倒数10蜘蛛量域名">
        </el-table-column>
        <el-table-column
          prop="count"
          width="100"
          label="蜘蛛数量">
        </el-table-column>
      </el-table>
    </div>

  </div>
</template>

<script>
  import { parseTime, formatTime } from '@/utils/index'
  import EventBus from "@/utils/eventBus.js";
  import { spiderRecord, rankingList } from '@/api/report'
  import LineChart from './components/LineChart'
  import groupSelect from '@/components/group-select'

  export default {
    filters: {
      parseTime(value) {
        return formatTime(value, '{y}-{m}-{d}')
      }
    },
    props: {
      sid: Number,
    },
    components: {
      LineChart,
      groupSelect
    },
    data() {
      return {
        loadingBtn: false,
        listLoading: false,
        listLoading2: false,
        domain: '',
        date: [],
        top10Data: [],
        low10Data: [],
        dateList: [],
        pickerOptions: {
          disabledDate(time) {
            return time.getTime() > Date.now();
          },
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }]
        },
        lineChartData: {
          baiduData: [],
          sougouData: [],
          threeSixZeroData: [],
          shenmaData: [],
          // googleData: [],
          // toutiaoData: [],
          // yahooData: [],
        }
      }
    },
    created() {
      this.getTimeFn()
    },
    mounted() {
      EventBus.$on('row', (row) =>{
        this.domain = row.domain
        if(this.domain) {
          this.top10Data = []
          this.low10Data = []
          this.getList()
        }
      })
      if(this.sid) {
        this.getList()
        this.getRankingList()
      }
    },
    methods: {
      dateChange(val) {
        if(val[0] && val[1]) {
          this.date = val
          this.getList()
          if(!this.domain) {
            this.getRankingList()
          } else {
            this.top10Data = []
            this.low10Data = []
          }
          this.dateList = this.getdiffdate(val[0],val[1])
        }
      },
      wholeServer() {
        this.domain = ''
        this.getList()
        this.getRankingList()
      },
      getList() {
        let query = {}
        query.domain = this.domain
        query.server_id = this.sid
        query.start_time = this.date[0]
        query.end_time = this.date[1]
        this.loadingBtn = true
        this.listLoading = true
        spiderRecord(query).then(response => {
          if(response.status) {
           this.lineChartData = response.message
          }
          this.loadingBtn = false
          this.listLoading = false
        }).catch(err => {
          this.loadingBtn = false
          this.listLoading = false
          console.log(err)
        })
      },
      getRankingList() {
        let query = {}
        query.server_id = this.sid
        query.start_time = this.date[0]
        query.end_time = this.date[1]
        this.loadingBtn = true
        this.listLoading = true
        rankingList(query).then(response => {
          if(response.status) {
           this.top10Data = response.data.top10
           this.low10Data = response.data.low10
          }
          this.loadingBtn = false
          this.listLoading = false
        }).catch(err => {
          this.loadingBtn = false
          this.listLoading = false
          console.log(err)
        })
      },
       /**
       * 设置默认时间
       */
      getTimeFn() {
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
        this.date[0] = this.formatDate(start);
        this.date[1] = this.formatDate(end);
        this.dateList = this.getdiffdate(this.date[0],this.date[1])
      },
      /**
       * 格式化时间
       */
      formatDate(date) {
        var myyear = date.getFullYear();
        var mymonth = date.getMonth() + 1;
        var myweekday = date.getDate();

        if (mymonth < 10) {
          mymonth = "0" + mymonth;
        }
        if (myweekday < 10) {
          myweekday = "0" + myweekday;
        }
        return myyear + "-" + mymonth + "-" + myweekday;
      },
      getdiffdate(stime,etime){
        //初始化日期列表，数组
        var diffdate = new Array();
        var i=0;
        //开始日期小于等于结束日期,并循环
        while(stime<=etime){
          diffdate[i] = stime;
          //获取开始日期时间戳
          var stime_ts = new Date(stime).getTime();
          //增加一天时间戳后的日期
          var next_date = stime_ts + (24*60*60*1000);
          //拼接年月日，这里的月份会返回（0-11），所以要+1
          var next_dates_y = new Date(next_date).getFullYear()+'-';
          var next_dates_m = (new Date(next_date).getMonth()+1 < 10)?'0'+(new Date(next_date).getMonth()+1)+'-':(new Date(next_date).getMonth()+1)+'-';
          var next_dates_d = (new Date(next_date).getDate() < 10)?'0'+new Date(next_date).getDate():new Date(next_date).getDate();

          stime = next_dates_y+next_dates_m+next_dates_d;

          //增加数组key
          i++;
        }
        return diffdate;
      }
    },
    watch: {
      sid(val) {
        this.domain = ''
        this.getList()
        this.getRankingList()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .table-two-row {
    display: flex;
    justify-content: space-evenly;
  }
</style>
