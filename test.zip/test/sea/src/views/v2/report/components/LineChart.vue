<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      // default: '400px'
      default: '60vh'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      required: true
    },
    dateList: {
      type: Array,
      required: true
    },
  },
  data() {
    return {
      chart: null,
      days15: []
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val)
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      this.setOptions(this.chartData)
    },
    setOptions({ baiduData, sougouData, threeSixZeroData, shenmaData } = {}) {
      let rotateNum = 70
      let intervalNum = 0
      this.dateList.length < 9 ? rotateNum = 70 : rotateNum = 70
      this.dateList.length > 31 ? intervalNum = 3 : intervalNum = 0
      this.chart.setOption({
        grid: {// 直角坐标系内绘图网格
          show: true, // 是否显示直角坐标系网格。[ default: false ]
          left:"100px",//grid 组件离容器左侧的距离。
          right:"100px",
          // borderColor:"",//网格的边框颜色
          // bottom: '35%' //
        },
        xAxis: {
          data: this.dateList,
          boundaryGap: false,
          axisTick: {
            show: false
          },
          axisLabel: {
           interval:intervalNum,
           show: true,
           rotate: rotateNum,
           margin: 20, //刻度标签与轴线之间的距离
           textStyle: {
             fontSize: 12, //横轴字体大小
           },
          },
          grid: {
            left: '40%',
            bottom:'35%'
          },
        },
        title: {
          // text: `蜘蛛访问走势`
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          data: ['expected', 'actual']
        },
        series: [{
          name: '百度蜘蛛', itemStyle: {
            normal: {
              color: '#1302f5',
              lineStyle: {
                color: '#1302f5',
                width: 2
              }
            }
          },
          data: baiduData,
          smooth: true,
          type: 'line',
          animationDuration: 2800,
          animationEasing: 'cubicInOut'
        },
        {
          name: '搜狗蜘蛛', itemStyle: {
            normal: {
              color: '#FF005A',
              lineStyle: {
                color: '#FF005A',
                width: 2
              }
            }
          },
          data:sougouData,
          smooth: true,
          type: 'line',
          animationDuration: 2800,
          animationEasing: 'cubicInOut'
        },
        {
          name: '360蜘蛛', itemStyle: {
            normal: {
              color: '#a7f100',
              lineStyle: {
                color: '#a7f100',
                width: 2
              }
            }
          },
          data:threeSixZeroData,
          smooth: true,
          type: 'line',
          animationDuration: 2800,
          animationEasing: 'cubicInOut'
        },
        {
          name: '神马蜘蛛', itemStyle: {
            normal: {
              color: '#0d520c',
              lineStyle: {
                color: '#0d520c',
                width: 2
              }
            }
          },
          data:shenmaData,
          smooth: true,
          type: 'line',
          animationDuration: 2800,
          animationEasing: 'cubicInOut'
        }]
      })
    },
  }
}
</script>
