<template>
  <div class="app-container">
    <aside>词库管理</aside>
    <div class="upload-wrap">
      <div class="left">
        <el-alert
          style="text-align: left;margin-bottom: 15px;"
          title="域名输入说明:"
          type="info"
          description="请输入一个已建站的域名来绑定右侧要上传的词库,若不输入域名则作为全局词库上传"
          show-icon>
        </el-alert>
        <el-autocomplete
          class="inline-input"
          v-model="domainInput"
          :trigger-on-focus="false"
          :fetch-suggestions="querySearchAsync"
          placeholder="请输入该词库对应的域名"
          @select="handleSelect"
          @clear="clearInput"
          @blur="blurInput($event)"
          style="margin-bottom: 15px;width: 360px;"
        >
          <i
            v-if="pass"
            class="el-icon-success el-icon-success-domain"
            slot="suffix">
          </i>
          <i
            v-if="!pass"
            class="el-icon-warning el-icon-success-domain"
            slot="suffix">
          </i>
        </el-autocomplete>
      </div>
      <div class="right">
        <el-upload
          drag
          class="upload"
          ref="upload"
          action="string"
          :file-list="fileList"
          :auto-upload="false"
          :http-request="uploadFile"
          :on-change="handleChange"
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          accept=".txt"
          >
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将词库TXT文件拖到此处，或<em>点击导入</em></div>
          <div class="el-upload__tip" slot="tip" style="margin: 10px 0">只能上传txt文件</div>
        </el-upload>
        <el-button
          style="margin-left: 10px;"
          size="small"
          type="success"
          @click="submitUpload"
        >上传到服务器</el-button>
      </div>
    </div>

    <el-button type="danger" @click="deleteRow" style="margin: 0 0 15px auto; float: right;"><i class="el-icon-delete"></i>一键清空列表</el-button>
    <!-- 展示列表 -->
    <el-table :data="ckList" stripe border fit highlight-current-row
      style="width: 100%;">

      <el-table-column
        label="序号"
        type="index"
        width="50">
      </el-table-column>

      <el-table-column show-overflow-tooltip label="站点域名">
        <template slot-scope="{row}">
          <span @click="handleCopy(row.domain,$event)">{{ row.domain || row.site_id }}</span>
        </template>
      </el-table-column>

      <el-table-column prop="word" show-overflow-tooltip label="关键词">
      </el-table-column>

      <el-table-column show-overflow-tooltip label="引用次数" width="90">
        <template slot-scope="{row}">
          <span>{{ row.quote_num }}</span>
        </template>
      </el-table-column>

      <el-table-column label="引用时间">
        <template slot-scope="scope">
          <i class="el-icon-time"></i>
          <span style="margin-left: 10px">{{ scope.row.quote_time | parseTime }}</span>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="primary" plain size="mini" @click="editForm(scope.row)">编辑</el-button>
          <!-- <el-button type="success" plain size="mini" @click="deleteRow(scope.row)">删除</el-button> -->
        </template>
      </el-table-column>

    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="page" :limit.sync="limit" @pagination="getKeywordsList" />

    <!-- 添加/编辑分组 -->
    <el-dialog :visible.sync="dialogEdit" title="编辑" width="560px" :close-on-click-modal="false">
      <el-form ref="form" :model="formAdd" label-width="70px">

        <el-form-item label="关键词：">
          <el-input type="textarea" wrap="off" v-model="formAdd.word" style="width: 100%;"></el-input>
        </el-form-item>

      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitUpdate">提交</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  import EventBus from "@/utils/eventBus.js";
  import { parseTime, formatTime } from '@/utils/index'
  import Pagination from '@/components/Pagination'
  import {
    getToken
  } from '@/utils/auth'
  import {
    websiteList
  } from '@/api/website'
  import {
    keywordsList,
    keywordsImport,
    keywordsClear,
    keywordsEdit
  } from '@/api/keywords'
  export default {
    components: {
      Pagination
    },
    filters: {
      parseTime(value) {
        return formatTime(value, '{y}-{m}-{d}')
      }
    },
    data() {
      return {
        total: 0,
        page: 1,
        limit: 10,
        dialogEdit: false,
        domainInput: '',
        siteId: '',
        actionUrl: `/api/website/importck`,
        fileList: [],
        domainList: [],
        pass: false,
        ckList: [],
        formAdd: {
          siteid: '',
          kwid: '', // 词id
          word: '',
        }
      }
    },
    mounted() {
     if(this.$route.query.ym) {
       this.domainInput = this.$route.query.ym
       this.getSiteListsingle()
     }
      EventBus.$on('orderCK', (order) =>{
      console.log(order)
        if(order) {
          this.domainInput = order
        }
      })
    },
    methods: {
      delFile () {
        this.fileList = []
      },
      editForm(row) {
        this.formAdd.word = row.word
        this.formAdd.siteid = row.site_id
        this.formAdd.kwid = row.id
        this.dialogEdit = true
      },
      submitUpdate() {
        let parmers = {}
        parmers.word = this.formAdd.word
        parmers.siteid = this.formAdd.siteid
        parmers.kwid = this.formAdd.kwid
        keywordsEdit(parmers).then(res => {
          if(res.status) {
            this.$message({
              type: 'success',
              message: res.message
            });
            this.dialogEdit = false
            this.getKeywordsList()
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
      },
      getKeywordsList() { // 查
        let query = {}
        query.page = this.page
        query.limit = this.limit
        query.siteid = this.siteId
        keywordsList(query).then(response => {
          if(response.status) {
            this.ckList = response.data.list
            this.total = response.data.total
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
      },
      getSiteList() { // 查
        let query = {}
        let selectServer = ''
        query.serid = ''
        query.group = ''
        websiteList(query).then(response => {
          if(response.status && response.data.list.length > 0) {
            this.siteId = response.data.list[0].id
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
      },
      handleChange (file, fileList) {
         this.fileList = fileList
        //   此处就是放置在before-upload里的，用于判断可上传文件的格式
         var testmsg = file.name.substring(file.name.lastIndexOf('.') + 1)
         const extension = testmsg === 'txt'
         if (!extension) {
           this.$message(
             {
               message: '上传文件只能是.txt格式!',
               type: 'warning'
             }
           )
         }
         return extension
       },
      deleteRow(row) {
        this.$alert('此操作将永久删除该条词库, 是否继续?', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            if(action == 'confirm') {
              let parmers = {}
              // parmers.append('siteid', row.id); // 单条删除
              parmers.siteid = this.siteId // 清空该域名下所有
              keywordsClear(parmers).then(res => {
                if(res.status) {
                  this.$message({
                    type: 'success',
                    message: '删除成功'
                  });
                  this.getKeywordsList()
                } else {
                  this.$message({
                    type: 'error',
                    message: res.message
                  });
                }
                setTimeout(() => {
                  this.listLoading = false
                }, 1.5 * 1000)
              }).catch(err => {
                console.log(err)
                setTimeout(() => {
                  this.listLoading = false
                }, 1.5 * 1000)
              })
            }
          }
        });
      },
      uploadFile (file) {
        this.formData.append('file', file.file)
      },
      handleRemove (file, fileList) {
        // console.log(file, fileList)
      },
      handlePreview (file) {
        // console.log(file)
      },
      async submitUpload () {
        // 上传到服务器
        if(this.fileList == [] || this.fileList.length < 1) {
          this.$message({
            type: 'info',
            message: '请选择要上传的文件'
          })
          return false
        }
        this.getSiteListsingle()
        let formData = new FormData()
        formData.append('siteid', this.siteId || 0)
        formData.append('file', this.fileList[0].raw)
        keywordsImport(formData).then(response => {
          if(response.status) {
            this.$message({
              type: 'success',
              message: response.message
            });
          } else {
            this.$message({
              type: 'error',
              message: response.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
        this.getKeywordsList()
      },
      getSiteListsingle() { // 查
        let query = {}
        let selectServer = ''
        query.server_ip = ''
        query.serid = ''
        query.group = ''
        query.domain = this.domainInput
        query.status = 1
        query.page = 1
        query.limit = 10
        websiteList(query).then(response => {
          if(response.status) {
            if(response.data.list.length > 0) {
              this.siteId = response.data.list[0].id
              this.domainList = response.data.list
              if(response.data.list[0].domain == this.domainInput) {
                this.pass = true
                if(this.siteId) {
                  this.getKeywordsList()
                }
              }
            } else {
              this.$message({
                type: 'info',
                message: `域名 ${this.domainInput} 无建站记录，请先建站！`
              });
            }
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
      },
      querySearchAsync(queryString, cb) {
        if(queryString == '') {
          this.pass = false
        }
        let query = {}
        let list = [{}]
        let selectServer = ''
        query.server_ip = ''
        query.serid = ''
        query.group = ''
        query.domain = this.domainInput
        query.status = 1
        query.page = 1
        query.limit = 10
        websiteList(query).then(response => {
          if(response.status) {
            if(response.data.list.length > 0) {
              response.data.list[0].value = response.data.list[0].domain
              this.domainList = response.data.list
              for(let i of response.data.list){
                i.value = i.domain;  //将想要展示的数据作为value
              }
              list = response.data.list;
              clearTimeout(this.timeout);
              this.timeout = setTimeout(() => {
                cb(list);
              }, 3000 * Math.random());
            } else {
              this.$message({
                type: 'info',
                message: `域名 ${this.domainInput} 无建站记录，请先建站！`
              });
            }
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
      },
      createStateFilter(queryString) {
        return (state) => {
          return (state.domain.toLowerCase().indexOf(queryString.toLowerCase()) == 0);
        };
      },
      handleSelect(item) {
        this.siteId = item.id
        this.pass = true
        this.getKeywordsList()
      },
      clearInput() {
        this.siteId = ''
        this.domainInput = ''
        this.pass = false
      },
      blurInput(val) {
        if(this.domainInput) {
          this.pass = true
          this.getSiteListsingle()
        }
      }
    },
  }
</script>

<style lang="scss" scoped>
  .upload-wrap {
    // width: 360px;
    display: flex;
    margin-bottom: 20px;
    text-align: center;
    .left {
      width: 360px;
    }
    .right {
      margin-left: 15px;
      width: 360px;
      .el-button--success {
        width: 100%;
      }
    }
  }
  .el-icon-success-domain {
      font-size: 20px;
      color: #18ff18;
      margin: 8px 0 0;
  }
  .el-icon-warning {
    color: red;
  }
</style>
