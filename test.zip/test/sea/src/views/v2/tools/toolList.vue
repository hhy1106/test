<template>
  <div class="left-part">
    <div class="header">
      <h3><i class="el-icon-tickets" />网站列表</h3>
    </div>
    <div class="left-part-list">
        <el-table
          ref="multipleTable"
          :data="siteList"
          tooltip-effect="dark"
          header-cell-class-name="table_header"
          :row-style="{height: '20px'}"
          height="100%"
          @selection-change="handleSelectionChange">
          <el-table-column
            type="selection"
            width="50">
          </el-table-column>
          <el-table-column
            prop="domain"
            label="域名"
          >
          </el-table-column>
          <el-table-column
            align="right"
            width="50">
            <template slot="header" slot-scope="scope">
              <div class="refresh" @click="getSiteList">刷新</div>
            </template>
          </el-table-column>
        </el-table>
 </div>
  </div>
</template>

<script>
  import {
    websiteList
  } from '@/api/website'


  export default {
    props: {
      sid: {},
      titleServer: {}
    },
    data() {
      return {
        siteList: [],
      }
    },
    watch: {
      sid(val) {
        // console.log('服务器id：',val)
        if (val) {
          this.sid = val
          this.getSiteList()
        }
      }
    },
    mounted() {
      if (this.sid) {
        this.getSiteList()
      }
    },
    methods: {
      getSiteList() {
        const query = {}
        query.server_ip = ''
        query.group = '' // 分组
        query.ser_id = this.sid
        query.domain = ''
        query.status = '3'// 站点状态：-1：未解析；0未建站；1等待建站；2建站中；3完成建站；4等待删除；5源站访问失败
        query.page = 1
        query.limit = 2000
        query.desc = ''
        websiteList(query).then(response => {
          if (response.status) {
            this.siteList = response.data.list || []
            console.log(this.siteList,'siteList')
          } else {
            this.$message({
              type: 'error',
              message: res.message
            })
          }
        }).catch(err => {

        })
      },
      handleSelectionChange(val) {
        this.$emit('getToolsBatch',val)
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import "~@/styles/box.scss";
  .left-part{
    width: 430px;
  }
  .left-part-list{
    padding: 0 !important;
    .table{
      position: relative;
      min-width: 428px;
    }
    ::v-deep .el-table__header-wrapper .cell{
      font-size: 12px;
      color: #000000;
      font-weight: normal;
    }
    ::v-deep .table_header{
      height: 30px;
      line-height: 30px;
      padding: 0!important ;
      background: #f5f5f5 !important;
    }
    ::v-deep.el-table--medium td, ::v-deep.el-table--medium th{
      padding: 4px 0;
    }
    .refresh{
      display: flex;
      justify-content: flex-end;
      cursor: pointer;
      font-size: 12px;
      color: #000000;
      font-weight: normal;
    }
  }
</style>

