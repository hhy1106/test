<template>
  <div class="sys-page">
    <div class="checkbox-group">
      <el-button type="success" @click="openPage">死链查询</el-button>
      <el-button type="primary" v-if="!loadingBtn" @click="showDialogClone">克隆站点预览</el-button>
<!--      <el-button type="primary" @click="handleUpdate('update')">批量修改广告</el-button>-->
<!--            <el-button type="primary"  @click="handleUpdate('report')">批量修改统计</el-button>-->
<!--      <el-button type="warning" @click="handleRestart('clone')">重启克隆</el-button>-->
<!--      <el-button type="warning" @click="handleRestart('tinyproxy')">重启站群</el-button>-->
<!--      <el-button type="warning" @click="handleRestart('nginx')">重启Nginx</el-button>-->
<!--      <el-button type="warning" @click="handleRestart('redis')">重启Redis</el-button>-->
      <el-button type="primary" icon="el-icon-loading" v-if="loadingBtn">页面加载中</el-button>
      <!-- <el-button type="success" @click="dialogCk = true">词库管理</el-button> -->
      <!-- <el-button type="success" @click="dialogAd = true">修改广告</el-button> -->
      <!-- <el-button>标题模版</el-button> -->
      <!-- <el-button>修改词库</el-button> -->
      <!-- <el-button>修改企业名</el-button> -->
      <!-- <el-button>批量删站</el-button> -->
      <!-- <el-button>转移分组</el-button> -->
      <!-- <el-button>提取连接</el-button> -->
      <!-- <el-button>查找站点</el-button> -->
      <!-- <el-button>虚拟词链轮</el-button> -->
      <!-- <el-button>批量加友连</el-button> -->
      <!-- <el-button>批量清空</el-button> -->
      <!-- <el-button>提取克隆网址</el-button> -->
      <!-- <el-button>检测网站访问</el-button> -->
      <!-- <el-button>批量检测模版</el-button> -->
      <!-- <el-button>改克隆网址</el-button> -->
      <!-- <el-button>蜘蛛池</el-button> -->
      <!-- <el-button>推送设置</el-button> -->
      <!-- <el-button>干扰+堆词</el-button> -->
    </div>

    <!-- 词库管理组建  -->
    <div class="cuku">
      <el-drawer
        class="pl-drawer"
        title="词库管理"
        :wrapperClosable="false"
        :visible.sync="dialogCk"
        :direction="direction">
        <ciku/>
      </el-drawer>
    </div>

    <!-- 修改广告组建  -->
    <div class="cuku">
      <el-drawer
        class="pl-drawer gold-frame-drawer"
        title="广告管理"
        :wrapperClosable="false"
        :visible.sync="dialogAd"
        :direction="direction">
        <div class="ym-list-left">
        </div>

        <page-config
          :pageSelect="pageType2"
          :showUrlInput="showUrlInput"
          :showPageSelect="showPageSelect"
          :row="row"
        />
      </el-drawer>
    </div>
    <!--    批量修改弹窗-->
    <el-dialog
      :title="updateTitle"
      :visible.sync="updateDia"
      width="90%"
      top="0"
      class="update-dia"
    >
      <div class="update-con">
        <div class="update-left">
          <div class="table">
            <el-table
              ref="multipleTable"
              :data="siteList"
              tooltip-effect="dark"
              style="width: 100%"
              max-height="75vh"

              @selection-change="handleSelectionChange">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
                prop="domain"
                label="域名"
              >
              </el-table-column>

            </el-table>
          </div>
         <div class="res-table" v-if="resDomain && resDomain.length>0">
           <el-timeline  >
             <el-timeline-item
               v-for="(item, index) in resDomain"
               :key="index"
               :icon="item.icon"
               :color="item.color"
               :timestamp="item.content">
               {{item.timestamp}}
             </el-timeline-item>
           </el-timeline>
         </div>
        </div>

        <div class="update-right">
          <code-page :value="codeContent" @input="setInput" />

        </div>
      </div>

      <div class="update-dia-footer">
        <el-button @click="updateDia = false">取 消</el-button>
        <el-button type="primary" @click="submitData">提 交</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
  import EventBus from "@/utils/eventBus.js";
  import ciku from '@/views/v2/tools/keywords'
  import pageConfig from '@/views/v2/website/page'
  import {clonePreview} from '@/api/dns'
  import {
    pluginControll
  } from '@/api/server'
  import {
    websiteList,
    newFileGet
  } from '@/api/website'
  import codePage from './code'

  export default {
    components: {
      ciku,
      pageConfig,
      codePage
    },
    props: {
      sid: {},
      titleServer: {}
    },
    data() {
      return {
        row: {},
        pageType2: 'footjs',
        showUrlInput: true,
        showPageSelect: false,
        loadingBtn: false,
        listLoading: false,
        dialogCk: false,
        dialogAd: false,
        direction: 'btt', // 抽屉方向
        updateDia: false,
        siteList: [],
        multipleSelection: [],
        updateType:'',
        codeContent:'',
        updateTitle:'广告批量修改',
        resDomain:[]
      }
    },
    mounted() {
      EventBus.$on('orderCK', (order) => {
        if (order) {
          console.log(order)
          this.dialogCk = true
        }
      })

    },
    methods: {
      getSiteList() {
        const query = {}
        query.server_ip = ''
        query.group = '' // 分组
        query.ser_id = this.sid
        query.domain = ''
        query.status = '3'// 站点状态：-1：未解析；0未建站；1等待建站；2建站中；3完成建站；4等待删除；5源站访问失败
        query.page = 1
        query.limit = 2000
        query.desc = ''
        websiteList(query).then(response => {
          if (response.status) {
            this.siteList = response.data.list || []
          } else {
            this.$message({
              type: 'error',
              message: res.message
            })
          }

        }).catch(err => {

        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      setInput(code){
        this.codeContent=code
      },
      async submitData(){
        if(!this.codeContent){
          this.$message({
            type: 'error',
            message: '请输入代码内容'
          })
        }else{
          // 提交保存
          if(this.multipleSelection  && this.multipleSelection.length>0 ){
            this.resDomain=[]
            for(let i=0 ; i<this.multipleSelection.length; i++){
              const req={
                domain: this.multipleSelection[i].domain, //站点域名
                type:this.updateType==='update'? 'footjs' :'headjs', // type=footjs修改 统计的参数：type=headjs
                path: "", //type为：other时生效；要修改的URL

              }
              await this.postList(req,{content:this.codeContent})

            }


          }else{
            this.$message({
              type: 'error',
              message: '至少选择一个域名'
            })
          }
        }

      },
      postList(req,data){
        newFileGet(req,data).then(response => {
          const res={
            content:response.message,
            timestamp:req.domain,
          }
          if (response.status) {
              res.color= '#67C23A'
              res.flag=true
              res.icon='el-icon-check'
            // return res
            // this.updateDia=false
            // this.multipleSelection=[]
          } else {
            res.color="#F56C6C"
            res.flag=false
            res.icon='el-icon-close'


            // this.$message({
            //   type: 'error',
            //   message: res.message
            // })
          }
          this.resDomain.push(res)
        }).catch(err => {

        })
      },
      handleUpdate(type) {
        if (this.sid) {
          if(type=='update'){
            this.updateTitle='广告批量修改'
          }else{
            this.updateTitle='广告修改统计'
          }
          this.resDomain=[]
          this.updateDia = true
          this.updateType=type
          this.getSiteList()
        } else {
          this.$message({
            type: 'error',
            message: '请先选择服务器'
          });
        }
      },
      handleRestart(name) {
        this.$alert('确认此操作, 是否继续?', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            if (action == 'confirm') {
              const parmers = {
                server_id: this.sid, //服务器id
                para: this.titleServer, //备注，例如拨号服务器归属(域名 xx.com or  xx.cn)
                "name": name, //服务名字 redis、 nginx、clone、tinyproxy、
                action: "start" //start启动 stop 停止
              }
              pluginControll(parmers).then(res => {
                if (res.message == '操作成功') {
                  this.$message({
                    type: 'success',
                    message: res.message
                  });
                } else {
                  this.$message({
                    type: 'error',
                    message: res.message
                  });
                }
              }).catch(err => {
              })
            }
          }
        });
      },
      openPage() {
        window.open('https://www.deadlinkchecker.com/website-dead-link-checker.asp')
      },
      showDialogClone() {
        this.$prompt('请输入要预览的克隆站点地址', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        }).then(({value}) => {
          this.cloneUrlPreview(value)
        }).catch(() => {
        });
      },
      cloneUrlPreview(cloneUrl) {
        let query = {}
        query.url = cloneUrl
        this.loadingBtn = true
        this.listLoading = true
        clonePreview(query).then(response => {
          if (response) {
            this.$alert('<div class="cloneUrlPreview">' + response + '</div>', '', {
              dangerouslyUseHTMLString: true,
              customClass: 'cloneUrlPreview'
            });
          }
          this.loadingBtn = false
          this.listLoading = false
        }).catch(err => {
          this.loadingBtn = false
          this.listLoading = false
          console.log(err)
        })
      },
    }
  }
</script>

<style lang="scss" scoped>
  .sys-page {
    padding-top: 30px;

    .checkbox-group {
      display: flex;
      flex-wrap: wrap;

      .el-button {
        margin: 10px 8px 30px 20px;
        width: 120px;
        font-size: 14px;
      }
    }

    .el-button {
      margin: 0 20px 50px auto;
      float: right;
    }

    .cuku {
      position: relative;
      z-index: 9999;

      .el-drawer__wrapper {
        z-index: 9999 !important;
      }
    }
  }

  .page-preview {
    display: block;
  }

  .cloneUrlPreview {
    width: 96%;
    height: 90vh;
    overflow-y: auto !important;
  }

  .update-dia {
    .update-dia-footer {
      text-align: right;
      height: 40px;
    }
  }

  .update-con {
    display: flex;
    height: 78vh;
    /*min-height: 50vh;*/
    .update-left {
      min-width: 300px;
      margin-right: 20px;
      max-width: 600px;
      display: flex;
      .table{
        width: 280px;
      }
      .res-table{
        width:300px;
        height: 100%;
        overflow: scroll;
      }
    }

    .update-right {
      flex: 1;
      overflow: hidden;
    }
  }
</style>

