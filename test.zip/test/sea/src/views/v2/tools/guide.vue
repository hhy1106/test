<template>
  <div class="guide-page">

    <el-alert
      title="系统操作使用简易步骤"
      :closable="false"
      style="margin-bottom: 20px"
      type="success">
    </el-alert>

    <el-steps direction="vertical" :active="1">
      <el-step title="步骤一:服务器配置">
        <template slot="description">
           1、首页点击“系统设置”按钮，然后进入服务器管理页面<br>
           <img src="../../../assets/step1.jpg" alt="" style="width: 500px">
           <br><br>
           2、点击“添加服务器”按钮，填写有效的服务器信息，然后提交<br>
           <img src="../../../assets/step2.jpg" alt="" style="width: 500px">
           <br><br>
           3、服务器列表最后一列找到“系统安装”按钮，点击等待自动安装环境<br>
           <img src="../../../assets/step3.jpg" alt="" style="width: 500px">
           <br><br>
           4、若失败，检查后重试，成功后返回首页，进入seo工作台<br><br>
        </template>
      </el-step>
      <el-step title="步骤二:站点操作">
          <template slot="description">
           1、首页点击“seo工作台”按钮，然后进入seo工作台页面<br>
           <img src="../../../assets/step1.jpg" alt="" style="width: 500px">
           <br><br>
           2、最左边栏先选择要操作的服务器<br>
           <img src="../../../assets/step4.jpg" alt="" style="width: 500px">
           <br><br>
           3、第二栏点击“添加站点”按钮，进行建站操作<br>
           <img src="../../../assets/step5.jpg" alt="" style="width: 500px">
           <br><br>
          </template>
      </el-step>
    </el-steps>
  </div>
</template>

<script>
</script>

<style lang="scss">
  .guide-page {
    margin: 20px auto;
    width: 600px;
    .el-step__title {
      font-size: 18px!important;
      font-weight: bold!important;
    }
    .el-step__description {
      font-size: 16px!important;
    }
  }
</style>
