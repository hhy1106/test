<template>
  <div class="sys-page">
    <div class="btn">
      <el-button
        type="success"
        icon="el-icon-circle-check"
        size="mini"
        @click="submitData"
      >保存修改
      </el-button>
    </div>
    <div class="update-con">
      <div class="update-left" v-if="resDomain && resDomain.length>0">
        <div class="res-table" >
          <el-timeline  >
            <el-timeline-item
              v-for="(item, index) in resDomain"
              :key="index"
              :icon="item.icon"
              :color="item.color"
              :timestamp="item.content">
              {{item.timestamp}}
            </el-timeline-item>
          </el-timeline>
        </div>
      </div>

      <div class="update-right">
        <div class="list-item"  v-if="isFrom==='fanzhanqun'">
          <span>影响范围:</span>
          <el-radio-group v-model="zone">
            <el-radio label="account">当前账户</el-radio>
            <el-radio label="group">{{groupName}}分组</el-radio>
            <el-radio label="site">当前站点：{{checkDomain}}</el-radio>
          </el-radio-group>
        </div>
        <code-page :value="codeContent" :type="type" @input="setInput" />
      </div>
    </div>


  </div>
</template>

<script>
  import {
    websiteList,
    newFileGet
  } from '@/api/website'
  import {
    getSiteInfo,
    batchPostFile
  }from '@/api/moreSite'
  import codePage from './code'

  export default {
    components: {
      codePage
    },
    props: {
      isFrom:{}, // 默认是功能大全，泛站群是fanzhanqun
      checkDomain:{// 泛站群选中的域名
        type:String,
        default:''
      },
      groupName:{
        type:String,
        default:''
      },
      site_id:{},
      sid: {},
      titleServer: {},
      type:{},
      toolsWebList:{},
      showPage:false

    },
    data() {
      return {
        row: {},
        codeContent:'',
        resDomain:[],
        zone:'account',
        currentGroupName:'',
        currentSiteId:''
      }
    },
    watch:{

    },
    mounted() {
      // if(this.isFrom==='fanzhanqun'){
      //   if(this.checkDomain){
      //     this.getSite()
      //   }else{
      //     this.$message({
      //       type: 'error',
      //       message: '请选择域名'
      //     })
      //   }
      // }
    },
    methods: {
      getSite(){
        //选中的是泛站群就调用moreSiteOne 组件下面的方法
        getSiteInfo({
          domain: this.checkDomain
        }).then(response => {
          if (response.status) {
            const res = response.data
            if (res) {
              this.currentGroupName= res?.igroup || 'defult',
                this.currentSiteId=res?.id
            }
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      },
      setInput(code){
        this.codeContent=code
      },
      async submitData(){
        if(!this.codeContent){
          this.$message({
            type: 'error',
            message: '请输入代码内容'
          })
        }else{
          if(this.isFrom==='fanzhanqun'){
            // 泛站群
            // 提交保存
            if(this.checkDomain){
              this.resDomain=[]
              const req={
                domain:this.checkDomain,
                zone:this.zone,
                site_id:this.site_id,
                type:this.type==='update'? 'footjs' :'headjs', // type=footjs修改 统计的参数：type=headjs
               }
               if(this.site_id){
                 batchPostFile(req,{
                   content:this.codeContent
                 }).then(response => {
                   const res={
                     content:response.message,
                     timestamp:req.domain,
                   }
                   if (response.status) {
                     res.color= '#67C23A'
                     res.flag=true
                     res.icon='el-icon-check'
                     // return res
                     // this.updateDia=false
                     // this.toolsWebList=[]
                   } else {
                     res.color="#F56C6C"
                     res.flag=false
                     res.icon='el-icon-close'
                   }
                   this.resDomain.push(res)
                 }).catch(err => {

                 })
               }else{
                 this.$message({
                   type: 'error',
                   message: '请选择域名'
                 })
               }



            }else{
              this.$message({
                type: 'error',
                message: '请选择域名'
              })
            }

          }else{
            // 功能大全
            // 提交保存
            if(this.toolsWebList  && this.toolsWebList.length>0 ){
              this.resDomain=[]
              let reqList=[]
              for(let i=0 ; i<this.toolsWebList.length; i++){
                const req={
                  domain: this.toolsWebList[i].domain, //站点域名
                  type:this.type==='update'? 'footjs' :'headjs', // type=footjs修改 统计的参数：type=headjs
                  path: "", //type为：other时生效；要修改的URL
                }
                reqList.push(req)
                // const reqData={
                //    req:req,
                //   data:{content:this.codeContent}
                //  }
                // await this.postList(req,{content:this.codeContent})
              }
              let promiseArray=reqList.map((item)=>{
                return new Promise(resolve => {
                  newFileGet(item,{content:this.codeContent}).then(response => {
                    const res={
                      content:response.message||'',
                      timestamp:item.domain,
                    }
                    if (response.status) {
                      res.color= '#67C23A'
                      res.flag=true
                      res.icon='el-icon-check'
                    } else {
                      res.color="#F56C6C"
                      res.flag=false
                      res.icon='el-icon-close'
                    }
                    resolve(res)
                  })
                  //
                  //
                  //
                  // getUserById([item.userId]).then((resName)=>{
                  //   item['username']=resName.data[0].name
                  //   resolve(item)
                  // })
                })
              })
              Promise.all(promiseArray).then(result => {
                //TODO
                this.resDomain=[...result]
              });
            }else{
              this.$message({
                type: 'error',
                message: '至少选择一个域名'
              })
            }
          }

        }

      },
      postList(req,data){
        newFileGet(req,data).then(response => {
          const res={
            content:response.message,
            timestamp:req.domain,
          }
          if (response.status) {
            res.color= '#67C23A'
            res.flag=true
            res.icon='el-icon-check'
            // return res
            // this.updateDia=false
            // this.toolsWebList=[]
          } else {
            res.color="#F56C6C"
            res.flag=false
            res.icon='el-icon-close'


            // this.$message({
            //   type: 'error',
            //   message: res.message
            // })
          }
          this.resDomain.push(res)
        }).catch(err => {

        })
      },
      handleUpdate() {
        if (this.sid) {
          this.resDomain=[]
          this.getSiteList()
        } else {
          this.$message({
            type: 'error',
            message: '请先选择服务器'
          });
        }
      },


    }
  }
</script>

<style lang="scss" scoped>
  .sys-page{
    width: calc(100% - 40px);
    margin: 20px;

    .btn{
      position: relative;
      height: 40px;
      .el-button--success {
        position: absolute;
        top:-10px;
        right: 2px;
        width: 95px !important;
        height: 28px;
        padding: 0 !important;
        line-height: 20px;
        font-size: 12px;
        background-color: #7eda50 !important;
        border: none !important;
        border-bottom: 2px solid #508c32 !important;
      }
    }

    .update-con {
      display: flex;
      height: 78vh;
      /*min-height: 50vh;*/
      .update-left {
        min-width: 300px;
        margin-right: 20px;
        max-width: 600px;
        display: flex;
        .res-table{
          width:300px;
          height: 100%;
          overflow: scroll;
        }
      }

      .update-right {
        flex: 1 ;
        overflow: hidden;
        .list-item{
          margin-bottom: 20px;
        }
      }
    }
  }


</style>

