<template>
	<div class="app-container bg-gray">
		<aside>系统安全</aside>

    <el-card class="box-card">

      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="系统防火墙" name="first">
          <div>
            <div style="display: flex;margin: 0 0 15px 0;">
              <servers-select
                v-on:selectVal="selectServerFromSon"
                :showAllOpation="false"
              />

              <el-button
                v-if="!loadingBtn2"
                type="danger"
                size="small"
                :loadig="loadingBtn2"
                style="margin: 0 0 0 10px;display:inline-block"
                @click="firewallReload">
                重启防火墙
              </el-button>

              <el-button
                type="info"
                size="small"
                icon="el-icon-loading"
                v-if="loadingBtn2"
                style="margin: 0 10px 0 10px;">
                正在重启中
              </el-button>
            </div>

            防火墙开关
            <el-switch
              size="small"
              @click.native="firewallSwitch"
              v-model="firewallStatus">
            </el-switch>

             <el-divider direction="vertical"></el-divider>

            类型:
            <el-select
              v-model="typeSelect"
              size="small"
              style="margin:0 10px;width:100px">
              <el-option
                v-for="(index,item) in firewallType"
                :label="item.label"
                :key="item.value"
                :value="item.value">
              </el-option>
            </el-select>
            <label v-if="typeSelect == 'port'">协议:</label>
            <el-select
              v-if="typeSelect == 'port'"
              v-model="protocol"
              size="small"
              style="margin:0 10px;width:100px">
              <el-option
                v-for="(index,item) in protocolList"
                :label="item.label"
                :key="item.value"
                :value="item.value">
              </el-option>
            </el-select>

            <el-input
              v-if="typeSelect == 'port'"
              v-model="port"
              size="small"
              placeholder=""
              placeholder="端口"
              style="width:100px">
            </el-input>
            <el-input
              v-if="typeSelect == 'blockIp'"
              v-model="port"
              size="small"
              placeholder=""
              placeholder="欲屏蔽的ip"
              style="width:180px">
            </el-input>

           <!-- <el-input
              v-model="desc"
              size="small"
              placeholder="备注/说明"
              style="margin: 0 10px;width:200px">
            </el-input> -->

            <el-button
              type="success"
              size="small"
              v-if="!loadingBtn"
              :loadig="loadingBtn"
              style="margin: 0 10px 0 10px;"
              @click="firewallCreate">
              <span v-if="typeSelect == 'port'">放行</span>
              <span v-if="typeSelect == 'blockIp'">屏蔽</span>
            </el-button>

            <el-button
              type="info"
              size="small"
              icon="el-icon-loading"
              v-if="loadingBtn"
              style="margin: 0 10px 0 10px;">
              执行中
            </el-button>

            <el-link icon="el-icon-info" type="info" :underline="false" v-if="typeSelect == 'port'">说明: 支持放行端口范围，如: 3000:3500</el-link>
            <el-link icon="el-icon-info" type="warning" :underline="false" v-if="typeSelect == 'blockIp'">说明: 支持屏蔽IP段，如: 192.168.0.0/24</el-link>

          </div>

          <!-- 展示列表 -->
          <el-table
            v-if="typeSelect == 'port'"
            ref="multipleTable"
            :data="portlist"
            stripe border fit highlight-current-row
            style="width: 100%;margin-top:20px;">

            <el-table-column label="协议">
              <template slot-scope="{row}">
                <span>{{ row.protocol }}</span>
              </template>
            </el-table-column>

            <el-table-column label="端口">
              <template slot-scope="{row}">
                <span>{{ row.port }}</span>
              </template>
            </el-table-column>

            <el-table-column label="操作" width="212">
              <template slot-scope="scope">
                <el-button
                  class="el-btn--mini"
                 type="danger" plain size="mini"
                 @click="deleteRow('port',scope.row)">
                 <i class="el-icon-delete"></i>删除</el-button>
              </template>
            </el-table-column>

          </el-table>

          <el-table
            v-if="typeSelect == 'blockIp'"
            ref="multipleTable"
            :data="iplist"
            stripe border fit highlight-current-row
            style="width: 100%;margin-top:20px;">

            <el-table-column label="IP地址">
              <template slot-scope="{row}">
                <span>{{ row.address }}</span>
              </template>
            </el-table-column>

            <el-table-column label="类型">
              <template slot-scope="{row}">
                <span>{{ row.type }}</span>
              </template>
            </el-table-column>

            <el-table-column label="操作" width="212">
              <template slot-scope="scope">
                <el-button
                  class="el-btn--mini"
                 type="danger" plain size="mini"
                 @click="deleteRow('ip',scope.row)">
                 <i class="el-icon-delete"></i>删除</el-button>
              </template>
            </el-table-column>

          </el-table>
        </el-tab-pane>

        <el-tab-pane label="SSH管理" name="second">
          <ssh-page  v-if="showSsh" />
        </el-tab-pane>

      </el-tabs>

    </el-card>


  </div>
</template>
<script>
import {
  firewallList,
  firewallReload,
  firewallSwitch,
  firewallAddIp,
  firewallDelIp,
  firewallAddport,
  firewallDelport,
} from '@/api/system'

import sshPage from "@/views/v2/system/components/ssh"
import serversSelect from '@/components/servers-select'

export default {
  components: {
    sshPage,
    serversSelect
  },
  data() {
    return {
      activeName: 'first',
      serverId: null,
      page: 1,
      limit: 10,
      total: 0,
      port: '',
      desc: '',
      iplist: [],
      portlist: [],
      showSsh: false,
      firewallStatus: false,
      loadingBtn: false,
      loadingBtn2: false,
      typeSelect: 'port',
      protocol: 'tcp',
      protocolList: [
        {
          value: 'tcp',
          label: 'TCP'
        },{
          value: 'udp',
          label: 'UDP'
        }
      ],
      firewallType: [
        {
          value: 'port',
          label: '端口'
        },{
          value: 'blockIp',
          label: '屏蔽ip'
        }
      ]
    }
  },
  mounted() {
  },
  methods: {
    handleClick(tab, event) {
      tab.name == 'second' ? this.showSsh = true : this.showSsh = false
    },
    getFirewallList() { // 查
      let query = {}
      query.page = this.page
      query.limit = this.limit
      query.sid = this.serverId
      firewallList(query).then(response => {
        if (response.status) {
          this.iplist = response.data.iplist
          this.portlist = response.data.ports
          // this.total = response.data.total
        console.log(this.portlist)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    deleteRow(type,row) {
      let parmers = {}
      parmers.sid = this.serverId
      this.$alert('此操作将删除该条数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        callback: action => {
          if(action == 'confirm') {
            if(this.typeSelect == 'port') {
              parmers.append('port', row.port);
              parmers.append('type', row.protocol);
              firewallDelport(parmers).then(response => {
                if (response.status) {
                  this.$message({
                    type: 'success',
                    message: response.message
                  });
                  this.getFirewallList()
                }
              }).catch(err => {
                console.log(err)
              })
            } else if(this.typeSelect == 'blockIp') {
              parmers.append('ip', row.address);
              firewallDelIp(parmers).then(response => {
                if (response.status) {
                  this.$message({
                    type: 'success',
                    message: response.message
                  });
                  this.getFirewallList()
                }
              }).catch(err => {
                console.log(err)
              })
            }
          }
        }
      });
    },
    firewallCreate() {
      this.loadingBtn = true
      if (!this.serverId) {
        this.loadingBtn = false
        return this.$message.info('请先选择要操作的服务器');
      }
      if (this.typeSelect == 'port' && !this.port) {
        this.loadingBtn = false
        return this.$message.info('端口不能为空');
      } else if (this.typeSelect == 'blockIp' && !this.port) {
        this.loadingBtn = false
        return this.$message.info('屏蔽ip不能为空');
      }
      let parmers = {}
      parmers.sid = this.serverId
      parmers.type = this.protocol
      // parmers.append('desc', this.desc);
      if(this.typeSelect == 'port') {
        parmers.append('port', this.port);
        firewallAddport(parmers).then(res => {
          if (res.status) {
            this.loadingBtn = false
            this.$message({
              type: 'success',
              message: res.message
            });
            this.getFirewallList()
          }
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        }).catch(err => {
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      } else if(this.typeSelect == 'blockIp') {
        parmers.append('ip', this.port);
        firewallAddIp(parmers).then(res => {
          if (res.status) {
            this.$message({
              type: 'success',
              message: res.message
            });
            this.getFirewallList()
          }
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        }).catch(err => {
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      }

    },
    firewallSwitch() {
      let title = ''
      let command = ''
      if(this.firewallStatus) {
        title = '开启'
        command = 'start'
      } else {
        title = '关闭'
        command = 'stop'
      }
      this.$confirm(`${title}系统防火墙，继续操作?`, '操作确认', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        if (!this.serverId) {
          this.firewallStatus = !this.firewallStatus
          return this.$message.info('请选择要操作的服务器');
        }
        if (!command) {
          this.firewallStatus = !this.firewallStatus
          return this.$message.info('指令不正确');
        }
        this.$message.info('指令执行中...');
        let parmers = {}
        parmers.sid = this.serverId
        parmers.command = command

        firewallSwitch(parmers).then(res => {
          if (res.status) {
            this.$message({
              type: 'success',
              message: res.message
            });
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
        }).catch(err => {
          console.log(err)
        })
      }).catch(() => {
        this.$message.info('已取消操作');
        this.firewallStatus = !this.firewallStatus
        return
      });
    },
    firewallReload() {
      if (!this.serverId) {
        return this.$message.info('请选择要操作的服务器');
      }
      this.$alert('此操作将重启防火墙, 是否继续?', '提示', {
        confirmButtonText: '确定',
        callback: action => {
          if(action == 'confirm') {
            this.loadingBtn2 = true
            this.$message.info('重启执行中，请稍后...');
            let parmers = {}
            parmers.sid = this.serverId
            firewallReload(parmers).then(response => {
              if (response.status) {
                this.$message.success('重启防火墙成功！');
              }
              this.loadingBtn2 = false
            }).catch(err => {
              console.log(err)
              this.loadingBtn2 = false
            })
          }
        }
      });
    },
    selectServerFromSon(msg, list) {
      if(msg) {
        list.forEach((item) => {
          if(item.value == msg) {
            this.serverId =item.sid
            this.getFirewallList()
            this.page = 1
          }
        })
      }
    }
  },
  watch:{
    typeSelect(val) {
      this.getFirewallList()
      this.page = 1
    }
  }
}
</script>

<style lang="scss" scoped>
  @import "~@/styles/common.scss";
</style>

<style lang="scss">
</style>
