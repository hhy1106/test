<template>
  <div class="app-container bg-gray page-load">

    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <div class="title-load">
          <span>负载状态</span>
          <servers-select v-on:selectVal="selectServerFromSon" :showAllOpation="false" />
          <i class="el-icon-refresh" @click="getList()" style="float:right;cursor: pointer;"></i>
        </div>
      </div>
      <div class="load-status" v-if="showList">
          <div>
            <h6>负载状态</h6>
            <el-tooltip class="item" effect="dark" placement="bottom">
              <el-progress
                type="circle"
                :percentage="dataList.load.one"
                :color="colors"
                :stroke-width="circleWidth"
                :width="110">
              </el-progress>
              <div slot="content" class="tips-content">
                <p>最近1分钟平均负载：{{ dataList.load.one }}</p>
                <p>最近5分钟平均负载：{{ dataList.load.five }}</p>
                <p>最近15分钟平均负载：{{ dataList.load.fifteen }}</p>
                <p>user：{{ 0 }}</p>
                <p>nice：{{ 0 }}</p>
                <p>system：{{ 0 }}</p>
                <p>idle：{{ 0 }}</p>
                <p>iowait：{{ 0 }}</p>
                <p>irq：{{ 0 }}</p>
                <p>softirq：{{ 0 }}</p>
                <p>steal：{{ 0 }}</p>
                <p>guest：{{ 0 }}</p>
                <p>guest_nice：{{ 0 }}</p>
                <p>总进程数：{{ 0 }}</p>
                <p>总活动数：{{ 0 }}</p>
              </div>
            </el-tooltip>
            <h6>运行流畅</h6>
          </div>

          <div>
            <h6>CPU使用率</h6>
            <el-tooltip class="item" effect="dark" placement="bottom">
              <el-progress type="circle" :percentage="dataList.cpu[0]" :color="colors" :stroke-width="circleWidth" :width="110"></el-progress>
              <div slot="content" class="tips-content">
                <p>{{ dataList.cpu[3] }}</p>
                <p>{{ dataList.cpu[4] }}个物理cpu,{{ dataList.cpu[5] }}个物理核心</p>
                <p v-for="(item, index) in dataList.cpu[2]" :key="index">CPU-{{ (index+1) }}: {{ item }}%</p>
              </div>
            </el-tooltip>
            <h6>{{ dataList.cpu[1] }}核心</h6>
          </div>

        <div>
          <h6>CPU内存使用率</h6>
          <el-progress type="circle" :percentage="filterData(dataList.mem.memRealUsed/dataList.mem.memTotal)" :color="colors" :stroke-width="circleWidth" :width="110"></el-progress>
          <h6>{{ dataList.mem.memRealUsed }} / {{ dataList.mem.memTotal }}(MB)</h6>
        </div>

        <div v-for="item in dataList.disk">
          <h6>{{ item.path }}</h6>
          <el-tooltip
            class="item"
            effect="dark"
            placement="bottom">
           <el-progress
              type="circle"
              :percentage="parseFloat(item.size[3].replace('%',''))"
              :color="colors"
              :stroke-width="circleWidth"
              :width="110">
            </el-progress>
            <div slot="content" class="tips-content">
              <p class="title">基础信息</p>
              <div>
                <p>文件系统：{{ item.filesystem }}</p>
                <p>类型：{{ item.type }}</p>
                <p>挂载点：{{ item.path }}</p>
              </div>
             <p class="title">Inode信息</p>
              <div>
                <p>总数：{{ item.inodes[0] }}</p>
                <p>已用：{{ item.inodes[1] }}</p>
                <p>可用：{{ item.inodes[2] }}</p>
              </div>
              <p class="title">容量信息</p>
              <div>
                <p>容量：{{ item.size[0] }}</p>
                <p>已用：{{ item.size[1] }}</p>
                <p>可用：{{ item.size[2] }}</p>
                <p>使用率：{{ item.size[2] }}</p>
              </div>
            </div>
          </el-tooltip>
          <h6>{{ item.size[1] }} / {{ item.size[0] }}</h6>
        </div>
    </div>
  </el-card>

    <el-row :gutter="20">
      <el-col :span="12">
        <el-card class="box-card">
          <software :sid="sid" v-if="showSoft" />
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="box-card">

          <!-- 流量 -->
          <el-select
            v-show="activeName == 'first'"
            v-model="networkVal"
            size="mini"
            @change="networkChange($event)"
            placeholder="全部"
            style="width: 80px;">
            <el-option
              v-for="(item, index) in optionsNetwork"
              :key="item.value"
              :label="item.label" :value="item.label">
            </el-option>
          </el-select>

          <!-- 网络ip -->
          <el-select
            v-show="activeName == 'second'"
            v-model="ioVal"
            size="mini"
            @change="ioChange($event)"
            placeholder="全部"
            style="width: 80px;">
            <el-option
              v-for="(item, index) in optionsIo"
              :key="item.value"
              :label="item.label" :value="item.label">
            </el-option>
          </el-select>

          <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="流量" name="first">
              <div class="chart-title">
                <div class="item">
                  <p><i class="ico-up"></i>上行</p>{{ formatBytes(dataList.up) || '查询中' }}
                </div>
                <div class="item">
                  <p><i class="ico-down"></i>上行</p>{{ formatBytes(dataList.down) || '查询中' }}
                </div>
                <div class="item">
                  <p>总发送</p>{{ formatBytes(dataList.upTotal) || '查询中' }}
                </div>
                <div class="item">
                  <p>总接收</p>{{ formatBytes(dataList.downTotal) || '查询中' }}
                </div>
              </div>
              <p class="chart-tips">单位：KB/s</p>
              <line-chart :chart-data="lineChartData" />
            </el-tab-pane>
            <el-tab-pane label="磁盘IO" name="second">
              <div class="chart-title" v-if="dataList.iostat">
                <div class="item">
                  <p><i class="ico-read"></i>读取</p>{{ formatBytes(dataList.iostat.ALL.read_bytes) || '查询中' }}
                </div>
                <div class="item">
                  <p><i class="ico-write"></i>写入</p>{{ formatBytes(dataList.iostat.ALL.write_bytes) || '查询中' }}
                </div>
                <div class="item">
                  <p>每秒读写</p>{{ dataList.iostat.ALL.write_count }}
                </div>
                <div class="item">
                  <p>IO延迟</p>{{ dataList.iostat.ALL.write_time }}
                </div>
              </div>
              <p class="chart-tips">单位：MB/s</p>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-col>
    </el-row>

  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import clip from '@/utils/clipboard'
  import { parseTime, formatTime } from '@/utils/index'
  import LineChart from '@/components/LineChart'
  import serversSelect from '@/components/servers-select'
  import software from './components/software'
  import {
    pluginGet,
    pluginControll,
    systemLoadStatus
  } from '@/api/server'

  export default {
    components: {
      LineChart,
      serversSelect,
      software
    },
    filters: {
      parseTime(value) {
        return formatTime(value, '{y}-{m}-{d}')
      }
    },
    data() {
      return {
        showSoft: true,
        showList: false,
        networkVal: '',
        optionsNetwork: [],
        ioVal: '',
        optionsIo: [],
        timer: '',
        activeName: 'first',
        circleWidth: 8,
        // colors: [
        //   {color: '#f56c6c', percentage: 20},
        //   {color: '#5cb87a', percentage: 60},
        // ],
        pluginList: [],
        colors: '#f56c6c',
        sid: '', // 服务器ID；宝塔面板的：:8888/system?action=GetNetWork
        total: 0,
        page: 1,
        limit: 10,
        resultType: '1', // 0 全部 1失败 2成功
        dataList: {},
        listLoading: false,
        loadingBtn: false,
        loading: false,
        lineChartData: {
          upData: [],
          downData: []
        },
      }
    },
    created() {
    },
    mounted() {
      if(this.sid) {
        this.timer = setInterval(this.getList, 1000);
      }
    },
    beforeDestroy() {
      clearInterval(this.timer);
    },
    methods: {
      handleClick(tab, event) {
      },
      formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
      },
      filterData(data) {
        let newData = 0
        newData = (Math.round((data))).toFixed(1)
        return parseFloat(newData)
      },
      getList() { // 查
        this.showSoft = false
        this.listLoading = true
        this.loadingBtn = true
        this.loading = true
        let parmers = {}
        if(!this.sid) {
          return this.$message.info('请先选择要查看的服务器');
        }
        parmers.sid = this.sid
        systemLoadStatus(parmers).then(response => {
          if(response) {
            this.dataList = response
            let obj = {}
            let objAll = {
              value: 'all',
              label: '全部'
            }
            this.optionsNetwork = []
            for (let i in this.dataList.network) {
              if (this.dataList.network.hasOwnProperty(i)) {
                obj = this.dataList.network[i]
                obj.value = i;
                obj.label = i;
                this.optionsNetwork.push(obj)
              }
            }
            this.optionsNetwork.unshift(objAll)
            this.lineChartData.upData.push(this.dataList.up)
            this.lineChartData.downData.push(this.dataList.down)
            if(this.lineChartData.upData.length > 7) {
              this.lineChartData.upData = this.lineChartData.upData.slice(this.lineChartData.upData.length - 7, this.lineChartData.upData.length)
            }
            if(this.lineChartData.downData.length > 7) {
              this.lineChartData.downData = this.lineChartData.downData.slice(this.lineChartData.downData.length - 7, this.lineChartData.downData.length)
            }
            this.showList = true
            this.showSoft = true
            console.log(this.dataList.iostat.ALL)
          }
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
            this.loading = false
          }, 1.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
            this.loading = false
            this.showSoft = true
          }, 1.5 * 1000)
        })
      },
      networkChange(data) {
        this.optionsNetwork.forEach((item) => {
          if(item.label == '全部') {
            this.getList()
          }else if(item.label == data) {
            this.dataList = item
            this.lineChartData.upData.push(this.dataList.up)
            this.lineChartData.downData.push(this.dataList.down)
          }
        })
      },
      ioChange(data) {
      },
      loadingClose() {
        const loadingInstance = Loading.service()
        this.$nextTick(() => {
          this.loading = false
          loadingInstance.close()
        })
      },
      handleCopy(text, event) {
        clip(text, event)
      },
      resultChange(data) {
        this.page = 1
      },
      openUrl(path) {
        path.indexOf('http://') < 0 ? path = `http://${path}` : path = path
        window.open(path)
      },
      selectServerFromSon(msg, list) {
        if(msg) {
          list.forEach((item) => {
            if(item.value == msg) {
              this.sid =item.sid
              this.getList()
            }
          })
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
.box-card {
  margin-bottom: 20px;
  .load-status {
    display: flex;
    justify-content: space-around;
    text-align: center;
    h6 {
        text-align: center;
        margin: 15px auto;
        font-size: 15px;
        font-weight: 600;
        color: #666;
    }
    .el-progress {
      cursor: pointer;
    }
  }
}
.tips-content {
  line-height: 24px;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 700;
    color: #03f703;
  }
}
.soft-list {
  display: flex;
  .item {
    text-align: center;
    margin: 0 10px 0;
    i {
      display: block;
      font-size: 50px;
      margin: 0 auto 10px;
    }
  }
}
.chart-title {
  display: flex;
  justify-content: space-around;
  align-items: center;
  text-align: center;
  font-size: 14px;
  color: #666;
  p {
    color: #999;
    i {
      width: 10px;
      height: 10px;
      display: inline-block;
      margin-right: 3px;
      border-radius: 5px;
    }
    .ico-up {
      background-color: #f7b851;
    }
    .ico-down {
      background-color: #52a9ff;
    }
    .ico-read {
      background-color: #FF4683;
    }
    .ico-write {
      background-color: #6CC0CF;
    }
  }
}
.chart-tips {
  margin: 20px 0 0;
  padding: 0;
  font-size: 14px;
  color: #333;
}
</style>

<style lang="scss">
  .page-load {
    .el-progress__text {
      color: #a7a31b;
      font-size: 18px!important;
    }
    .el-select {
      position: absolute;
      right: 30px;
      z-index: 999;
    }
    .title-load {
      display: flex;
      align-items: center;
      .el-select {
        position: static!important;
      }
      .server-select {
        margin: 0 10px 0 auto;
      }
    }
  }
</style>
