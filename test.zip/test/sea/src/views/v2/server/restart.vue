<template>
  <div class="con">
    <el-tabs tab-position="left" style="height: 600px;width: 560px">
      <el-tab-pane label="服务">
        <div class="current">
          当前状态:{{ restatFlag?"开启":"关闭" }}
        </div>
        <div class="btn">
          <el-button type="primary" size="small" @click="handleServer('restart')">重启</el-button>
          <el-button v-if="name!=='adslproxy'" type="primary" size="small" @click="handleServer('start')">开启</el-button>
          <el-button v-if="name!=='adslproxy'" type="primary" size="small" @click="handleServer('stop')">停止</el-button>
        </div>
      </el-tab-pane>
      <el-tab-pane v-if="name==='fluent-bit'||name==='tinyproxy'||name==='nginx'" label="配置修改" >

        <el-select v-model="configKey" placeholder="请选择" @change="changeConfig">
          <el-option
            v-for="(item, index) in configArr"
            :key="index"
            :label="item.key"
            :value="item.key"
          />
        </el-select>
        <el-input
          v-model="configValue"
          type="textarea"
          :autosize="{ minRows: 10, maxRows: 20}"
          placeholder="请输入内容"
          style="margin-top: 20px;min-height: 117px;height: 480px"
        />
        <el-button type="primary" size="small" style="margin-top: 20px" @click="save">保存</el-button>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>

import {
  serverControll,
  readServer,
  writeServer
} from '@/api/server'

export default {
  props: {
    rowData: {
      type: Object,
      default() {
        return {}
      }
    },
    name: {
      type: String,
      default: ''
    },
    restatFlag:
      {
        type: Boolean,
        default: false
      }
  },
  data() {
    return {
      configValue: '',
      configKey: '',
      configArr: [

      ]
    }
  },

  mounted() {
    if (this.name === 'fluent-bit' || this.name === 'tinyproxy' || this.name === 'nginx') {
      this.getServerConfig()
    }
  },

  methods: {
    save() {
      writeServer({
        server_id: this.rowData.id,
        name: this.name,
        filename: this.configKey,
        data: this.configValue
      }).then(response => {
        this.$message({
          type: 'success',
          message: '保存成功'
        })
      })
    },
    changeConfig(value) {
      const obj = this.configArr.find(function(item) {
        return item.key === value
      })
      this.configValue = obj.value
    },
    getServerConfig() {
      readServer({
        server_id: this.rowData.id,
        name: this.name
      }).then(response => {
        if (response.data) {
          for (const key in response.data) {
            const configData = {
              value: response.data[key],
              key: key
            }
            this.configArr.push(configData)
          }
          this.configValue = this.configArr[0].value
          this.configKey = this.configArr[0].key
        }
      })
    },

    handleServer(action) {
      serverControll({
        server_id: this.rowData.id,
        para: this.rowData.iname,
        name: this.name,
        action: action
      }).then(response => {
        if (response.status && action == 'start') {
          this.restatFlag = true
        } else {
          this.restatFlag = false
        }
        this.$message({
          type: 'success',
          message: '操作成功'
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .chart{
    display: flex;

    .chart-item{
     width: 25%;
      text-align: center;

    }
  }
  .soft{
    display: flex;
    justify-content: space-between;
    .soft-item-l{
      width: 30%;
      display: flex;
      .item{
        width: 25%;
      }
    }
    .soft-item-r{
   width: 65%;
      .chart-title{
        display: flex;
        .item{
          width: 20%;
        }
      }
    }
  }

</style>
