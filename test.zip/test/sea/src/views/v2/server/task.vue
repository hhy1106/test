<template>
	<div class="app-container bg-gray">
		<aside>计划任务</aside>

    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>添加计划任务</span>
      </div>
      <el-form ref="formAdd" :model="formAdd" label-width="80px">

        <el-form-item label="任务类型">
          <el-select v-model="formAdd.taskType">
            <el-option
              v-for="item in taskType"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <span style="font-size:12px;color:#666;margin-left:10px;">*任务类型包含以下部分：Shell脚本、备份网站、备份数据库、日志切割、释放内存、访问URL、备份目录、木马查杀、同步时间</span>
        </el-form-item>

        <el-form-item label="任务名称">
          <el-input v-model="formAdd.name" placeholder="请输入计划任务名称" style="width:300px"></el-input>
        </el-form-item>

        <el-form-item label="执行周期">

          <el-select v-model="formAdd.dayType" style="width:100px">
            <el-option
              v-for="(index,item) in dayTypeArr"
              :key="index"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>

          <el-select v-model="formAdd.week" style="width:90px;margin: 0 10px;">
            <el-option
              v-for="item in weekDays"
              :label="item.label"
              :key="item.value"
              :value="item.value">
            </el-option>
          </el-select>

          <el-input type="number" v-model="formAdd.hour" style="width:150px">
              <template slot="append">小时</template>
            </el-input>
            <el-input type="number" v-model="formAdd.minute" style="width:150px;margin: 0 10px;">
                <template slot="append">分钟</template>
              </el-input>
        </el-form-item>

        <el-form-item label="脚本内容">
          <el-input
          type="textarea"
          rows="6"
          v-model="formAdd.code"
          style="max-width: 600px"
          placeholder="请输入脚本内容">
        </el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="success" @click="onSubmit">添加任务</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>任务列表</span>
      </div>

      <!-- 展示列表 -->
      <el-table
        ref="multipleTable"
        :data="dataList"
        stripe border fit highlight-current-row
        style="width: 100%;">

        <el-table-column label="任务名称">
          <template slot-scope="{row}">
            <span>{{ row.iname }}</span>
          </template>
        </el-table-column>

        <el-table-column label="状态">
          <template slot-scope="{row}">
            <span>{{ row.status }}</span>
          </template>
        </el-table-column>

        <el-table-column label="执行周期">
          <template slot-scope="{row}">
            <span>{{ row.cycle }}</span>
          </template>
        </el-table-column>

        <el-table-column label="保存数量">
          <template slot-scope="{row}">
            <span>{{ row.save_local }}</span>
          </template>
        </el-table-column>

        <el-table-column label="	备份到">
          <template slot-scope="{row}">
            <span>{{ row.status }}</span>
          </template>
        </el-table-column>

        <el-table-column label="上次执行时间">
          <template slot-scope="{row}">
            <span>{{ row.addtime }}</span>
          </template>
        </el-table-column>

        <el-table-column label="操作" width="212">
          <template slot-scope="scope">
            <el-button class="el-btn--mini" type="primary" plain size="mini" @click="startTask(scope.row)"><i class="el-icon-edit"></i>执行</el-button>
            <el-button class="el-btn--mini" type="info" plain size="mini" @click="checkLog(scope.row)"><i class="el-icon-edit"></i>日志</el-button>
            <el-button class="el-btn--mini" type="success" plain size="mini" @click="editForm(scope.row)"><i class="el-icon-edit"></i>编辑</el-button>
            <el-button class="el-btn--mini" type="danger" plain size="mini" @click="deleteRow(scope.row)"><i class="el-icon-delete"></i>删除</el-button>
          </template>
        </el-table-column>

      </el-table>
    </el-card>

  </div>
</template>
<script>
  export default {
    data() {
      return {
        dataList: [],
        formAdd: {
          taskType: 'everyday',
          name: '',
          dayType: 'everyweek',
          week: 'monday',
          hour: '1',
          minute: '30',
          code: ''
        },
        dayTypeArr: [
          {
            value: 'everyday',
            label: '每天'
          },{
            value: 'someday',
            label: 'N天'
          },{
            value: 'everyhour',
            label: '每小时'
          },{
            value: 'somehour',
            label: 'N小时'
          },{
            value: 'someminute',
            label: 'N分钟'
          },{
            value: 'everyweek',
            label: '每星期'
          },{
            value: 'everymonth',
            label: '每🈷️'
          }
        ],
        taskType: [
          {
            value: 'everyday',
            label: 'Shell脚本'
          },{
            value: 'someday',
            label: '备份网站'
          },{
            value: 'everyhour',
            label: '备份数据库'
          },{
            value: 'somehour',
            label: '日志切割'
          },{
            value: 'someminute',
            label: '释放内存'
          },{
            value: 'everyweek',
            label: '备份目录'
          },{
            value: 'everymonth',
            label: '木马查杀️'
          },{
            value: 'everyweek',
            label: '同步时间'
          }
        ],
        weekDays: [
          {
            value: 'monday',
            label: '周一'
          },{
            value: 'tusday',
            label: '周二'
          },{
            value: 'wedsday',
            label: '周三'
          },{
            value: 'tuesday',
            label: '周四'
          },{
            value: 'friday',
            label: '周五'
          },{
            value: 'satuadary',
            label: '周六'
          },{
            value: 'sunday',
            label: '周日️'
          }
        ],
      }
    },
    methods: {
      onSubmit() {
        console.log('submit!');
      },
      startTask(row) {
        console.log(row);
      },
      checkLog(row) {
        console.log(row);
      },
      editForm(row) {
        console.log(row);
      },
      deleteRow(row) {
        console.log(row);
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import "~@/styles/common.scss";
</style>

<style lang="scss">
</style>
