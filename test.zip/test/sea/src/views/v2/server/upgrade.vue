<template>
  <div class="app-container page-upgrade">

    <div class="btn-group">
      <!-- <router-link to="/" style="color: blue;margin-right: 10px;">
        <i class="el-icon-back"></i>返回首页
      </router-link> -->

      <el-button
        type="primary"
        @click="dialogCreate = true"
        style="margin-left: auto;">
        <i class="el-icon-plus"></i>
        添加版本升级
      </el-button>
    </div>

    <!-- 展示列表 -->
    <el-table v-loading="listLoading" ref="multipleTable" :data="dataList" stripe border fit highlight-current-row
      style="width: 100%;">
      </el-table-column>

      <el-table-column
        label="序号"
        type="index"
        width="50">
      </el-table-column>

      <el-table-column label="升级类型">
        <template slot-scope="{row}">
          <span v-for="(item,index) in row.allow_biz.split(',')">
            <el-tag size="mini" type="success" v-if="item == 'all'">all全部</el-tag>
            <el-tag size="mini" type="primary" v-if="item == 'clone'">站群克隆</el-tag>
            <el-tag size="mini" type="danger" v-if="item == 'tinyproxy'">多IP代理</el-tag>
            <el-tag size="mini" type="warning" v-if="item == 'adslproxy'">拨号代理</el-tag>
            <el-tag size="mini" type="info" v-if="item == 'none'">无</el-tag>
          </span>
        </template>
      </el-table-column>

      <el-table-column label="版本号">
        <template slot-scope="{row}">
          <el-tag size="mini" type="success">{{ row.version }}</el-tag>
        </template>
      </el-table-column>

      <el-table-column label="是否强制" width="80">
        <template slot-scope="{row}">
          <el-tag size="mini" type="success" v-if="row.is_force == '1'"><i class="el-icon-success"></i>是</el-tag>
          <el-tag size="mini" type="danger" v-if="row.is_force == '0'"><i class="el-icon-error"></i>否</el-tag>
        </template>
      </el-table-column>

      <el-table-column show-overflow-tooltip label="md5">
        <template slot-scope="{row}">
          <span @click="handleCopy(row.md5,$event)"><i class="el-icon-copy-document"></i>{{ row.md5 }}</span>
        </template>
      </el-table-column>

      <el-table-column show-overflow-tooltip label="升级信息">
        <template slot-scope="{row}">
          <span>{{ row.idesc }}</span>
        </template>
      </el-table-column>

      <el-table-column label="创建时间" width="130">
        <template slot-scope="{row}">
          <i class="el-icon-time"></i>
          <span style="margin-left: 10px">{{ row.create_time | parseTime }}</span>
        </template>
      </el-table-column>

      <el-table-column label="更新时间" width="130">
        <template slot-scope="{row}">
          <i class="el-icon-time"></i>
          <span style="margin-left: 10px">{{ row.start_time | parseTime }}</span>
        </template>
      </el-table-column>

      <el-table-column show-overflow-tooltip label="升级包地址" width="130">
        <template slot-scope="{row}">
          <el-button type="success" size="mini" icon="el-icon-download" @click="openUrl(row.zipfile)">下载升级包</el-button>
        </template>
      </el-table-column>

    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="page" :limit.sync="limit" @pagination="getList" />

    <!-- 添加/编辑服务器 -->
    <el-drawer
      title="添加升级包"
      class="pl-drawer"
      :wrapperClosable="false"
      :visible.sync="dialogCreate"
      :direction="direction">
      <el-form ref="form" :model="formAdd" label-width="120px">

        <el-form-item label="上传升级包：">
          <div class="el-upload-upgrade">
           <el-upload
             drag
             class="upload"
             ref="upload"
             action="string"
             :file-list="fileList"
             :auto-upload="false"
             :http-request="uploadFile"
             :on-change="handleChange"
             accept=".zip"
             >
             <i class="el-icon-upload"></i>
             <div class="el-upload__text">将zip文件拖到此处，或<em>点击导入</em></div>
           </el-upload>
          </div>
        </el-form-item>

        <el-form-item label="版本号：">
          <el-input wrap="off" v-model="formAdd.version" type=number placeholder="只允许填写数字"></el-input>
        </el-form-item>

        <el-form-item label="升级业务：">
          <!-- <el-input wrap="off" v-model="formAdd.biz"></el-input> -->
            <el-checkbox-group v-model="checkedItem">
              <el-checkbox
                v-for="(item,index) in optionsDeploy"
                :label="item.label"
                :key="index"
                @change="chooseItem(item)">
              </el-checkbox>
            </el-checkbox-group>
        </el-form-item>

        <el-form-item label="强制升级：">
          <el-switch
            :change="forceSwitch()"
            v-model="isForce"
            active-color="#2e79f4"
            inactive-color="#ddd"
            active-text="开启"
            inactive-text="关闭"
          ></el-switch>
        </el-form-item>

        <el-form-item label="升级开始时间：" >
          <el-date-picker
          v-model="formAdd.start"
          type="datetime"
          value-format="timestamp"
          style="width: 100%;"
          placeholder="大于该时间，会推送给客户机">
          </el-date-picker>
        </el-form-item>

        <el-form-item label="升级说明：">
          <el-input wrap="off"
            type="textarea"
            v-model="formAdd.description"
            placeholder="必填,至少3个字符">
          </el-input>
        </el-form-item>

        <el-button
          type="primary"
          @click="startCreate"
          :loading="loadingBtn"
          style="width: 100%;">
          提交
        </el-button>

        </el-form-item>
      </el-form>
    </el-drawer>

  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import { parseTime, formatTime } from '@/utils/index'
  import Pagination from '@/components/Pagination'
  import {
    upgradeStart,
    upgradeList,
    upgradeCreate,
    upgradeDelete,
  } from '@/api/server'
  import clip from '@/utils/clipboard'

  export default {
    components: {
      Pagination
    },
    filters: {
      parseTime(value) {
        return formatTime(value, '{y}-{m}-{d}')
      }
    },
    data() {
      return {
        fileList: [],
        checkedItem: [],
        arrChecked: [],
        direction: 'ltr',
        total: 0,
        page: 1,
        limit: 10,
        resultType: '1', // 0 全部 1失败 2成功
        dataList: [],
        isForce: false,
        dialogCreate: false,
        listLoading: false,
        loadingBtn: false,
        optionsDeploy: [{
          value: 'none',
          label: '无'
        }, {
          value: 'clone',
          label: '克隆站群'
        }, {
          value: 'tinyproxy',
          label: '多ip代理'
        }, {
          value: 'adslproxy',
          label: '拨号代理'
        }],
        formAdd: {
          file: '',
          version: '',
          description: '',
          force: 0,
          biz: '',
          start: '',
        }
      }
    },
    created() {
      this.getList()
    },
    methods: {
      async submitUpload () {
        // 上传到服务器
        // if(this.fileList == [] || this.fileList.length < 1) {
        //   this.$message({
        //     type: 'info',
        //     message: '请选择要上传的文件'
        //   })
        //   return false
        // }
        // console.log(this.fileList[0].raw)
        // this.startCreate(this.fileList[0].raw)
      },
      uploadFile (file) {
        // console.log("uploadFile",file)
        this.formAdd.append('file', file.file)
      },
      handleChange (file, fileList) {
         this.fileList = fileList
        //   此处就是放置在before-upload里的，用于判断可上传文件的格式
         var testmsg = file.name.substring(file.name.lastIndexOf('.') + 1)
         const extension = testmsg === 'zip'
         if (!extension) {
           this.$message(
             {
               message: '上传文件只能是.zip格式!',
               type: 'warning'
             }
           )
         }
         return extension
      },
      forceSwitch() {
        this.isForce === false ? this.formAdd.force = 0 : this.formAdd.force = 1
      },
      chooseItem(item) {
        this.checkedItem.push(item.value)
        if(this.arrChecked.indexOf(item.value)==-1){
          this.arrChecked.push(item.value)
        }else{
          this.arrChecked.splice(this.arrChecked.indexOf(item.value), 1)
        }
      },
      startCreate() {
        if(this.fileList == [] || this.fileList.length < 1) {
          return this.$message.info('请选择要上传的文件');
        }
        if (!this.formAdd.version) {
          return this.$message.info('请输入版本号');
        } else if (this.arrChecked.length < 1) {
          return this.$message.info('部署程序不能为空');
        }
        this.loadingBtn = true
        this.submitCreate(this.formAdd)
      },
      submitCreate(item) { // 增
        let FormData = require('form-data');
        let parmers = new FormData();
        
        parmers.append('file', this.fileList[0].raw)
        parmers.append('version', item.version);
        parmers.append('description', item.description);
        parmers.append('force', item.force);
        parmers.append('biz', this.arrChecked.join(','));
        parmers.append('start', item.start / 1000);
        upgradeCreate(parmers).then(res => {
          if (res.status) {
            this.$message({
              type: 'success',
              message: '添加版本升级成功'
            });
            this.dialogCreate = false
            this.getList()
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
          this.loadingClose()
        }).catch(err => {
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      },
      getList() { // 查
        this.listLoading = true
        this.loadingBtn = true
        let parmers = {}
        parmers.page = this.page
        parmers.limit = this.limit
        parmers.type = this.resultType
        upgradeList(parmers).then(response => {
          if(response.status) {
            this.dataList = response.data.list
            this.total = response.data.total
          }
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
          }, 1.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      },
      loadingClose() {
        const loadingInstance = Loading.service()
        this.$nextTick(() => {
          this.loading = false
          this.loadingBtn = false
          loadingInstance.close()
        })
      },
      handleCopy(text, event) {
        clip(text, event)
      },
      resultChange(data) {
        this.page = 1
      },
      openUrl(path) {
        path.indexOf('http://') < 0 ? path = `http://${path}` : path = path
        window.open(path)
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
</style>
<style lang="scss">
  .el-drawer__open .el-drawer.ltr {
    width: 460px !important;
    overflow-y: auto;
    .el-checkbox {
      min-width: 80px;
    }
  }
  .config-page {
    .el-slider__input {
        float: none!important;
    }
  }
  .el-drawer__body {
      padding: 0 30px;
  }
  .page-upgrade {
    .el-upload-dragger {
        width: 280px!important;
        height: 110px!important;
    }
    .el-icon-upload {
        margin: 10px 0 10px!important;
    }
    .btn-upload {
      .el-icon-upload {
        margin: 0!important;
      }
    }
  }
</style>
