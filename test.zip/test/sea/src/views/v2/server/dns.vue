<template>
  <dnsAccount />
   <!-- <el-tabs :tab-position="tabPosition">
     <el-tab-pane label="CF账号列表">
        <dnsAccount />
      </el-tab-pane>

      <el-tab-pane label="CF域名列表">
        <domainList />
      </el-tab-pane>

      <el-tab-pane label="批量解析">
        <batchAddRecord />
      </el-tab-pane>

      <el-tab-pane label="批量清空">
        <batchDelRecord />
      </el-tab-pane>
    </el-tabs> -->
</template>

<script>
  import dnsAccount from '@/views/v2/server/components/cf/account'
  import domainList from '@/views/v2/server/components/cf/domain'
  import batchAddRecord from '@/views/v2/server/components/cf/add'
  import batchDelRecord from '@/views/v2/server/components/cf/del'
  export default {
    components: {
      dnsAccount,
      domainList,
      batchAddRecord,
      batchDelRecord,
    },
    data() {
      return {
        tabPosition: 'left'
      }
    }
  };
</script>

<style>
</style>
