<template>
    <div class="wrap-new">
        <div class="kx-main kx-main-serve">
            <div class="kx-header">
                <h1>
                    <label>狂侠站群系统</label>
                    <div v-if="titleServer" class="title-box">
                        <el-tooltip class="item" effect="light" placement="left">
                            <div slot="content">
                            </div>
                            <span style="color: #fff">{{ titleServer }} - {{ valueServer }}</span>
                        </el-tooltip>
                    </div>
                    <span v-if="!valueServer" style="color: #ffffff">未选择服务器</span>
                    <span class="right-btn"/>
                </h1>
            </div>
            <div class="new-content">
                <div style="width: 210px;">
                    <servers-card @create="openCreateDialog" @getServeInfo="getServeInfo" :show-all-opation="true"
                                  :clone-deploy="true" @selectVal="selectServerFromSon"/>
                </div>
                <div class="new-content-right" style="margin-left: 210px;height: calc(100vh - 58px);overflow-y: auto;">
                    <ul class="big-menus">
                        <li v-for="(item, index) in bigMenus" :key="index" :class="{ active: item.name === activeSys }"
                            @click="menusChange(item.name)">
                            <i :class="`el-icon-${item.icon}`"/>
                            <label>{{ item.title }}</label>
                        </li>
                        <li style="margin-left: auto; cursor: pointer" @click="menusChange('home')">
                            <i class="el-icon-s-home"/>
                            <label>回到首页</label>
                        </li>
                        <li style="cursor: pointer" @click="logout">
                            <i class="el-icon-switch-button"/>
                            <label>{{ $store.state.user.name }}</label>
                        </li>
                    </ul>
                    <div class="serve-inter-box" id="container" style="display: initial">
                        <!--            <section  v-if="isShow">-->
                        <!-- 0323添加的内容 -->
                        <div v-if="activeSys == 'site'">
                            <el-card class="status-box1" style="padding: 0px; height: 36px;">
                                <span>克隆版本号：{{ versionData.version }}</span>
                                <span style="margin-left: 30px; font-size: 14px;">
            克隆有新版本了，版本号：{{ versionData.version }}<span
                                        style="margin-left: 10px; color: #3a8ee6; cursor: pointer" @click="viewDetail">查看详情</span>
          </span>
                                <el-button type="primary" @click="updateServeDialog"
                                           style="float: right; padding: 3px 0;font-size: 17px">编辑服务器
                                </el-button>
                            </el-card>
                            <!-- <div v-show="showConTab == 'site'" style="overflow-y: auto; height: 495px"> -->
                            <el-card class="status-box">
                                <div slot="header" class="clearfix">
                                    <p class="header-text1">状态</p>
                                </div>
                                <div class="progress-box">
                                    <div>
                                        <div class="status-box">
                                            <p class="status-p">
                                                负载状态
                                            </p>
                                            <div class="progress">
                                                <el-tooltip class="item" effect="dark" placement="right-start">
                                                    <el-progress :stroke-width="10" type="circle"
                                                                 :percentage="loadProgress" color="green"
                                                                 style="font-size: 30px"></el-progress>
                                                    <div slot="content" class="tips-content">
                                                        <p>最近1分钟平均负载：{{ dataList.load.one }}</p>
                                                        <p>最近5分钟平均负载：{{ dataList.load.five }}</p>
                                                        <p>最近15分钟平均负载：{{ dataList.load.fifteen }}</p>
                                                    </div>
                                                </el-tooltip>
                                            </div>
                                            <p>运行流畅</p>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="status-box">
                                            <p class="status-p">
                                                CPU
                                            </p>
                                            <div class="progress">
                                                <el-tooltip class="item" popper-class="popper-class" effect="dark"
                                                            placement="bottom">
                                                    <el-progress :stroke-width="10" type="circle"
                                                                 :percentage="cpuProgress" color="green"/>
                                                    <div slot="content" class="tips-content-big">
                                                        <p>{{ dataList.cpu[3] }}</p>
                                                        <p>{{ dataList.cpu[4] }}个物理cpu,{{
                                                            dataList.cpu[5]
                                                            }}个物理核心</p>
                                                        <p>
                                <span v-for="(item, index) in dataList.cpu[2]" :key="index">
                                  CPU-{{ (index + 1) }}: {{ item }}%  |  </span>
                                                        </p>
                                                    </div>
                                                </el-tooltip>
                                                <p class="status-p">
                                                    {{ cpuText }}核心</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <p class="status-p">内存使用率</p>
                                        <div>
                                            <el-progress :stroke-width="10" type="circle" :percentage="memProgress"
                                                         color="green"></el-progress>
                                        </div>
                                        <p>{{ memRealUsed }} / {{ memTotal }}（MB）</p>
                                    </div>
                                    <div class="status-box" v-for="(item,index) in dataList.disk" key="index">硬盘-{{
                                        (index + 1)
                                        }}
                                        <div>
                                            <!--                        parseFloat-->
                                            <el-progress :stroke-width="10" type="circle"
                                                         :percentage="parseFloat(item.size[3].split('%')[0])"
                                                         color="green"></el-progress>
                                        </div>
                                        <p>{{ item.size[1] }}/{{ item.size[0] }}</p>
                                    </div>
                                    <div>
                                    </div>
                                </div>
                            </el-card>
                            <div class="col-xs-12 col-sm-12 col-md-6 pull-left pd0"
                                 style="flex-flow: wrap; padding: 10px">
                                <div class="pr8">
                                    <div class="bgw radius4">
                                        <div class="title c6"></div>
                                        <div class="setting-con" style="padding: 0;
                            margin-right: -4px;
                            overflow: hidden; ">
                                            <div class="container-fluid soft-man interface-box-column">
                                                <div class="interface-left-container">
                                                    <el-card class="box-card">
                                                        <div slot="header" class="card-header">
                                                            <span class="header-text2">软件</span>
                                                        </div>
                                                        <section class="interface interface-box-column1"
                                                                 style="height: 408px;">
                                                            <div v-for="(item,index) in softList" :key="index"
                                                                 class="item a"
                                                                 @click="openStart(item.name,item.flag)">

                                                                <div v-if="item.name == 'nginx'">
                                                                    <img
                                                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAX8SURBVGhD7ZhbbBRVGIB3Zmd2Lrs7u9vddnujQGlFoC0qWEGxwQeEIBRNjIZoSNREE1+Mr2o0agzxzZgYH4yoGE1IjErBIvRBEZWLgNAWWizSC/Te7o2Z2dmZ2Rn/Mx2EXmCX3VNJzH5JM5f/zHb+M//dUaBAgQJ3FKd9xA7hInmmjK+jfK4yQ0knHGlTs0VYwa4A4SRoVym3zNtQ1BzcXPmmpz7QTJgOw9CMpJFMxxxwbi/FAmEf84dwkHSQWcQt9q71rAo+7V7m30A4SQaJzLShSl2xQ+KpyT3J3qvHtMlULy5FsCjgFOgybpG30d0QaIYd30q6qSBBEKQttjBN0zAkPSJ2RFuk9miL0nf1hJ7Qhm1xzuSlAMk5fWyVZ5V7hX+zB0yGKmIWgwlRtnhOzLSp65FUn9ge2Sudix1QBsSTYFpxW3zb5KQAQZMsU8E3gJlsdNcHtrjK+XqSJjlbnBXIJ9QhuVPqiO4D8zqYGpTbTc1QbHHW3J4CpMPpKuZq+OX+TWjX2UWeRidH+W1pTqSTekzpE0/A12iVz8cOquPJHvCOtC3OSNYKQDgs55f5NrjrAo9x1d6HwO5LZ9p5riD/SCe00eSlq79KnbEf5K5Ymx5Xh2zxLcmoALJzrkZ4GGz8Ca5WaKKLmIUoVNpirIB/aFok1Z+8mPhFPBv5Hh0z+UfGPMAtEdYVP171PlfrW08JdJggiX+fgV0aTJwY/zJxbPwLZUA66eSpgBNFoBvWzMRQ07LcnWiL/Tz8oTqidFN+VwWYoQ/J0HPwfJErzN3NVvIr1eHkOW0idcl68CZkVICt9j7obyp9ea5djx8d+yz20/AHyZ7EYeWy9Kd6WT5Nh9hqykdX3EwJLaL2jX/T9yqYSqs6LJ8jecoHuWONLbZA/4sSXKVSd6xNBee2b89JXjacGpTOQlLqM3UzZch6RL4YPzK5b+ANbTzVYxrm7ERlOkwwiYTSL540dUPRYupgCiKRLc2JvBRANjsto8J5EiLKRMvAa5C0JsA5TVtyHXBYh2Hq1rlhpvOtkbBEkWnAy0nno4cmW6+8DS+nwp3ZSmAEvwIAmJQSPz62O3Z49KO5PgJOsCmASgjhgeIdUAcVoWvwCjFy4Mo7ENN/tBbMEzi/AOFbF35RWB3ajnoBdAOybHz0696X1JFkl7ViHsBqQgRFsKFtVTv5WmE9/LJV1Omx1JWR3Rd3pCV90lqEGew+ALvvKX22ZhdT4a5Dlyh0Qo44M/rV3y9AsSZPrcIHfgUAqJPCZTtqdkOWLbduosgE9c3E/stvoZxh3cMEdgWugUrs8Pbqj0nWKaBrUzXk+LGxz9GftQAT86YAAirXrcFNla+DWbnRNSS3yQSUH5YQE/OqAML/SOkrQmPxM+DgVn88LXNjYN4VcDgJV2jLgnf55YFHHeSt281cyEsBq0Ilpn5j6nx2g4OcGpJbqLh5wU52oed+WH+9ByFhfZ69RV4KMGXuFZSfqSBogmXg5cBhvbZoGlBak3QJWxtqrnoPNUck7wyASblQc8SU8yjc5kzGfoDy0iVMJX8PyVKCtcs3gMIkemlXiF3iW1vyPFPO1RFOcs4dRf0B5acr2SrPapKjBCbML/U0BLZ57w0+OVNxQ4WGf0TuEs9Evs3U0GTbUjZ5VkJLCbv3H7WUR6Cl/A5LS4kSjzam/JXql/7Q49oQqudR60gwpBvZt70sL+ymfkTujrclfh//NPHb2CepAelUNknv9l5gaqxSyy/3b/Ss8G9m8IxV4ql+8bgILebUWEXpsRqdLMlpBy2nrXA3uNF8qM4abNXlMNhS1CG5Q+qM7pfgxVF7amrmPA+2ZmCPFlfbo8WtWY0WoS7SoY8WOyItqLG/I6PFmVACXcYu9ja662853DVRKSF2RvdJ7dG91nA3foeHu9OABEUHmWqu2rvWc1/wqdnj9XibeHpiT7JXPKpNKJdQmW09lyf4FLBBIRaS1l3Q1DQJa0qeQ6kYCrhdck/8CESzC9YkAyPYFbgGqkBdYW4pOldHkxegnJYsQYECBQr8j3A4/gE/mb008TCrmQAAAABJRU5ErkJggg=="
                                                                            alt="nginx" width="50" height="50">
                                                                    <div>nginx</div>
                                                                </div>
                                                                <div v-if="item.name=='redis'">
                                                                    <img
                                                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAArOSURBVGhD7Vhpb1xnFT53nXtnnBlv8Ro7tuPEiUlLaOgS0ZVvfACBxCoQQv3EN0QFAgHic4VAqkDiH7BICAlVVdmqFpGmabqkTdI4tpPY8RZv8e6529yF57kzk06SCU3S8Ak/yus7c+d9z3uec55z7nsjO9jBDnawg/9rKJXrfYWpKFa7afS2GUZ3TlMLQZJ4K6VwfiEoTW9F0Vpl2n3BfSOg4l+rYXT1WubQPss6fChrPzxoW59s0bUOJ062r3j+yIjjvDXmeKenfH8UZKZKSRJUlt8zPjaBnKrmeyzzwKBlP0CnD+fsYwP5/HBheNjwZqaVcH1dzPYOURRFnLnZcBFZOOc4b4w47qlxxzsDMhfWw+haxdxd454IaIro7YbRsx8RHsraRw/Z9sNDWeuhvKa1qIqiqrmc9H3/BxKHJQmWliXT2SWrr/5TNk6+ka5P8M+J4q1Lnnd2pOicGnW9d8cc9/R8UJq826zcFYEGVS3029YnhrP2Iwez1tEh236oyzQGTFW10gmIsrW3T/JHPiVtX/6KNBwcliSBu1Eki3/+k6y88g8pjpyX2PfT6QQdXgpKs+Oud3rUdd+54LhvX0RmNqJopTLlv+IjCWiCaJtGz+Fc9hgdR9SP9FuZ4YJptmiWpSqaJnEQSIJBZLq7JXdgSPTGRrH3DUrnV78hSy+9KMXRC7J97qw4ly6mc2MQczGCOBGLxDU12Y6i9SnPH7vk+u9DYm9/4Dgn5/xgAiQ/ZHwTbkvAVpUcInz0SEPuSUabTrdbVm+hf8DKH/202H39ouXzAsFIEoYSXFsWZ2xU1k+elGhrM7VhtLRI3w9/LNO/fiH9nZEPcR9FLUUkxsV1rRRKERnabWjSYehS0GBPJFguleamvGB03HXPnNzcfnnUcd/xk8RNDdegLgG0v96v7W557sGc/eiejDmY1/UWTFTsgX3S8fVvStMTT6bOqYZRWQGVOI74iwuy8Mffy/KLf5HY89L7dv+AuJMTacTX4fAWRkAPMXgP8pEpP2DApFXXZJ9lyB7YNfGdQFY2x1zv7K9m57+LTnY+vVkDdL9b0ajrXU81Fp4dzmUfK+h6K53n/TjwJYkj0VCktc4TWjYrmp1NiaS6r4DOEzSQgVTMSsyqM/iNznci+r0ZQ5ohSTSJFJyDnpBvNjKPmYraVL57IypTb8SgbT/+o96e43mkswnWsriSqaLrYnZ0SnZwv9goVqO1VRRsHLue+HNz4l6ZEOfiuISbkFCFBMmaHR0puS3UACVUwk+Uj4M5Ma46vMhjHxty1EGSmaHM1qJyxjA3emFm5pnLrns8NVqDugQGQOB7PT3HUcB4qgoIKNIE47vYP7GBMEpwSM2YsADNQsMKSJpt7ZLp6kbb7KyMbjGaEDismf/D72Tlby+n9pmhGNcIgw7ovGJOiPvbcHotiqVYkRrn8PKb2xCoKyFskERJUuJiF6vXwkSm8e2yj3aIq4/CC7e3pLSyIiUUZ7i2KuHGhuj5gjQ//Yx0fuvb0vaFL0nj409IwwMPprLaOHmibBygsxoGjhxiYJRwbzmMZSKIZAr2V0GC+3J/Yt73z7txvFH5egMY5FuAFJawidJumocMVbVhKzXGiGwjMhvYAB0BkStnBP+wKAaha7J15j3ZPnsWoVHF6u2VGM5f+vlPILFZmr4O2vRgawkOz5fiVC5exWn+RiRouLOed/yllWs/m/H808haldN11JXQLk1r/lxz43e+2Nr8HIqom8ap21owdWSfQwG2QMRsf4wqoWi6qLmsGM0tOEa0y+bbb6UEiWr/X0ZWN1O7ZTnVgu2BtdesqwksujxHPT8z9+yE558rz/gQdQngTPPoL/p7X27UtQK+aow8dbmKTbn5zSCZDCw1Y9NWXU1lQZmkQL3wSUzHt+DwEuzwSqdvtmRhCdc3sp7wmXYT2FkoReFPJ6eewXHj9fLMD1G3BuCwsRhJE6SCoOIpCWOdMDxkoU+bmuQR9dqFdIaavQqC5z3qGEUIR+l0CfWygu9jqJ+L0Pg6nK+VCWk2wN4A7B60dOnAPtyPYObHvVCulmIFpit3b0RdAjSOLqCwqEZgYAkFxixQMkztgQw306Qd0mGkqpa5jm2SBTkCh991Q3kf6yegc9ZO1WmCnYcZY1CGYI+feY8FvQRvL2DdZezPNspA3A71CVS6EJexX08jgjQ4A0fY3hhBG5npwTNgGFHrRfRYC3U7Qg1IlIQ7QJzRHsjo0gA73MfBn9nKPux4zCgB56PNKFpErZQf7Teh7p5ob3ZnJnOoWdd7ICGSVCiTIv6UW1wC5myFMIBBCbTiLJPFlfvWtgo6zU0oi3ZDlb2mDo2X1zJbzAy70BwGo127luu8JF56dW3t+fGi81o9EnUJIChRk67q+3GAwwtLE/xWKgFJHWS7S5+SLEZ8ht/pyGJhM84zrBGdA7NJige1HkSb9wnKcQNdCdqWBciN0aZdgjMoJWa0DfWAs1G21dCbzhSdf+HFZzmdVIOyxZuALnTslwN7X0FrzDLybHfVpyN1xXu1YNtjVEE6PRobsErDbACpY8gYI+tj4SbsrGBUJVIF08x1JNyMLsSjBe9xv9UojtGFnsaJ9M6exFikLYZJlnKhgQKM9UPnA0g/o8Lo0Okq+/RJirkXUbhTKDw6SE3zQcVBmSwg2peDUGYrEa+C0abTbJ992KMfe3C/suNJ+mSGvMoFWQd1CTDC1COd4biGTXm4ymB2N+TAltcJPRewMbVdNcI9NjDvShDLJMiw6Kex/hI+z8OGX3GCxFnMlFQ7HGdwemCPp1IcGdL9qnvzqY+Gcts+VJcApselOHarRGYQvSswxihuILrEbm6M9rcHhFrSrNxYUCx09vxNrGexEnSchCm3Ljjch/UduHId5y3CPp3mfmn7xH12oaVSadyP4y3auBl1ixhPLyNvGB1ZFDDed9HpFLXaMVi4PAfFcIcap5zoEGXAcxEuaSZquwmjZOMP57WhyNmNOJ+yoOMr6Pt8dvCFh3Ik4Hi4HoZzk5534vX19d9Oed5bOK3e8mrJoNwC3FSb0EIPNzR8fp9tP9WVyTzQZBh7cUQov7wDdIrO78LIwTGmny8rJLcFGWyDAc854JQWNouS7ZbkmNoi5jAYDEo1Q0QYx95qGE7P+f77OD7/e7RY/PtKqXQFS2qnXUddAlXgRw1vZ914P/hMP0ZPJnMUJ9SDtpaeka6vpSx2oXOQEAe/88lPAiTK7sLd2cV43qc8WFNlMZbhQSJLQTA643nv8Nw/4bqvMwMgXDvtFlx34qOQxQl1TyZzpM+yju21rEd6LOsoTq0dqqJclyHfrPhkbahIiud97l7uROWI13Yg1hoysYIj83tXPO/NSdc9MeP7p/GSf8f/0XXHBKqgjHab5v5ekAAZjmOthrEf7w03yMuGZYOSgcMe/lQ7EIGuEm5U9A2n34C+Ty34/oUgSYqVKXeMuyZQBRaqeOHvQn08SDKolcd7M5mHM6q6C8Vd1y7PV5DJ2EXXfQ0SOYHIn4a+J2+n7zvBPROohaWqhTbTHKLEBrPZpw5ks59tUNU2di/8nLAVzvr+eyPF4l8pk/kg+AAZuFpe/fFwXwhUgfZrthhGX4dpDqNOHm3GZzxPnKtBcG4axbkQBCNOFK1Wpt8X3FcCNVAaNK3VxnME3TTYDsPle9H3Dnawgx3s4H8Mkf8AKHyWFR0zLP4AAAAASUVORK5CYII="
                                                                            width="50" height="50">
                                                                    <div>redis</div>
                                                                </div>
                                                                <div v-if="item.name=='clone'">
                                                                    <img src="../../../assets/站群渲染.png" width="50"
                                                                         height="50">
                                                                    <div>站群渲染</div>
                                                                </div>
                                                                <div v-if="item.name=='fluent-bit'">
                                                                    <img src="../../../assets/日志.png" width="50"
                                                                         height="50">
                                                                    <div>日志推送</div>
                                                                </div>

                                                                <div v-if="item.name=='tinyproxy'">
                                                                    <img src="../../../assets/代理服务.png" width="50"
                                                                         height="50">
                                                                    <div>代理服务</div>
                                                                </div>
                                                                <div v-if="item.name=='celery'">
                                                                    <img src="../../../assets/克隆.png" width="50"
                                                                         height="50">
                                                                    <div>克隆内核</div>
                                                                </div>
                                                                <!--                                  <div>{{ item.name }}</div>-->
                                                            </div>
                                                        </section>
                                                    </el-card>
                                                </div>
                                                <div class="interface-right-container">
                                                    <el-card class="interface-right">
                                                        <header class="flow-header">
                                                            <span>流量</span>
                                                            <select name="" id="">
                                                                <option value="0">全部</option>
                                                            </select>
                                                        </header>
                                                        <div class="flow-count">
                                                            <article class="flow-count-article">
                                                                <p>上行</p>
                                                                <p>{{
                                                                    dataList.up ? formatBytes(dataList.up) : '0kb/s'
                                                                    }}</p>
                                                            </article>
                                                            <article class="flow-count-article">
                                                                <p>下行</p>
                                                                <p>{{
                                                                    dataList.down ? formatBytes(dataList.down) : '0kb/s'
                                                                    }}</p>
                                                            </article>
                                                            <article class="flow-count-article">
                                                                <p>总发送</p>
                                                                <p>{{
                                                                    dataList.upTotal ? formatBytes(dataList.upTotal) : 'null'
                                                                    }}</p>
                                                            </article>
                                                            <article class="flow-count-article">
                                                                <p>总接收</p>
                                                                <p>{{
                                                                    dataList.downTotal ? formatBytes(dataList.downTotal) : 'null'
                                                                    }}</p>
                                                            </article>
                                                        </div>
                                                        <div style="height: 351px;">
                                                            <LineChart :chart-data="lineChartData"
                                                                       class-name="linechart"/>
                                                        </div>
                                                    </el-card>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- 0323添加的内容 -->
                        <!--            </section>-->
                        <div v-if="activeSys == 'webssh'">
                            <div>
                                <el-tabs v-model="editableTabsValue" type="card" editable @edit="handleTabsEdit">
                                    <el-tab-pane>
                                        <span slot="label"><i class="el-icon-user-solid"></i>{{ valueServer }}</span>
                                        <webssh></webssh>
                                    </el-tab-pane>
                                </el-tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 添加/编辑服务器 -->
        <el-drawer class="pl-drawer pl-drawer-select" :wrapper-closable="false" :title="titleDialog"
                   :visible.sync="dialogCreate" direction="ltr">
            <el-form ref="form" v-loading="listLoading2" :model="formAdd" label-width="120px">


                <el-form-item label="服务器名称：">
                    <el-input v-model="formAdd.name" wrap="off" placeholder="格式:组别+编号+站(例如:A12站)"
                              style="width: 100%"/>
                </el-form-item>


                <el-form-item label="主IP：">
                    <el-input v-model="formAdd.host" wrap="off" placeholder="输入一个主要的管理IP" style="width: 100%"/>
                </el-form-item>

                <el-form-item label="SSH端口：">
                    <el-input v-model="formAdd.ssh_port" wrap="off" style="width: 100%"/>
                </el-form-item>
                <el-form-item label="SSH用户名：">
                    <el-input v-model="formAdd.sshuser" wrap="off" style="width: 100%"/>
                </el-form-item>
                <el-form-item label="SSH密码：">
                    <el-input v-model="formAdd.sshpasswd" wrap="off" style="width: 100%"/>
                </el-form-item>

                <!-- 多ip段时显示 -->
                <el-form-item label="附加IP段：">
                    <el-input v-model="tinyproxyConfig" wrap="off" type="textarea" placeholder="配置IP可以实现建站自动解析DNS
    例如:
    154.94.148.193-254
    154.94.182.193-254
    154.94.186.193-254
    154.94.188.193-254" style="width: 100%"/>
                </el-form-item>

                <!-- 拨号模式时显示 -->
                <el-form-item v-if="arrChecked.indexOf('adslproxy') > -1 || formAdd.deploy == 'adslproxy'"
                              label="ADSL账号：">
                    <el-input v-model="adslproxyUser" wrap="off" placeholder="拨号代理账号" style="width: 100%;"/>
                </el-form-item>
                <el-form-item v-if="arrChecked.indexOf('adslproxy') > -1 || formAdd.deploy == 'adslproxy'"
                              label="ADSL密码：">
                    <el-input v-model="adslproxyPwd" wrap="off" placeholder="拨号代理密码" style="width: 100%;"/>
                </el-form-item>

                <el-form-item label="购买日期：">
                    <el-date-picker v-model="formAdd.buytime" type="date" value-format="yyyy-MM-dd"
                                    placeholder="选择日期"/>
                </el-form-item>

                <el-form-item>
                    <el-button v-if="!loadingBtn2" type="primary" style="width: 280px" @click="startCreate">提交
                    </el-button>
                    <el-button v-if="loadingBtn2" type="info" :loading="true" style="width: 280px">IP验证中,请最多等待30秒...
                    </el-button>
                </el-form-item>
            </el-form>
        </el-drawer>
        <!-- 服务器软件配置 -->
        <el-dialog v-if="restatOpen" :close-on-click-modal="false" :title="`${restatName}`" :visible.sync="restatOpen"
                   width="600px" append-to-body>
            <restart :row-data="rowData" :name="restatName" :restat-flag="restatFlag"/>
        </el-dialog>
        <el-dialog
                title="版本说明"
                :visible.sync="dialogVisible"
                width="30%"
        >
            <span>{{ versionData.idesc }}</span>
            <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">关闭</el-button>
      </span>
        </el-dialog>
    </div>
</template>


<script>
import clip from '@/utils/clipboard'
import Cookies from "js-cookie";
import EventBus from "@/utils/eventBus.js";
import serversCard from "@/components/servers-card";
import serversSelect from "@/components/servers-select";
import VueDragResize from "vue-drag-resize";
import siteList from "@/views/v2/website/list";
import toolList from "@/views/v2/tools/toolList";
import systemConfig from "@/views/v2/system/config";
import page404 from "@/views/v2/system/page404";
import allowIP from "@/views/v2/system/allowIP";
import robots from "@/views/v2/system/robots";
import shouluPage from "@/views/v2/report/shoulu";
import tools from "@/views/v2/tools/index";
import serverPage from "@/views/v2/server/index";
import upgradePage from "@/views/v2/server/upgrade";
import taskPage from "@/views/v2/server/task";
import firewallPage from "@/views/v2/server/firewall";
import siteAdd from "@/views/v2/website/add";
import pageConfig from "@/views/v2/website/page";
import addSite from "@/views/v2/website/add";
import setSitePage from "@/views/v2/website/setsitepage";
import toolsPage from "@/views/v2/tools/index";
import codePage from "@/views/v2/website/code";
import LineChart from "@/components/LineChart.vue";
import BatchUpdate from "../tools/batchUpdate";
// import sshTerminal from './sshTerminal.vue'
import webssh from './webssh.vue'
import {
    systemLoadStatus,
    pluginGet,
    severInstallerStatus,
    updateVersion,
    clientUpgrade,
    severCreate,
} from '@/api/server'
import restart from './restart.vue'
// import sshTerminalVue from './sshTerminal.vue';


export default {
    components: {
        // sshTerminal,
        webssh,
        restart,
        BatchUpdate,
        siteList,
        systemConfig,
        page404,
        allowIP,
        robots,
        serverPage,
        shouluPage,
        tools,
        serversCard,
        siteAdd,
        pageConfig,
        serversSelect,
        addSite,
        upgradePage,
        taskPage,
        firewallPage,
        toolsPage,
        setSitePage,
        codePage,
        toolList,
        LineChart
    },
    props: {
        restatFlag:
            {
                type: Boolean,
                default: false
            }
    },
    beforeRouteEnter(to, from, next) {
        // 添加背景色 margin:0;padding:0是为了解决vue四周有白边的问题
        document.querySelector("body").setAttribute("style", "margin:0;padding:0");
        next();
    },
    beforeRouteLeave(to, from, next) {
        // 去除背景色
        document.querySelector("body").setAttribute("style", "");
        next();
    },
    data() {
        return {
            editableTabsValue: '0',
            windows: [],
            editableTabs: [{
                title: 'Tab 1',
                name: '1',
                content: 'Tab 1 content'
            }, {
                title: 'Tab 2',
                name: '2',
                content: 'Tab 2 content'
            }],
            tabIndex: 2,

            lineChartData: {
                upData: [],
                activeSys: 'site',
                downData: []
            },
            dataList: {
                load: {},
                cpu: [],
                iostat: {
                    ALL: {}
                }
            },

            lineIostatChartData: {
                upData: [],
                downData: []
            },
            dialogVisible: false,
            rowData: {},
            val: [],
            restatName: '',
            isAdmin: false,
            keywordsInput: '',
            loadingBtn: false,
            adslproxyUser: '',
            adslproxyPwd: '',
            restatOpen: false,
            loadProgress: 0,//负载状态
            cpuProgress: 0,//cpu
            memProgress: 0,//内存使用率
            memRealUsed: 0,
            versionData: {},
            intervalId: null,
            first: true,
            second: false,
            direction2: 'btt',
            diskRealUsed: 0,
            diskTotal: 0,
            diskProgress: 0,
            memTotal: 0,
            cpuText: 0,//几个核
            softList: [],//软件列表
            titleDialog: "添加服务器",
            dialogCreate: false,
            formAdd: {
                name: '', // 测试服务器名称
                ssh_ip: '',
                server_ip: '',
                ssh_port: '22',
                desc: '备注内容',
                group: '未分组',
                host: '',
                location: '',
                sshuser: 'root',
                sshpasswd: '',
                buytime: '',
                config: {}, // 	服务器附加配置，如蜘蛛防火墙，adsl账号密码；多IP号段
                deploy: '' // 部署程序：无：none；克隆站群：clone；多IP代理：tinyproxy；拨号代理：adslproxy；多个用英文逗号隔开
            },
            tinyproxyConfig: '',
            listLoading2: false,
            arrChecked: [],
            loadingBtn2: false,

            webOriginalConfig: [
                {
                    id: 1,
                    title: "状态",
                    name: "config",
                    active: true,
                },
            ],
            bigMenus: [
                {
                    name: "site",
                    icon: "monitor",
                    title: "系统摘要",
                },
                {
                    name: "shoulu",
                    icon: "folder-add",
                    title: "CC防御",
                },
                {
                    name: "webssh",
                    icon: "data-analysis",
                    title: "WebSSH",
                },
            ],
            currentConfig: {},
            currentGroupName: "",
            currentSiteId: "",
            showUpdate: true,
            flag1: true,
            flag2: true,
            flag3: true,
            flag4: true,
            taskMsg: '',
            installBtnText: '一键安装对应服务器软件',
            activeTools: "toolsUpdate",
            activeMoreSite: "siteconfig",
            activeSpider: "spider",
            activeShoulu: "shoulu",
            siteType: "edit",
            title: "保存修改",
            pageType1: "friendlink",
            pageType2: "footjs",
            websshDrawer: false,
            pageType3: "headjs",
            pageType4: "404",
            pageType5: "other",
            pageType6: "nginx",
            showSiteList: true,
            isShow: true,
            icon: {
                celery: "iconfont icon-user",
                clone: "iconfont icon-asd",
                fluent: "",
                nginx: "",
                redis: "",
                tinyproxy: "",
            },
            showConTab: "site,webssh",
            direction: "btt", // 抽屉方向
            openDrawer: "",
            winLeft: 200,
            winTop: 20,
            activeSite: "config",
            activeServer: "serverList",
            activeSys: "site",
            activeName: "add",
            winWidth: 900,
            winHeight: 640,
            row: {},
            sid: null,
            valueServer: "",
            titleServer: "",
            spiderConfig: {},
            webConfig: [],
        };
    },
    watch: {
        visible: function (val) {
            if (!val) {
                this.dataList = {
                    load: {},
                    cpu: [],
                    iostat: {
                        ALL: {}
                    }
                }
                this.rowData = {}
                clearInterval(this.timer)
                this.timer = null
                this.taskMsg = ''
                this.installBtnText = '一键安装对应服务器软件'
                this.flag1 = true
                this.flag2 = true
                this.flag3 = true
                this.flag4 = true
                this.taskStatus = 'none'
                this.$emit('refreshDataList')
            }
        }
    },
    mounted() {
        this.webConfig = [...this.webOriginalConfig];
        // this.getCloneLoad();
        this.timer = setInterval(this.getCloneLoad, 3000);
        //  this.fun1()
        this.timer = setInterval(this.getSystemLoad, 3000);
        this.getList()
        const oversea = {}
        oversea.children = [{label: '海外', value: '999999'}]
        oversea.label = '海外'
        oversea.value = '999998'
        const adminList = ['gs2019', 'gs2020', 'tester']
        if (this.$store.state.user.name && adminList.includes(this.$store.state.user.name)) {
            this.isAdmin = true
        } else {
            this.isAdmin = false
        }
        this.getUpgrade()
    },
    beforeDestroy() {
        EventBus.$off("order");
        clearInterval(this.timer);
    },

    methods: {
        openWindow(server) {
            const url = `https://example.com/webssh?host=${server.host}&username=${server.username}&password=${server.password}`;
            window.open(url, 'WebSSH', 'width=800,height=600');
        },
        handleUpdate() {
            const query = {
                server_id: this.rowData.id
            }
            updateVersion(query).then(response => {
                this.$message({
                    type: 'info',
                    message: response.message
                })
            }).catch(err => {
                console.log(err)
            })
        },
        openWebssh(row) {
            this.websshDrawer = true
            this.sendMesFroIframe(row)
            // 定义一个变量来存储打开的窗口对象
            let websshWindow;
            // 打开一个新的 WebSSH 窗口
            function openWebsshWindow(ip) {
                // 如果窗口已经打开，则直接激活该窗口
                if (websshWindow && !websshWindow.closed) {
                    websshWindow.focus();
                    return;
                }
                // 创建新的窗口
                websshWindow = window.open(`/webssh/${ip}`, ip, "width=1024,height=768");
                // 添加窗口关闭事件，以便在关闭窗口时清除该窗口的引用
                websshWindow.addEventListener("beforeunload", () => {
                    websshWindow = null;
                });
            }

// 监听服务器列表中的服务器点击事件
            handleServerClick(server)
            {
                // 如果没有选择服务器，则返回
                if (!server) {
                    return;
                }
                // 打开 Webssh 窗口
                openWebsshWindow(server.ip);
            }

        },
        serverd() {
            this.val = valueServer
        },
        sendMesFroIframe(row) {
            // 向iframe传值
            this.$nextTick(() => {
                const mapFrame = this.$refs['mainIframe']
                // 因为iframe页面打开就已经加载 获取接口成功后刷新他
                mapFrame.contentWindow.location.reload()
                if (mapFrame.attachEvent) {
                    // 兼容浏览器判断 // iframe的加载完成函数
                    mapFrame.attachEvent('onload', function () {
                        const iframeWin = mapFrame.contentWindow
                        // 传递参数
                        iframeWin.postMessage(row, '*')
                    })
                } else {
                    // iframe的加载完成函数
                    mapFrame.onload = function () {
                        const iframeWin = mapFrame.contentWindow
                        // 传递参数
                        iframeWin.postMessage(row, '*')
                    }
                }
            })
        },
        viewDetail() {
            this.dialogVisible = true
        },
        addForm() {
            this.tinyproxyConfig = ''
            this.dialogCreate = true
            this.titleDialog = '添加服务器'
        },
        getUpgrade() {
            const req = {
                version: '20221003',
                access_token: '111'
            }
            clientUpgrade(req).then(response => {
                if (response.status) {
                    this.versionData = response.data
                } else {
                    this.$message({
                        type: 'error',
                        message: response.message
                    })
                }
            })
        },
        handleTabsEdit(targetName, action) {
            if (action === 'add') {
                let newTabName = ++this.tabIndex + '';
                this.editableTabs.push({
                    title: 'New Tab',
                    name: newTabName,
                    content: 'New Tab content'
                });
                this.editableTabsValue = newTabName;
            }
            if (action === 'remove') {
                let tabs = this.editableTabs;
                let activeName = this.editableTabsValue;
                if (activeName === targetName) {
                    tabs.forEach((tab, index) => {
                        if (tab.name === targetName) {
                            let nextTab = tabs[index + 1] || tabs[index - 1];
                            if (nextTab) {
                                activeName = nextTab.name;
                            }
                        }
                    });
                }

                this.editableTabsValue = activeName;
                this.editableTabs = tabs.filter(tab => tab.name !== targetName);
            }
        },
        getList() { // 查
            this.listLoading = true
            this.loadingBtn = true
            const query = {}
            query.page = this.page
            query.limit = this.limit
            query.deploy = this.deploy
            query.keywordsInput = this.keywordsInput
        },
        handleClick(tab, event) {
            console.log(tab, event);
        },
        installServerStatus(flag) { // 查询安装状态
            this.loadingBtn = true
            severInstallerStatus({
                server_id: this.rowData.id
            }).then(res => {
                if (flag && res.status) {
                    this.timer = setInterval(() => {
                        this.installServerStatus()
                    }, 1000)
                } else {
                    if (res.status) {
                        this.taskStatus = res.message
                        this.showInstallBtn = false
                        this.installBtnText = '点击一键安装'
                        if (res.data && res.data.message) {
                            this.taskMsg = res.data.message + '<br/>'
                            // this.taskMsg = this.taskMsg + res.data.message + '<br/>'
                        }
                        if (this.taskStatus === 'PROCESS') {
                            this.taskMsg = '等待任务开始<br/>'
                        }
                        if (this.taskStatus === 'STARTING' || this.taskStatus === 'PENDDING' || this.taskStatus === 'PENDING' || this.taskStatus === 'PROCESS' || this.taskStatus === 'PROGRESS') {
                            this.showCancelBtn = true
                        } else {
                            this.showCancelBtn = false
                        }

                        if (this.taskStatus === 'FAILED') {
                            clearInterval(this.timer)
                            this.timer = null
                            this.showInstallBtn = true
                            this.installBtnText = '重试一键安装'
                            if (this.flag1) {
                                this.$alert(`安装失败，重试下或去检查服务器状态`, '提示', {
                                    confirmButtonText: '确认'
                                })
                                this.flag1 = false
                            }
                        } else if (this.taskStatus === 'OK' || this.taskStatus === 'SUCCESS' || this.taskStatus === 'FINISHED') {
                            this.showInstallBtn = false
                            this.showCancelBtn = false
                            clearInterval(this.timer)
                            this.timer = null
                            console.log(this.flag2)
                            if (this.flag2) {
                                const self = this
                                this.$alert(`服务器已成功安装`, '提示', {
                                    confirmButtonText: '确认'
                                }).then(function () {
                                    self.showElse = true
                                    self.handleInstalled()
                                })
                                this.flag2 = false
                            } else {
                                this.showElse = true
                                this.handleInstalled()
                            }
                        } else if (this.taskStatus === 'none') {
                            this.showInstallBtn = true
                            if (this.flag3) {
                                this.$alert(`未知错误，已停止任务，请稍后重试`, '提示', {
                                    confirmButtonText: '确认'
                                })
                                this.flag3 = false
                            }
                        }
                    } else {
                        const _this = this
                        if (res.message === '任务不存在') { // 显示安装按钮
                            _this.showInstallBtn = true
                            _this.taskStatus = ''
                            if (this.flag4) {
                                this.$message({
                                    type: 'info',
                                    showClose: true,
                                    message: res.message + ',请点击一键安装任务'
                                })
                                this.flag4 = false
                            }
                            clearInterval(this.timer)
                            this.timer = null
                        }
                    }
                }
                setTimeout(() => {
                    this.loadingBtn = false
                }, 1.5 * 1000)
            }).catch(err => {
                console.log(err)
                setTimeout(() => {
                    this.loadingBtn = false
                }, 1.5 * 1000)
            })
        },
        handleCopy(text, event) {
            clip(text, event)
        },
        formatBytes(bytes, decimals = 2) {
            if (bytes === 0) return '0 Bytes'
            const k = 1024
            const dm = decimals < 0 ? 0 : decimals
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
            const i = Math.floor(Math.log(bytes) / Math.log(k))
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i]
        },
        startCreate() {
            if (!this.formAdd.name) {
                return this.$message.info('服务器名称不能为空')
            } else if (!this.formAdd.host) {
                return this.$message.info('服务器主IP不能为空')
            } else if (!this.formAdd.ssh_port) {
                return this.$message.info('端口不能为空')
            } else if (!this.formAdd.sshuser) {
                return this.$message.info('SSH账号不能为空')
            } else if (!this.formAdd.sshpasswd) {
                return this.$message.info('SSH密码不能为空')
            } else if (!this.formAdd.desc) {
                return this.$message.info('备注信息至少3个字符')
            } else if (this.formAdd.name.length < 3) {
                return this.$message.info('服务器名称至少3个字符')
            } else if (this.formAdd.desc.length < 3) {
                return this.$message.info('备注信息至少3个字符')
            }

            this.formAdd.config.tinyproxy = {}
            this.formAdd.config.adslproxy = {}
            this.formAdd.config.clone = {}

            // if(this.arrChecked.indexOf('clone') > -1) {
            //   this.formAdd.config.clone = this.configData
            // }
            // if(this.arrChecked.indexOf('tinyproxy') > -1) {
            //   this.formAdd.config.tinyproxy.ipsection = this.tinyproxyConfig
            // }
            // if(this.arrChecked.indexOf('adslproxy') > -1) {
            //   this.formAdd.config.adslproxy.username = this.adslproxyUser
            //   this.formAdd.config.adslproxy.password = this.adslproxyPwd
            // }

            this.formAdd.config.adslproxy.username = this.adslproxyUser
            this.formAdd.config.adslproxy.password = this.adslproxyPwd
            this.formAdd.config.tinyproxy.ipsection = this.tinyproxyConfig
            this.formAdd.config.clone = this.configData

            this.formAdd.name = this.formAdd.name.toUpperCase()
            this.loadingBtn2 = true
            this.titleDialog == '编辑服务器信息' ? this.submitUpdate(this.formAdd) : this.submitCreate(this.formAdd)
        },
        submitCreate(item) { // 增
            const parmers = {}
            parmers.name = item.name
            parmers.desc = item.desc
            parmers.host = item.host
            parmers.ssh_ip = item.host
            parmers.server_ip = item.host
            parmers.port = item.ssh_port
            parmers.sshuser = item.sshuser
            parmers.sshpasswd = item.sshpasswd
            parmers.group = '无'
            // parmers.location = item.location
            parmers.location = 'haiwai,haiwai'
            // parmers.deploy = this.arrChecked.join(',')
            parmers.deploy = 'clone,tinyproxy'
            parmers.buytime = item.buytime
            parmers.desc = item.desc || '站群服务器'
            parmers.config = JSON.stringify(item.config)

            severCreate(parmers).then(res => {
                if (res.status) {
                    this.$message({
                        type: 'success',
                        message: '服务器信息创建成功'
                    })
                    this.dialogCreate = false
                    this.getList()
                } else {
                    this.$message({
                        type: 'error',
                        message: res.message
                    })
                }
                this.loadingClose()
            }).catch(err => {
                this.$message({
                    type: 'error',
                    message: 'IP验证结果无效，请检查'
                })
                setTimeout(() => {
                    this.loadingBtn2 = false
                }, 1.5 * 1000)
            })
        },
        softInsalled(val) { // 已安装软件

            const query = {
                server_id: val.id
            }
            pluginGet(query).then(response => {
                if (response.data) {
                    const softList = []
                    for (const key in response.data) {
                        const configData = {
                            flag: response.data[key],
                            name: key
                        }
                        softList.push(configData)
                    }
                    this.softList = softList
                }
            }).catch(err => {
                console.log(err)
            })
        },
        openStart(name, flag) {
            this.restatName = name
            this.restatFlag = flag
            this.restatOpen = true
        },
        getSystemLoad() {

            systemLoadStatus({
                server_id: this.rowData.id
            }).then(response => {

                console.log(response, 'response')

                if (response) {
                    this.dataList = response.data
                    const loadData = this.dataList.load || ""

                    // loadProgress负载状态
                    if (loadData) {
                        this.loadProgress = Number(loadData?.one)
                    }
                    // cpuProgress CPU使用率
                    this.cpuProgress = this.dataList?.cpu[0] || 0
                    this.cpuText = this.dataList?.cpu[1] || 0
                    this.memRealUsed = this.dataList?.mem?.memRealUsed
                    this.memTotal = this.dataList?.mem?.memTotal
                    this.memProgress = (this.memRealUsed / this.memTotal * 100).toFixed(2)
                    this.diskRealUsed = this.dataList?.disk[0].size[1]//磁盘使用的容量
                    this.diskTotal = this.dataList?.disk[0].size[0]//磁盘总容量
                    this.diskProgress = Number(this.dataList?.disk[0].size[3].split('%')[0])//磁盘百分比
                    this.lineChartData.upData = [this.dataList.network?.eth0?.up, this.dataList.network?.lo?.up]
                    this.lineChartData.downData = [this.dataList.network?.eth0?.down, this.dataList.network?.lo?.down]

                    this.lineIostatChartData.upData = [this.dataList.iostat?.ALL?.read_bytes, this.dataList.iostat['dm-0'].read_bytes, this.dataList.iostat['dm-1'].read_bytes, this.dataList.iostat['sda'].read_bytes, this.dataList.iostat['sda1'].read_bytes, this.dataList.iostat['sda2'].read_bytes]
                    this.lineIostatChartData.downData = [this.dataList.iostat?.ALL?.write_bytes, this.dataList.iostat['dm-0']?.write_bytes, this.dataList.iostat['dm-1']?.write_bytes, this.dataList.iostat['sda']?.write_bytes, this.dataList.iostat['sda1'].write_bytes, this.dataList.iostat['sda2']?.write_bytes]


                }
            })
        },
        getServeInfo(val) {
            console.log(val)
            this.getSystemLoad(val)
            this.softInsalled(val)
            this.rowData = val
        },
        openCreateDialog() {
            this.titleDialog = '新增服务器'
            this.dialogCreate = true
        },
        updateServeDialog() {
            this.titleDialog = '编辑服务器'
            this.dialogCreate = true
        },
        submitDomain(domain) {
            console.log(domain, "domain");
            this.$refs.siteListRef.getList();
            this.$set(this.row, "domain", domain);
        },
        menusChange(name) {
            console.log(name)
            // 0323新加
            // this.showConTab = name;
            // EventBus.$off("row");
            // EventBus.$off("order");
            // if (name === "home") {
            //   this.$router.push("/");
            // }
            this.activeSys = name;
        },
        changeRow(id) {
            this.$refs.siteListRef.getList("", "", id);
        },
        handleClickSite(tab, event) {
            // if(tab.name == 'config') {
            //   EventBus.$emit('domainActived', this.row.domain); //传递更新列表指令
            // }
            EventBus.$off("row");
            EventBus.$off("order");
            this.activeSite = tab.name;
            this.webConfig.map((v, i) => {
                return (v.active = Number(tab.index) === i);
            });
        },
        selectServerFromSon(msg, list) {
            console.log(msg, list)
            // 来自公共组件传值
            if (msg && list) {
                list.forEach((item) => {
                    if (item.value == msg.server_ip) {
                        this.sid = item.sid;
                        this.valueServer = msg.server_ip;
                        this.titleServer = msg.iname;
                        this.spiderConfig = item.spiderConfig;

                        // this.menusChange('site')
                    }
                });
            }
        },
        getToolsBatch(val) {
            this.toolsWebList = val;
        },
        getRowData(row) {
            this.row = row;
            this.currentConfig = this.row?.config || {};
        },
        clsoeDialog() {
            this.dialogCreate = false;
            this.dialogAddShow = false;
        },
        logout() {
            const that = this;
            this.$confirm("即将登出后台（程序会继续后台运行）, 是否继续?", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(() => {
                    that.$message({
                        type: "success",
                        message: "登出成功!",
                    });
                    sessionStorage.clear();
                    localStorage.clear();
                    Cookies.remove("Admin-Token");
                    that.$store.dispatch("user/logout");
                    setTimeout(() => {
                        that.$router.push(`/login?redirect=${that.$route.fullPath}`);
                    }, 1000);
                })
                .catch(() => {
                });
        },
    },
};
</script>
<style>
.kx-main-serve .el-tabs {
    flex: 1 !important;
}

.kx-main-serve .el-tabs .el-tabs__content {
    width: 100%;
}

.kx-main-serve .el-tabs__item.is-top.is-active {
    background: #000;
}

.kx-main-serve .el-tabs__content {
    transform: translate(0, -9px);
}

.kx-main-serve .el-tabs .el-tabs__content .el-tab-pane {
    display: initial !important;
}

.el-progress__text {
    font-size: 26px !important;
    color: green;
}

.status-box1 .el-card__body {
    padding: 10px;
    height: 36px;
}

.status-box1 .is-always-shadow {
    height: 40px !important;
    padding: 0px;
}

.serve-inter-box.el-card__body {
    padding: 0px !important;
}

.interface-left-container .el-card__body {
    padding: 0px;
}

.tips-content-big {
    width: 175px;
    color: #fff;
}

.text {
    font-size: 14px;
}

.item {
    margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
    display: table;
    content: "";
}

.clearfix:after {
    clear: both
}

.box-card {
    padding: 3px;
    height: 465px;
}
</style>
<style lang="scss" scoped>
.wrap-new .right {
  // height: calc(100% - 240px) !important;
}

//  <!-- 0323添加的内容 -->
.serve-inter-box {
  margin-right: 20px;
}

.top-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 5px;


  .top-info-2 {
    background: #ccc;
    padding: 5px;
    margin: 0 10px;

    a {
      color: #409eff;
      cursor: pointer;
      margin-left: 10px;
    }
  }

  .top-info-3 {
    background: #55a030;
    padding: 5px;
    cursor: pointer;
    margin-left: 10px;
    border-radius: 3px;
    color: #fff;
  }

  .btn {
    border: 1px solid #ccc;
    padding: 5px 10px;
    border-radius: 3px;
    cursor: pointer;
  }
}

.header-text1 {
  font-size: 18px;
  font-weight: 400;
  margin: -18px;
  height: 37px;
  line-height: 30px;
  border-bottom: 1px solid #eee;
}

.header-text2 {
  font-size: 18px;
  font-weight: 400;
  margin: -8px;
  height: 37px;
  line-height: 0px;
}

.status-box {
  padding: 10px;
  margin: 10px;


  .status-p {
    margin: 5px 0;
  }

  .icon-que {
    margin-left: 10px;
    color: #ccc !important;
  }

  .progress-box {
    display: -webkit-inline-flex;
    justify-content: space-between;
    align-items: baseline;
    text-align: center;
    width: 70%;
    margin: 20px auto 0;
    // height: 150px;
  }
}

.status-box1 {
  padding: 10px;
  margin: 10px;
  height: 45px;

  .status-p {
    margin: 5px 0;
  }

  .icon-que {
    margin-left: 10px;
    color: #ccc !important;
  }

  .progress-box {
    display: -webkit-inline-flex;
    justify-content: space-between;
    align-items: baseline;
    text-align: center;
    width: 70%;
    margin: 20px auto 0;
    // height: 150px;
  }
}

.interface {
  display: flex;
  flex-flow: wrap;
}

.interface > div {
  width: 25%;
  height: 185px;
  text-align: -webkit-center;
  margin-bottom: 0px;
  display: inline-grid;
  align-items: center;
  border: 1px solid #ebeef5;

  .image {
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .preview-btn {
    cursor: pointer;
    border: 1px solid #ccc;
    padding: 5px;
    font-size: 14px;
    margin-right: 10px;
  }
}

//  <!-- 0323添加的内容 -->
.a:hover {
  background-color: #f5f5f5;
}

.interface-box-column {
  display: flex;

  .interface-right-container,
  .interface-left-container {
    width: 50%;
  }


  .interface-left,
  .interface-right {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
    height: 466px;
  }

  .interface-left {
    margin-right: 10px;

    .sname,
    .product-name,
    .sf-hidden {
      font-size: 12px;
      line-height: 20px;
    }
  }

  .interface-right {
    margin-left: 10px;

    .flow-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 24px;
      border-bottom: 1px solid #ebeef5;

      span {
        font-size: 18px;
        padding-bottom: 24px;
        margin: -12px;
      }

      select {
        font-size: 14px;
      }
    }

    .flow-count {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 57px;

      .flow-count-article {
        p {
          margin: 0;
          margin-top: 10px;
        }
      }
    }

    .flow-chart {
      margin-top: 20px;
    }
  }
}

.interface-box-column1 {
  display: flex;
  align-content: flex-start;

  .interface-right-container,
  .interface-left-container {
    width: 50%;
  }

  .interface-left,
  .interface-right {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
    height: 466px;
  }

  .interface-left {
    margin-right: 10px;

    .sname,
    .product-name,
    .sf-hidden {
      font-size: 12px;
      line-height: 20px;
    }
  }

  .interface-right {
    margin-left: 10px;

    .flow-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 24px;
      border-bottom: 1px solid #ebeef5;

      span {
        font-size: 18px;
        padding-bottom: 24px;
        margin: -12px;
      }

      select {
        font-size: 14px;
      }
    }

    .flow-count {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 57px;

      .flow-count-article {
        p {
          margin: 0;
          margin-top: 10px;
        }
      }
    }

    .flow-chart {
      margin-top: 20px;
    }
  }
}

/*.new-content-right {*/
/*  width: calc(100vw - 210px);*/
/*}*/
.bg-green {
  background: url("../../../assets/top-bg-50.png") no-repeat;
  background-size: 100% 100%;
}

.bg-yellow {
  background: url("../../../assets/top-bg-70.png") no-repeat;
  background-size: 100% 100%;
}

.bg-red {
  background: url("../../../assets/top-bg.png") no-repeat;
  background-size: 100% 100%;
}

.title-box {
  padding: 0 20px;
  height: 50px;
  min-width: 200px;

  .item-title {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 50px;
    background: #0dff0d;
  }

  .icon-green {
    background: #55a030;
    width: 100%;
    height: 6px;
  }

  .icon-yellow {
    background: #e6a23c;
    width: 100%;
    height: 6px;
  }

  .icon-red {
    background: #f56c6c;
    width: 100%;
    height: 6px;
  }
}
</style>
<style lang="scss">
@import "~@/styles/box.scss";

.pl-drawer-select .el-date-editor .el-input__inner {
  padding: 0 25px !important;
}

.pl-drawer-select .el-drawer__body {
  padding: 10px 20px;
}

.right-closed {
  background: rgba(0, 0, 0, 0.7);
  width: 100%;
  height: 100%;
  position: absolute;
  left: 200px;
  z-index: 999;

  p {
    color: #fff;
    font-size: 30px;
    margin: 0;
    text-shadow: 2px 2px 3px #c6ff29;
  }
}

.vdr.active:before {
  // outline: none;
}

.vdr-stick-tm,
.vdr-stick-ml,
.vdr-stick-mr,
.vdr-stick-bm {
  display: none;
}

.main-box {
  position: relative;
  display: flex;

  .el-tabs {
    .el-tabs__header {
      padding-bottom: 10px;
    }

    .el-tabs__content {
      overflow-x: auto;
    }
  }

  .el-input--medium .el-input__inner {
    height: 30px;
    line-height: 30px;
    border-color: #eee;
    color: #409eff;
    font-family: monospace, monospace;
  }

  .el-select .el-input .el-select__caret {
    color: #0a51e0;
  }

  .el-input__suffix {
    right: 2px;
    top: 2px;
  }

  .is-focus {
    .el-input__suffix {
      top: -4px;
    }
  }

  .el-input--suffix {
    .el-input__inner {
      padding: 0;
    }
  }

  .box-footer {
    display: flex;
    align-items: center;
    font-size: 14px;

    p {
      padding: 0;
      margin: 15px 0 0 15px;
      cursor: pointer;

      &:hover {
        color: blue;
      }
    }
  }

  .right-btn {
    i {
      cursor: pointer;
      margin: 0;

      &:hover {
        font-weight: bold;
      }
    }
  }
}

.active-server {
  color: #ebff10;
  animation: blink 1s linear infinite;
  -webkit-animation: blink 1s linear infinite;
  -moz-animation: blink 1s linear infinite;
  -ms-animation: blink 1s linear infinite;
  -o-animation: blink 1s linear infinite;
}

@keyframes blink {
  0% {
    color: #ebff10;
  }

  50% {
    color: red;
  }

  100% {
    color: #ebff10;
  }
}
</style>
