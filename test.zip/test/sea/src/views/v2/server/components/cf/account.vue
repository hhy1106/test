<template>
  <div class="app-container page-upgrade">

    <div class="btn-group">
      <!-- <router-link to="/" style="color: blue;margin-right: 10px;">
        <i class="el-icon-back"></i>返回首页
      </router-link> -->

      <!-- <el-input
        v-model="keywordsInput"
        placeholder="请输入服务器主IP或者服务器备注"
        style="width: 240px;margin-left: auto;"
      /> -->

      <el-button
        type="primary"
        style="margin-left: auto;"
        @click="dialogCreate = true;actionType='add'">
        <i class="el-icon-plus"></i>
        添加
      </el-button>

      <el-button
        type="success"
        @click="getList()">
        <i class="el-icon-refresh"></i>
        刷新
      </el-button>

    </div>

    <!-- 展示列表 -->
    <el-table
      v-loading="listLoading"
      ref="multipleTable"
      :data="dataList"
      stripe border fit
      highlight-current-row
      style="width: 100%;"
    >

      <el-table-column label="id">
        <template slot-scope="{row}">
          {{ row.id }}
        </template>
      </el-table-column>

      <el-table-column label="服务商">
        <template slot-scope="{row}">
          {{ row.lsp }}
        </template>
      </el-table-column>

      <el-table-column show-overflow-tooltip label="秘钥值/邮箱">
        <template slot-scope="{row}">
          <span>{{ row.keySecret }}</span>
        </template>
      </el-table-column>

      <el-table-column show-overflow-tooltip label="Global API Key">
        <template slot-scope="{row}">
          <span>{{ row.keyId }}</span>
        </template>
      </el-table-column>

      <el-table-column show-overflow-tooltip label="备注">
        <template slot-scope="{row}">
          <span>{{ row.remark }}</span>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="250">
        <template slot-scope="scope">
          <el-button class="el-btn--mini" type="primary" plain size="mini" @click="editForm(scope.row)"><i class="el-icon-edit"></i>编辑</el-button>
          <!-- <el-button class="el-btn--mini" type="info" plain size="mini" @click="domainPage(scope.row)"><i class="el-icon-download"></i>一键同步</el-button> -->
          <el-button class="el-btn--mini" type="danger" plain size="mini" @click="deleteRow(scope.row)"><i class="el-icon-delete"></i>删除</el-button>
        </template>
      </el-table-column>

    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="page" :limit.sync="limit" @pagination="getList" />

    <!-- 添加/编辑账号 -->
    <el-dialog
      :title="dialogTitle"
      class="pl-drawer"
      :wrapperClosable="false"
      :visible.sync="dialogCreate"
      :direction="direction">
      <el-form ref="form" :model="formAdd" label-width="130px">

        <el-form-item label="服务商：">
          <el-select v-model="formAdd.lsp" placeholder="请选择服务商" style="width: 100%;">
            <el-option label="tencent" value="tencent"></el-option>
            <el-option label="aliyun" value="aliyun"></el-option>
            <el-option label="cloudflare" value="cloudflare"></el-option>
          </el-select>
        </el-form-item>


        <el-form-item label="Global API Key：">
          <el-input v-model="formAdd.keyId" placeholder="必填"></el-input>
        </el-form-item>

        <el-form-item label="秘钥值/邮箱：">
          <el-input v-model="formAdd.keySecret" placeholder="必填"></el-input>
        </el-form-item>

        <el-form-item label="备注：">
          <el-input wrap="off"
            type="textarea"
            v-model="formAdd.remark"
            placeholder="选填">
          </el-input>
        </el-form-item>

        <el-button
          type="primary"
          @click="startCreate"
          :loading="loadingBtn"
          style="width: 100%;">
          提交
        </el-button>

        </el-form-item>
      </el-form>
    </el-dialog>

  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import { parseTime, formatTime } from '@/utils/index'
  import Pagination from '@/components/Pagination'
  import {
    cfUserList,
    cfUserAdd,
    cfUserDelete,
    cfUserUpdate,
    cfUserSearch,
    cfDomainSync,
    cfDomainLocalDel,
    cfDomainSearch,
    sycnCloudDomain,
    localDomainList,
    batchAddRecord,
    batchDelRecord,
    localDelRecordList,
  } from '@/api/cloudflare'
  import clip from '@/utils/clipboard'

  export default {
    components: {
      Pagination
    },
    data() {
      return {
        dialogTitle: '添加账号',
        direction: 'ltr',
        total: 0,
        page: 1,
        limit: 10,
        dataList: [],
        dialogCreate: false,
        listLoading: false,
        loadingBtn: false,
        actionType: 'add',
        dnsUserId: null,
        formEdit: {},
        domainList: [],
        formAdd: {
          lsp: '',
          keyId: '',
          keySecret: '',
          remark: '',
        }
      }
    },
    mounted() {
      this.getList()
    },
    methods: {
      startCreate() {
        if (!this.formAdd.lsp) {
          return this.$message.info('服务商必填');
        } else if (!this.formAdd.keyId) {
          return this.$message.info('秘钥key必填');
        } else if (!this.formAdd.keySecret) {
          return this.$message.info('秘钥值/邮箱必填');
        }
        this.loadingBtn = true
        this.actionType == 'add' ? this.submitCreate(this.formAdd) : this.submitUpdate(this.formEdit)
      },
      submitCreate(item) { // 增
        let parmers = {};
        parmers.alias = Date.parse(new Date())
        parmers.lsp = item.lsp
        parmers.keyId = item.keyId
        parmers.keySecret = item.keySecret
        parmers.remark = item.remark
        cfUserAdd(parmers).then(res => {
          if (res.status) {
            this.$message({
              type: 'success',
              message: '账号添加成功'
            });
            this.dialogCreate = false
            this.getList()
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
          this.loadingClose()
        }).catch(err => {
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      },
      submitUpdate(item) { // 增
        let parmers = {};
        parmers.alias = Date.parse(new Date())
        parmers.dnsUserId = this.dnsUserId
        parmers.keyId = item.keyId
        parmers.keySecret = item.keySecret
        parmers.remark = item.remark
        cfUserUpdate(parmers).then(res => {
          if (res.status) {
            this.$message({
              type: 'success',
              message: '账号修改成功'
            });
            this.dialogCreate = false
            this.getList()
          } else {
            this.$message({
              type: 'error',
              message: res.message
            });
          }
          this.loadingClose()
        }).catch(err => {
          setTimeout(() => {
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      },
      deleteRow (row) {
        this.$confirm(`将永久删除该条账号，是否继续?`, '操作确认', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let parmers = {};
          parmers.dnsUserId = row.id
          cfUserDelete(parmers).then(res => {
            if (res.status) {
              this.$message({
                type: 'success',
                message: '账号删除成功'
              });
              this.getList()
            } else {
              this.$message({
                type: 'error',
                message: res.message
              });
            }
          }).catch(err => {
          })
        }).catch(() => {
        });
      },
      editForm (row) {
        this.dialogTitle = '编辑账号'
        this.actionType = 'edit'
        this.dialogCreate = true
        this.dnsUserId = row.id
        this.formAdd = row
        this.formEdit = this.formAdd
      },
      domainPage(row) {
        this.getDomainList(row.id)
      },
      getDomainList(id) { // 查
        this.listLoading = true
        this.loadingBtn = true
        let parmers = {}
        parmers.dnsUserId = id
        cfDomainSync(parmers).then(response => {
          if(response.status) {
          }
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
          }, 1.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      },
      getList() { // 查
        this.listLoading = true
        this.loadingBtn = true
        let parmers = {}
        cfUserList().then(response => {
          if(response.status) {
            this.dataList = response.data.data
          }
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
          }, 1.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.listLoading = false
            this.loadingBtn = false
          }, 1.5 * 1000)
        })
      },
      loadingClose() {
        const loadingInstance = Loading.service()
        this.$nextTick(() => {
          this.loading = false
          this.loadingBtn = false
          loadingInstance.close()
        })
      },
      handleCopy(text, event) {
        clip(text, event)
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
</style>
<style lang="scss">
</style>
