<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '250px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      timeData: [],
      timer: '',
      chart: null
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val)
      }
    }
  },
  mounted() {
    console.log(this.$el,'$el')
    this.$nextTick(() => {
      this.getTime()
    })
    this.timer = setInterval(this.getTime, 3000)
  },
  beforeDestroy() {
    clearInterval(this.timer)
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    getTime() {
      const myDate = new Date() // 实例一个时间对象；
      myDate.getHours() // 获取系统时，
      myDate.getMinutes() // 分
      myDate.getSeconds() // 秒
      const currentTime = `${myDate.getHours()}:${myDate.getMinutes()}:${myDate.getSeconds()}`
      this.timeData.push(currentTime)
      console.log(this.timeData,'72')
      if (this.timeData.length > 7) {
        this.timeData = this.timeData.slice(this.timeData.length - 7, this.timeData.length)
      }
      this.$nextTick(() => {
        this.initChart()
      })
    },
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      this.setOptions(this.chartData)
    },
    setOptions({ upData, downData } = {}) {
      this.chart.setOption({
        xAxis: {
          // data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          data: this.timeData,
          boundaryGap: false,
          axisTick: {
            show: true
          }
        },
        grid: {
          left: 30,
          right: 30,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          // data: ['上行', '下行']
          data: []
        },
        series: [{
          name: '上行', itemStyle: {
            normal: {
              color: '#f7b851',
              lineStyle: {
                color: '#f7b851',
                width: 2
              },
              areaStyle: {
                color: '#f7b851'
              }
            }
          },
          smooth: true,
          type: 'line',
          data: upData,
          animationDuration: 2800,
          animationEasing: 'cubicInOut'
        },
        {
          name: '下行',
          smooth: true,
          type: 'line',
          itemStyle: {
            normal: {
              color: '#52a9ff',
              lineStyle: {
                color: '#52a9ff',
                width: 2
              },
              areaStyle: {
                color: '#52a9ff'
              }
            }
          },
          data: downData,
          animationDuration: 2800,
          animationEasing: 'quadraticOut'
        }]
      })
    }
  }
}
</script>
