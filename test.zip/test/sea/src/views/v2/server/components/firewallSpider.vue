<template>
  <div class="">
    <el-form-item label="✓ 防火墙状态：" v-if="rowData.deploy == 'clone'">
      <el-switch
        v-model="configData.firewall.status"
        active-color="#2e79f4"
        inactive-color="#ddd"
        active-text="开启"
        inactive-text="关闭"
      ></el-switch>
    </el-form-item>

    <el-form-item label="✓ 百度权重阀值：(百度权重超过此值就开始风控)" class="form-item-slider" v-if="rowData.deploy == 'clone'">
      <el-slider
        v-model="configData.firewall.warning"
        :max="10"
        show-input>
      </el-slider>
    </el-form-item>

    <el-form-item label="✓ 访问成功率：(0-100，0是不可访问，100是完全可访问)" class="form-item-slider" v-if="rowData.deploy == 'clone'">
      <el-slider
        v-model="configData.firewall.access_rate"
        show-input>
      </el-slider>
    </el-form-item>

    <el-form-item label="✓ 蜘蛛白名单(勾选放行的蜘蛛):" class="form-item-slider" v-if="rowData.deploy == 'clone'">
      <el-checkbox label="百度蜘蛛" v-model="configData.spider.baidu"></el-checkbox>
      <el-checkbox label="百度渲染" v-model="configData.spider.baidu_render"></el-checkbox>
      <el-checkbox label="百度蜘蛛(新)" v-model="configData.spider.Baiduspider"></el-checkbox>
      <el-checkbox label="360蜘蛛" v-model="configData.spider['360spider']"></el-checkbox>
      <el-checkbox label="搜狗蜘蛛" v-model="configData.spider.Sogouwebspider"></el-checkbox>
      <el-checkbox label="必应蜘蛛" v-model="configData.spider.bingbot"></el-checkbox>
      <el-checkbox label="雅虎蜘蛛" v-mozdel="configData.spider.Yahoo"></el-checkbox>
      <el-checkbox label="谷歌蜘蛛" v-model="configData.spider.Googlebot"></el-checkbox>
      <el-checkbox label="谷歌蜘蛛2" v-model="configData.spider.google"></el-checkbox>
      <el-checkbox label="有道蜘蛛" v-model="configData.spider.YoudaoBot"></el-checkbox>
      <el-checkbox label="易搜蜘蛛" v-model="configData.spider.EasouSpider"></el-checkbox>
      <el-checkbox label="SOSO蜘蛛" v-model="configData.spider.Sosospider"></el-checkbox>
    </el-form-item>
  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import {
    severConfig,
  } from '@/api/server'

  export default {
    props: {
     rowData: Object
    },
    data() {
      return {
        configData: {
          firewall: {
             status: 'on', // status是状态，on开启，off关闭
             warning: 5, // 百度权重触发值，权重到5就开始风控
             access_rate: 20, // 访问成功率，0-100，0是不可访问，100是完全可访问
             block_area: true // 表示禁止【上海、北京】区域的所有流量
          },
          spider: { // on放行，off屏蔽
            '360spider': false,
            baidu: false,
            baidu_render: false,
            google: false,
            Baiduspider: false,
            Googlebot: false,
            bingbot: false,
            Sosospider: false,
            Yahoo: false,
            Sogouwebspider: false,
            YoudaoBot: false,
            EasouSpider: false
          }
        }
      }
    },
    mounted() {
      this.configData = JSON.parse(this.rowData.spider_config)
      for (let key in this.configData.spider) {
        this.configData.spider[key] == 'on' ? this.configData.spider[key] = true : this.configData.spider[key] = false
      }
    },
    methods: {
      onSubmitConfig() {
        for (let name in this.configData.spider) {
          if(this.configData.spider[name] === true) {
            this.configData.spider[name] = 'on'
          } else {
            this.configData.spider[name] = 'off'
          }
        }
        this.listLoading = true
        this.loadingCon = true
        let parmers = {}
        parmers.config = JSON.stringify(this.configData)
        severConfig(this.configData.id, parmers).then(res => {
          if(res.status) {
            this.$message({
              showClose: true,
              type: 'success',
              message: '更新成功'
            });
            this.loadingCon = false
          } else {
            this.$message({
              showClose: true,
              type: 'error',
              message: res.message
            });
          }
          setTimeout(() => {
            this.listLoading = false
            this.loadingCon = false
          }, 0.5 * 1000)
        }).catch(err => {
          console.log(err)
          setTimeout(() => {
            this.listLoading = false
            this.loadingCon = false
          }, 0.5 * 1000)
        })
      }
    },
    watch: {
      rowData: function (newval, oldVal) {
        if(newval) {
          this.configData.id = newval.id
          this.configData.iname = newval.iname
          this.configData.server_ip = newval.server_ip
          this.configData.alive_time = newval.alive_time
          this.flag1 = true
          this.flag2 = true
          this.flag3 = true
          this.flag4 = true
          this.showCancelBtn = false
          this.taskStatus = ''
          this.installServerStatus()
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
</style>

<style lang="scss">
  .el-drawer__open .el-drawer.ltr {
    width: 480px !important;
    overflow-y: auto;
    .el-checkbox {
      min-width: 80px;
    }
  }
  .config-page {
    .el-slider__input {
        float: none!important;
    }
  }
  .el-drawer__body {
      padding: 0 30px;
  }
</style>
