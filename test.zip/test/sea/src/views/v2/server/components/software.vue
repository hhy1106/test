<template>
  <div>
    <div slot="header" class="clearfix">
      <span>程序软件<i class="el-icon-refresh" @click="getList()" style="float:right;cursor: pointer;"></i></span>
    </div>
    <div class="soft-list">
      <div class="item"
        v-for="(item, index) in softList"
        :key="index"
        @click="softAction(item.value,item.status)">
        <svg-icon :icon-class="`ico-${item.label}`" />
        <div class="soft-title">
          <label>{{ item.label }}</label>
          <i class="el-icon-caret-right"
            v-if="item.value == 'nginx' || item.value == 'redis'">
          </i>
        </div>
        <el-tag type="info" v-if="item.status == '查询中'">
          <i class="el-icon-loading"></i>查询中
        </el-tag>
        <el-tag type="success" v-if="item.status == '运行中'">
          <i class="el-icon-success"></i>
          {{ item.status }}
        </el-tag>
        <el-tag type="danger" v-if="item.status != '运行中' && item.status != '查询中'">
          <i class="el-icon-warning"></i>
          {{ item.status }}
        </el-tag>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <el-dialog
      :title="`${softSelect}管理`"
      :visible.sync="dialogVisible"
      width="600px">

      <el-tabs :tab-position="tabPosition" type="border-card" style="height: 300px;">
        <el-tab-pane label="服务">
          当前状态：开启<i class="el-icon-caret-right"></i>
          <div class="btn-group-server">
            <el-button size="small" @click="softControll('start')" v-if="softStatus == '未运行'">开启</el-button>
            <el-button size="small" @click="softControll('stop')" v-if="softStatus == '运行中'">停止</el-button>
            <el-button size="small" @click="softControll('reStart')">重启</el-button>
            <el-button size="small" @click="softControll('reload')">重载配置</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane label="配置修改">

        </el-tab-pane>
      </el-tabs>

    </el-dialog>

  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import serversSelect from '@/components/servers-select'
  import {
    pluginGet,
    pluginControll,
    systemLoadStatus
  } from '@/api/server'

  export default {
    props: ['sid'],
    components: {
      serversSelect
    },
    data() {
      return {
        softStatus: '',
        tabPosition: 'left',
        softSelect: 'nginx',
        dialogVisible: false,
        softList: [
          {
            label: 'nginx',
            value: 'nginx',
            status: '查询中'
          }, {
            label: 'redis',
            value: 'redis',
            status: '查询中'
          }, {
            label: 'clone',
            value: 'clone',
            status: '查询中'
          }, {
            label: 'tinyproxy',
            value: 'tinyproxy',
            status: '查询中'
          }
        ]
      }
    },
    mounted() {
      if(this.sid) {
        this.getList()
      }
    },
    methods: {
      getList() {
        this.softList.forEach((item) => {
          this.softInsalled(item.value)
        })
      },
      softInsalled() { // 已安装软件
      if (!this.rowData?.id) {
        return
      }
      const query = {
        server_id: this.rowData.id
      }
      pluginGet(query).then(response => {
        if (response.data) {
          const softList = []
          for (const key in response.data) {
            const configData = {
              flag: response.data[key],
              name: key,
            }
            softList.push(configData)
          }
          this.softList = softList
          // this.softList.forEach((item) => {
          //   if (item.value == response.name) {
          //     item.status = response.message
          //   }
          // })
        }
      }).catch(err => {
        console.log(err)
      })
    },
      softAction(val, status) {
        if(!this.sid) {
          return this.$message.info('请先选择要操作的服务器');
        }
        this.softStatus = ''
        this.dialogVisible = true
        this.softSelect = val
        this.softStatus = status
      },
      softControll(command) {
        this.$alert('确认此操作, 是否继续?', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            if (action == 'confirm') {

              let parmers = {}
              parmers.sid = this.sid
              parmers.para = this.softSelect
              parmers.name = this.softSelect
              parmers.action = command

              pluginControll(parmers).then(res => {
                if (res.message = '操作成功') {
                  this.$message({
                    type: 'success',
                    message: res.message
                  });
                  this.dialogCreate = false
                } else {
                  this.$message({
                    type: 'error',
                    message: res.message
                  });
                }
              }).catch(err => {
              })
            }
          }
        });
      },
      selectServerFromSon(msg, list) {
        if(msg) {
          list.forEach((item) => {
            if(item.value == msg) {
              this.sid =item.sid
              setTimeout(function() {
                this.softInsalled()
              }, 1000);
            }
          })
        }
      }
    },
    watch: {
      sid(val) {
        if(val) {
          this.softInsalled()
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~@/styles/common.scss";
</style>

<style lang="scss" scoped>
  .soft-list {
    display: flex;
    margin-top: 15px;
    border-top: 1px solid #ececfb;
    .item {
      width: 25%;
      text-align: center;
      border-bottom: 1px solid #ececfb;
      border-left: 1px solid #ececfb;
      border-right: 1px solid #ececfb;
      margin-right: -1px;
      margin-bottom: -1px;
      height: 148px;
      cursor: pointer;
      padding:0;
      .soft-title {
        margin: 0 0 10px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      &:hover {
        box-shadow: 0 0 38px rgb(0 0 0 / 8%) inset;
        -webkit-transition: all .25s ease;
        transition: all .25s ease;
      }
      label {
        display: block;
      }
      .svg-icon {
        margin: 15px 0 15px;
        width: 40px!important;
        height: 40px!important;
      }
    }
    .el-icon-caret-right {
      color: #20a53a;
      font-size: 20px;
    }
  }
  .btn-group-server {
    margin: 15px 0 0;
  }
</style>
