<template>
  <div>
    <div class="sys-page" v-if="showPage">
      <div class="btn">
        <el-button
          type="success"
          icon="el-icon-circle-check"
          size="mini"
          class="left-btn"
          @click="submitLeftData"
        >保存修改
        </el-button>
        <el-button
          type="success"
          icon="el-icon-circle-check"
          size="mini"
          @click="submitRightData"
          class="right-btn"
        >保存修改
        </el-button>
      </div>
      <div class="form-con">
        <div class="form-con-left">
          <div class="label-name">
            <span class="name">启用站点:</span>
            <el-switch
              @change="openSite()"
              v-model="siteSwitch">
            </el-switch>
          </div>
          <div class="btns-group">
            <el-button type="primary" size="small" @click="updateSite('index')">更新首页</el-button>
            <el-button type="primary" size="small" @click="updateSite('all')">更新全站</el-button>
            <el-button type="primary" size="small" @click="openKeywords('friendLink')">上传友链</el-button>
            <el-button type="primary" size="small" @click="openKeywords('keywords')">上传词库</el-button>
            <el-button type="primary" size="small" @click="clearAll()">清反向缓存</el-button>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>网站协议:</span>
            <el-radio-group v-model="form.scheme">
              <el-radio label="http">http</el-radio>
              <el-radio label="https">https</el-radio>
            </el-radio-group>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>网站域名:</span>
            <el-radio-group v-model="form.alias">
              <el-radio label="auto">跟随</el-radio>
              <el-radio label="*">泛域名</el-radio>
              <el-radio label="zhiding">指定</el-radio>
            </el-radio-group>
            <el-input v-model="alias" size="small" v-if="form.alias=='zhiding'" maxlength="10"
                      style="width: 100px; margin-left: 20px"
                      placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>网站名称:</span>
            <el-input v-model="form.name" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>分组:</span>
            <el-input v-model="form.group" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>网站模板:</span>
            <el-select v-model="form.template" size="small" placeholder="请选择">
              <el-option
                v-for="(item,index) in templateList"
                :key="index"
                :label="item.iname"
                :value="item.id">
              </el-option>
            </el-select>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>友情配置:</span>
            <el-switch
              v-model="form.outlink"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>统计配置:</span>
            <el-radio-group v-model="form.tj">
              <el-radio label="account">使用账户</el-radio>
              <el-radio label="group">使用分组</el-radio>
              <el-radio label="site">使用站点</el-radio>
            </el-radio-group>
          </div>
          <div class="label-name">
            <span class="name"><span class="red">*</span>广告配置:</span>
            <el-radio-group v-model="form.ad">
              <el-radio label="off">关闭</el-radio>
              <el-radio label="account">使用账户</el-radio>
              <el-radio label="group">使用分组</el-radio>
              <el-radio label="site">使用站点</el-radio>
            </el-radio-group>
          </div>
          <!--        <div class="label-name">-->
          <!--          <span class="name">LOGO:</span>-->

          <!--        </div>-->
        </div>
        <div class="form-con-right">
          <div class="big-title">TKD配置
            <el-button type="primary" size="small" @click="handleClone()">一键同步克隆</el-button>
          </div>
          <div class="small-title">
            <p>TKD支持的变量:支持的标签:
              <el-tag effect="plain" size="mini" @click="copyTxt('{sitename}')">{sitename}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{domain}')">{domain}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{year}')">{year}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{word1}')">{word1}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{word2}')">{word2}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{word3}')">{word3}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{word4}')">{word4}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{word5}')">{word5}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{word6}')">{word6}</el-tag>
              <el-tag size="mini" effect="plain" @click="copyTxt('{resname}')">{resname}</el-tag>
            </p>
            <p></p>
          </div>
          <div class="label-name">
            <span class="name">首页标题:</span>
            <el-input v-model="tkdForm.seo_t" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name">首页关键词:</span>
            <el-input v-model="tkdForm.seo_k" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name">首页描述:</span>
            <el-input v-model="tkdForm.seo_d" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name">内页标题:</span>
            <el-input v-model="tkdForm.in_t" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name">内页关键词:</span>
            <el-input v-model="tkdForm.in_k" size="small" placeholder="请输入内容"></el-input>
          </div>
          <div class="label-name">
            <span class="name">内页描述:</span>
            <el-input v-model="tkdForm.in_d" size="small" placeholder="请输入内容"></el-input>
          </div>
        </div>

      </div>
      <!--上传词库弹窗-->
      <el-dialog
        title="上传词库"
        :visible.sync="dialogKeyWord"
        width="800px"
        :close-on-click-modal="false"
        :close-on-press-escape="false"
      >
        <div class="dia-keyword">
          <div class="key-left">
            <div class="list-item">
              <span>影响范围:</span>
              <el-radio-group v-model="zone">
                <el-radio label="account">当前账户</el-radio>
                <el-radio label="group">{{groupName}}分组</el-radio>
                <el-radio label="site">当前站点：{{domain}}</el-radio>
              </el-radio-group>
            </div>
            <el-upload
              ref="upload"
              drag
              class="upload"
              action="string"
              :file-list="fileList"
              :auto-upload="false"
              :http-request="uploadFile"
              :on-change="handleChange"
              accept=".txt"
            >
              <i class="el-icon-upload"/>
              <div class="el-upload__text">将文件拖到此处，或<em>点击导入</em></div>
              <div slot="tip" class="el-upload__tip" style="margin: 10px 0">只能上传txt文件且不超过10M</div>
            </el-upload>

          </div>
          <div class="key-right">
            <p>说明:</p>
            <template v-if="updateType=='keywords'">
              <p>1、词库是一行一个词</p>
              <p>2、最大支持10M</p>
              <p>3、账户词库影响账户下所有站点</p>
              <p>4、分词词库，影响该分组下的所有站点</p>
            </template>
            <template v-else>
              <p>1、友链是一行一个链接，格式为:标题#URL</p>
              <p>2、最大支持10M</p>
              <p>3、账户友链影响账户所有站点</p>
              <p>4、分组友链影响分组所有站点</p>
            </template>
          </div>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="newSubmit">确 定</el-button>
          <el-button style="margin-left: 60px" @click="dialogKeyWord=false">取 消</el-button>
        </div>
      </el-dialog>
    </div>
    <div class="sys-page" v-else>
      请去添加该站点
    </div>
  </div>
</template>

<script>
  import {
    getSiteInfo,
    updatePurge,
    postWebsitTkd,
    postWebsiteSave,
    getTemplateList,
    updateKeyAndFl,
    clearPurge
  } from '@/api/moreSite'
  import {
    websiteDelete,
    getTdkList,
    updateSpiderConfig
  } from '@/api/website'

  export default {
    props: {
      spiderConfig: {},
      sid: {},
      row: {}
    },
    data() {
      return {
        showPage: true,
        siteSwitch: true,
        domain: '',
        groupName: '',
        form: {
          domain: '',
          scheme: 'http',
          alias: 'auto',
          template: '',
          name: '',
          logo: '',
          group: '',
          outlink: 0,
          tj: 'account',
          ad: 'off'
        },
        alias: '',
        tkdForm: {
          domain: '',
          seo_t: '',
          seo_k: '',
          seo_d: '',
          in_t: '',
          in_k: '',
          in_d: '',
        },
        templateList: [],
        dialogKeyWord: false,
        updateType: '',
        zone: 'account',
        fileList: [],

      }
    },
    watch: {
      row(val) {
        this.tkdForm.domain = val.domain
        this.form.domain = val.domain
        this.domain = val.domain
        console.log('换域名')
        this.getSite()
      },
      spiderConfig() {
        if(this.sid){
          this.getProxyHost()
        }
      }
    },
    mounted() {
      console.log(this.spiderConfig, 'currentConfigcurrentConfigcurrentConfig')
      if (this.row && this.row?.domain) {
        this.form.domain = this.row.domain
        this.groupName = this.row.igroup
        this.tkdForm.domain = this.row.domain
        this.domain = this.row.domain
        console.log('初始化域名')
        this.getSite()
      }
      // 获取模板列表
      this.getTemplate()
      if(this.sid) {
        this.getProxyHost()
      }else{
        this.$message({
          type: 'error',
          message: '请选择服务器'
        });
      }
    },
    methods: {
      // 判断有没有proxy_host
      getProxyHost() {
        if(!this.spiderConfig?.proxy_host){
          this.$prompt('请输入泛站群的apihost域名', '提示', {
            confirmButtonText: '确定',
            showClose:false,
            showCancelButton:false,
            closeOnClickModal:false,
            closeOnPressEscape:false,
            inputValue: '',
            inputValidator: (value) => {
              if(!value) {
                return '请输入泛站群的apihost域名！';
              }
            },
            //
            //
            // beforeClose: (action, instance, done) => {
            //   console.log(instance,'instance')
            //   const self=this
            //   if (action === 'confirm') {
            //     instance.$refs['confirm'].$el.onclick = function (e) {
            //       e = e || window.event;
            //       console.log(e.detail,'instance')
            //       if (e.detail) {
            //         const config={
            //           ...self.spiderConfig,
            //           proxy_host:value
            //         }
            //         updateSpiderConfig({
            //           server_id:self.sid,
            //           config:JSON.stringify(config)
            //         }).then(res => {
            //           if (res.status) {
            //             localStorage.setItem('__FANZHANQUNHOST__', e.detail)
            //             self.$message({
            //               type: 'success',
            //               message: '操作成功'
            //             })
            //             done();
            //           } else {
            //             self.$message({
            //               type: 'error',
            //               message: res.message
            //             })
            //           }
            //
            //         })
            //         // done();
            //       }
            //     }
            //
            //
            //   }
            // }

          }).then(async ({ value }) => {
            const config={
              ...this.spiderConfig,
              proxy_host:value
            }

            await updateSpiderConfig({
              server_id:this.sid,
              config:JSON.stringify(config)
            }).then(res => {
              if (res.status) {
                localStorage.setItem('__FANZHANQUNHOST__',value)
                this.$message({
                  type: 'success',
                  message: '操作成功'
                })

              } else {
                this.$message({
                  type: 'error',
                  center: true,
                  message: res.message
                })
              }
            })



            // this.$message({
            //   type: 'success',
            //   message: '你的邮箱是: ' + value
            // });
          })
        }

      },

      handleClone() {
        if (this.domain) {
          getTdkList({
            site_id: 0,
            domain: this.domain
          }).then(res => {
            if (res.status) {
              const cloneData = res?.data
              this.tkdForm = {
                domain: this.domain,
                seo_t: cloneData?.idx_t || '',
                seo_k: cloneData?.idx_k || '',
                seo_d: cloneData?.idx_d || '',
                in_t: cloneData?.inner_t || '',
                in_k: cloneData?.inner_k || '',
                in_d: cloneData?.inner_d || '',
              }
            } else {
              this.$message({
                type: 'error',
                message: res.message
              })
            }

          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择域名'
          })
        }

      },
      openSite() { // 启用站点
        if (this.row.id || this.row.site_id) {
          const parmers = {
            site_id: this.row.id || this.row.site_id,
            action: 'online'
          }
          websiteDelete(parmers).then(res => {
            if (res.status) {
              this.$message({
                type: 'success',
                message: '操作成功！'
              })
            } else {
              this.$message({
                type: 'error',
                message: res.message
              })
            }

          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择域名'
          })
        }

      },

      getSite() {
        getSiteInfo({
          domain: this.domain
        }).then(response => {
          if (response.status) {
            const res = response.data
            let extra = {}
            if (res.extra) {
              extra = JSON.parse(res.extra)
            }
            if (res) {
              this.form = {
                domain: res?.domain || '',
                scheme: res?.scheme || 'http',
                alias: res.alias == 'auto' || res.alias == '*' ? res.alias : 'zhiding',
                template: res.tpl || '',
                name: res?.iname || '',
                // logo: '',
                group: res?.igroup || 'defult',
                outlink: extra?.outlink || 0,
                tj: extra?.tj || 'account',
                ad: extra?.ad || 'off'
              }
              if (!(res.alias == 'auto' || res.alias == '*')) {
                this.alias = res.alias
              }
              this.tkdForm = {
                domain: res?.domain || '',
                seo_t: res?.seo_t || '',
                seo_k: res?.seo_k || '',
                seo_d: res?.seo_d || '',
                in_t: res?.in_t || '',
                in_k: res?.in_k || '',
                in_d: res?.in_d || '',
              }
              console.log(this.tkdForm)
            }


            // this.showPage=true
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      },
      copyTxt(data) {
        var input = document.createElement("input"); // 创建input对象
        input.value = data; // 设置复制内容
        document.body.appendChild(input); // 添加临时实例
        input.select(); // 选择实例内容
        document.execCommand("Copy"); // 执行复制
        document.body.removeChild(input); // 删除临时实例
        this.$message({message: '成功复制到粘贴板', type: 'success'})
        // const save = function(e) {
        //   e.clipboardData.setData('text/plain', data)
        //   e.preventDefault() // 阻止默认行为
        // }
        // document.addEventListener('copy', save) // 添加一个copy事件
        // document.execCommand('copy') // 执行copy方法
        // this.$message({ message: '成功复制到粘贴板', type: 'success' })
      },
      uploadFile(file) {
        this.formData.append('file', file.file)
      },
      handleChange(file, fileList) {
        this.fileList = fileList
        //   此处就是放置在before-upload里的，用于判断可上传文件的格式
        const testmsg = file.name.substring(file.name.lastIndexOf('.') + 1)
        const extension = testmsg === 'txt'
        if (!extension) {
          this.$message(
            {
              message: '上传文件只能是.txt格式!',
              type: 'warning'
            }
          )
        }
        return extension
      },
      async newSubmit() {
        // 上传到服务器
        if (this.fileList === [] || this.fileList.length < 1) {
          this.$message({
            type: 'info',
            message: '请选择要上传的文件'
          })
          return false
        }
        const formData = new FormData()
        formData.append('domain', this.domain)
        formData.append('dict', this.updateType == 'keywords' ? 'word' : 'link')
        formData.append('zone', this.zone)
        formData.append('file', this.fileList[0].raw)
        // const formData={
        //   domain:this.domain,
        //   dict:this.updateType == 'keywords' ? 'word' : 'link',
        //   zone:this.zone,
        //   file:this.fileList[0].raw
        // }
        updateKeyAndFl(formData).then(response => {
          if (response.status) {
            this.$message({
              type: 'success',
              message: '操作成功'
            })
            this.dialogKeyWord = false
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        }).catch(err => {
          console.log(err)
        })
      },
      getTemplate() {
        const req = {
          type: 'all',
          name: '',
          status: 1
        }
        getTemplateList(req).then(response => {
          if (response.status) {
            this.templateList = response?.data?.list || []
          }
        })
      },
      clearAll() {
        if (this.sid) {
          clearPurge({
            server_id: this.sid
          }).then(response => {
            if (!response.status) {
              this.$message({
                type: 'error',
                message: response.message
              })
            }
          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择服务器'
          })
        }

      },
      updateSite(zone) {
        if (this.domain) {
          updatePurge({
            domain: this.domain,
            zone: zone,//清除的缓存范围：all全站；index首页
          }).then(response => {
            if (!response.status) {
              this.$message({
                type: 'error',
                message: response.message
              })
            }
          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择一个域名'
          })
        }

      },


      openKeywords(type) {
        this.dialogKeyWord = true
        this.fileList = []
        this.zone = "account"
        this.updateType = type
      },
      submitLeftData() {
        if (this.form.domain) {
          let req = {}
          if (!this.form.name) {
            this.$message({
              type: 'error',
              message: '请输入网站名称'
            })
            return
          }
          if (!this.form.group) {
            this.$message({
              type: 'error',
              message: '请输入分组'
            })
            return
          } else {
            const groupReg = /[0-9a-zA-Z-_]/
            if (!groupReg.test(this.form.group)) {
              this.$message({
                type: 'error',
                message: '分组格式不正确'
              })
              return
            }
          }
          if (!this.form.template) {
            this.$message({
              type: 'error',
              message: '请选择网站模板'
            })
            return
          }
          if (this.form.alias != '*' && this.form.alias != 'auto') {
            if (this.alias) {
              const reg = /^[a-zA-Z\d]+$/
              if (reg.test(this.alias)) {
                req = {
                  ...this.form,
                  alias: this.alias
                }
              } else {
                this.$message({
                  type: 'error',
                  message: '长度是1-10,只能是数字和小写字母'
                })
                return
              }

            } else {
              this.$message({
                type: 'error',
                message: '长度是1-10,只能是数字和小写字母'
              })
              return
            }

          } else {
            req = this.form
          }
          postWebsiteSave(req).then(response => {
            if (response.status) {
              this.$message({
                type: 'success',
                message: '操作成功'
              })
            } else {
              this.$message({
                type: 'error',
                message: response.message
              })
            }
          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择一个域名'
          })
        }

      },
      submitRightData() {
        if (this.tkdForm.domain) {
          postWebsitTkd(this.tkdForm).then(response => {
            if (response.status) {
              this.$message({
                type: 'success',
                message: '操作成功'
              })
            } else {
              this.$message({
                type: 'error',
                message: response.message
              })
            }
          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择一个域名'
          })
        }

      },
    }
  }
</script>

<style lang="scss" scoped>
  .sys-page {
    width: calc(100% - 40px);
    margin: 20px;

    .btn {
      position: relative;
      height: 40px;

      .left-btn {
        position: absolute;
        top: -10px;
        left: 2px;
      }

      .right-btn {
        position: absolute;
        top: -10px;
        right: 2px;
      }

      .el-button--success {

        width: 95px !important;
        height: 28px;
        padding: 0 !important;
        line-height: 20px;
        font-size: 12px;
        background-color: #7eda50 !important;
        border: none !important;
        border-bottom: 2px solid #508c32 !important;
      }
    }

    .form-con {
      display: flex;

      .form-con-left {
        width: 500px;
        margin-right: 20px;

        .btns-group {
          margin-bottom: 15px;
        }

      }

      .form-con-right {
        flex: 1;

        .big-title {
          font-size: 14px;
          color: #000;
          font-weight: bold;

        }

        .small-title {
          font-size: 12px;

          p {
            ::v-deep .el-tag {
              margin-right: 10px;
              cursor: pointer;
            }
          }
        }
      }

      .form-con-left, .form-con-right {
        .label-name {
          margin-bottom: 15px;
          display: flex;
          align-items: center;

          .name {
            font-size: 14px;
            margin-right: 20px;
            font-weight: 700;
            color: #666;
            width: 100px;
            text-align: right;

          }

          ::v-deep .el-input {
            flex: 1;
            max-width: 450px;
          }

          ::v-deep .el-radio {
            margin-right: 10px !important;
          }
        }

      }


    }
  }

  .dia-keyword {
    display: flex;
    justify-content: space-between;

    .key-left {
      flex: 1;

      .list-item {
        display: flex;
        align-items: center;
        height: 40px;
        margin-bottom: 20px;
      }
    }

    .key-right {
      width: 300px;
    }

  }
</style>

