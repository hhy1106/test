<template>
  <div class="sys-page">
    <div class="btn">
      <el-button
        type="success"
        icon="el-icon-circle-check"
        size="mini"
        @click="submitData"
      >保存
      </el-button>
    </div>
    <div class="form-con">
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="广告邮箱">
          <el-input v-model="form.email"></el-input>
        </el-form-item>
        <el-form-item label="飞机账号">
          <el-input v-model="form.tele"></el-input>
        </el-form-item>
        <el-form-item label="永久域名">
          <el-input v-model="form.forever" placeholder="永久域名，支持配置泛域名。多个域名用 ; 分隔"></el-input>
        </el-form-item>
      </el-form>
    </div>


  </div>
</template>

<script>
  import {
    getMemberConfig,
    postMemberConfig
  } from '@/api/moreSite'

  export default {
    components: {
    },
    data() {
      return {
        form:{
          email:'',
          tele:'',
          forever:''
        },


      }
    },
    mounted() {
      this.getMember()
    },
    methods: {
      getMember(){
        getMemberConfig().then(response => {
          if (response.status) {
            const res=response?.data
            this.form={
              email:res?.email ||'',
              tele:res?.telegram ||'',
              forever:res?.forever ||''
            }
          }
        })
      },
     submitData(){
       if(!this.form.email){
         this.$message({
           type: 'error',
           message: '请输入广告邮箱'
         })
         return
       }
       if(!this.form.tele){
         this.$message({
           type: 'error',
           message: '请输入飞机账号'
         })
         return
       }
       if(!this.form.forever){
         this.$message({
           type: 'error',
           message: '请输入永久域名'
         })
         return
       }
       postMemberConfig(this.form).then(response => {
         if(response.status){
           this.$message({
             type: 'success',
             message:'操作成功'
           })
         }else{
           this.$message({
             type: 'error',
             message: response.message
           })
         }

       })

      },



    }
  }
</script>

<style lang="scss" scoped>
  .sys-page{
    width: calc(100% - 40px);
    margin: 20px;

    .btn{
      position: relative;
      height: 40px;
      .el-button--success {
        position: absolute;
        top:-10px;
        right: 2px;
        width: 95px !important;
        height: 28px;
        padding: 0 !important;
        line-height: 20px;
        font-size: 12px;
        background-color: #7eda50 !important;
        border: none !important;
        border-bottom: 2px solid #508c32 !important;
      }
    }
    .form-con{
      width: 500px;
    }
  }


</style>

