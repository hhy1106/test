<template>
  <el-dialog title="更换域名" :visible.sync="dialogVisible"  :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="change-con">
      <div class="red-text">当前域名:{{formData.domain}}</div>
      <el-form :inline="true" :model="formData" class="demo-form-inline">
        <el-form-item label="新域名">
          <el-input v-model="formData.new_domain" :disabled="isDisabled" size="small" placeholder="请输入"/>
        </el-form-item>
      </el-form>
      <div class="list-li">
        <p>1、请确保新域名在当前账户的DNS账户下；</p>
        <p>2、更换域名后，老域名将不能再访问该站点；</p>
        <p>3、如遇到证书申请不成功、自动解析不成功，请手动重试
        </p>
      </div>
      <div slot="footer" class="dialog-footer" >
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary"  :disabled="isDisabled" @click="onSubmitDomain">更换</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
  import {
    changeDomain
  } from '@/api/website'

  export default {
    props: {
      row: {
        type: Object,
        default: ''
      },
      currentConfig: {}
    },
    data() {
      return {
        formData: { // 更换域名data
          domain: '',
          new_domain: ''
        },
        isDisabled: true,
        rowId: null,
        dialogVisible:true,
      }
    },
    watch: {
      row(val) {
        if (val) {
          this.formData.domain = val?.domain
          this.formData.new_domain = val?.domain
          this.isDisabled = !val.id
          this.rowId = val.id
        } else {
          this.rowId = null
          this.isDisabled = true
        }
      }
    },
    mounted() {
      if (this.row) {
        this.formData.domain = this.row?.domain
        this.formData.new_domain = this.row?.domain
        this.isDisabled = !this.row.id
        this.rowId = this.row.id
      } else {
        this.rowId = null
        this.isDisabled = true
      }

      console.log(this.currentConfig, 'currentConfig')
    },
    methods: {
      closeDialog(){
        this.dialogVisible=false
        this.$emit('closeDialog')
      },
      // 切换域名
      onSubmitDomain() {
        if (this.row.id) {
          changeDomain(this.formData).then(response => {
            if (response.status) {
              this.$message({
                type: 'success',
                message: '操作成功!'
              })
              this.formData.domain = this.formData.new_domain
              this.dialogVisible=false
              this.$emit('closeDialog', this.formData.new_domain)
              // this.$emit('submitDomain')
            } else {
              this.$message({
                type: 'error',
                message: response.message
              })
            }
          })
        } else {
          this.$message({
            type: 'error',
            message: '请选择一个域名!'
          })
        }
      }
    }
  }
</script>

<style lang="scss" scoped>

  .change-con {
    flex: 1;

    .red-text {
      font-size: 14px;
      color: #ff4d51;
      font-weight: bold;
      margin-bottom: 30px;
    }

    ::v-deep .el-form-item__content {
      display: inline-block !important;
    }
    .dialog-footer{
      display: flex;
      justify-content: flex-end;
    }
  }

</style>
