<template>
  <div class="page-code">


    <div class="select-box">
      <el-select
        v-show="showPageSelect"
        v-model="pageType"
        placeholder="请选择一个"
        style="width: 220px;"
        @change="selectChange($event)"
      >
        <el-option
          v-for="(item, index) in optionsPage"
          :key="item.id"
          :label="item.label"
          :value="item.value"
        />
      </el-select>

      <!-- <h5>域名：{{ domain }} 的代码：</h5> -->

      <el-button
        class="btn-save"
        type="success"
        icon="el-icon-circle-check"
        :loading="loadingBtn"
        size="mini"
        style="margin-left: auto;"
        @click="onsubmit"
      >保存修改
      </el-button>
    </div>

    <div class="in-coder-panel panel-area">
      <div v-show="showUrlInput" class="left">
        <h5>网站域名：</h5>
        <el-input
          v-model="domain"
          width="100"
          rows="14"
          type="textarea"
          placeholder="请输入域名.一行一个"
          @blur="domainBlur($event)"
        />
        <!-- <el-button type="success" size="mini">读取域名</el-button> -->
      </div>

      <div class="right">
        <div class="form-item" v-if="pageType==='friendlink' && row.id">
          <span>友链展示：</span>
          <el-radio-group v-model="radioFriend"  size="small"   >
            <el-radio :label="0">不显示</el-radio>
            <el-radio :label="1">首页</el-radio>
            <el-radio :label="2">首页和内页全站</el-radio>
          </el-radio-group>
        </div>
        <h5>域名：{{ row.domain }} 的代码：</h5>
        <div class="row-second">
          <el-input
            v-if="pageType == 'other'"
            v-model="path"
            style="width: 440px;margin-left: 10px;"
            placeholder="请输入要修改页面的URL地址"
          />

          <el-button
            v-if="pageType == 'other'"
            type="primary"
            icon="el-icon-bottom"
            size="small"
            style="margin: 0 0px 0px 10px;float: none;"
            @click="fileGet()"
          >显示页面内容
          </el-button>
        </div>
        <textarea ref="textarea" />
      </div>
    </div>

    <!-- 结果列表 -->
    <el-table
      v-if="resultList.length > 0"
      ref="multipleTable"
      :data="resultList"
      stripe
      border
      fit
      highlight-current-row
      style="width: 100%;margin-top:20px"
    >

      <el-table-column
        label="序号"
        type="index"
        width="50"
      />

      <el-table-column label="域名">
        <template slot-scope="{row}">
          <span>{{ row.domain }}</span>
        </template>
      </el-table-column>

      <el-table-column label="结果">
        <template slot-scope="{row}">
          <el-tag v-if="row.message == '提交成功'" effect="dark" type="">{{ row.message }}</el-tag>
          <el-tag v-else effect="dark" type="danger">{{ row.message }}</el-tag>
        </template>
      </el-table-column>

    </el-table>

    <!-- <el-alert
      title="以下为实际页面预览"
      type="success"
      :closable="false"
      effect="dark">
    </el-alert>
    <div class="preview" v-html="code"> -->

  </div>
</template>

<script>
// 引入全局实例
import EventBus from '@/utils/eventBus.js'
import _CodeMirror from 'codemirror'
// 核心样式
import 'codemirror/lib/codemirror.css'
// 引入主题后还需要在 options 中指定主题才会生效
import 'codemirror/theme/cobalt.css'
// 需要引入具体的语法高亮库才会有对应的语法高亮效果
// codemirror 官方其实支持通过 /addon/mode/loadmode.js 和 /mode/meta.js 来实现动态加载对应语法高亮库
// 但 vue 貌似没有无法在实例初始化后再动态加载对应 JS ，所以此处才把对应的 JS 提前引入
import 'codemirror/mode/javascript/javascript.js'
import 'codemirror/mode/css/css.js'
import 'codemirror/mode/markdown/markdown.js'
import 'codemirror/mode/vue/vue.js'
import 'codemirror/addon/scroll/simplescrollbars.css'
import 'codemirror/addon/scroll/simplescrollbars'
import {
  readSoftConfig1,
  writeSoftConfig,
  websiteConfig,
  filesGet,
  newFileGet
} from '@/api/website'
// 尝试获取全局实例
const CodeMirror = window.CodeMirror || _CodeMirror
export default {
  name: 'InCoder',
  props: {
    // 外部传入的内容，用于实现双向绑定
    value: String,
    // 外部传入的语法类型
    language: {
      type: String,
      default: null
    },
    pageSelect: {
      type: String,
      default: false
    },
    showUrlInput: {
      type: Boolean,
      default: false
    },
    showPageSelect: {
      type: Boolean,
      default: ''
    },
    row: {
      type: Object,
      default: ''
    },
    serid: {
      type: Number,
      default: null
    },
    currentConfig:{}
  },
  data() {
    return {
      radioFriend: 0,
      showSelect: false,
      domain: '',
      path: '',
      loadingBtn: false,
      contentPage: '',
      pageType: '',
      resultList: [],
      optionsPage: [ // 要修改的文件类型：'404', '500', '502', 'index', 'tkd', 'other'
        {
          value: 'headjs',
          label: '百度统计'
        }, {
          value: 'footjs',
          label: '广告嵌套'
        }, {
          value: '404',
          label: '404页面'
        }, {
          value: '500',
          label: '500页面'
        }, {
          value: '502',
          label: '502页面'
        }, {
          value: 'index',
          label: 'index页面'
        }, {
          value: 'friendlink',
          label: '友情链接'
        }, {
          value: 'other',
          label: '其他页面'
        }
      ],
      // 内部真实的内容
      code: '',
      // 默认的语法类型
      mode: 'html',
      // 编辑器实例
      coder: null,
      // 默认配置
      options: {
        // 缩进格式
        tabSize: 2,
        // 主题，对应主题库 JS 需要提前引入
        theme: 'cobalt',
        // 显示行号
        lineNumbers: true,
        line: true,
        scrollbarStyle: 'overlay'
      }
    }
  },
  watch: {
    row(val) {
      if (val) {
        this.domain = val.domain
        this.radioFriend=val?.config?.friend || 0
        this.fileGet(this.domain)
        if(val.domain && val.domain.indexOf('http')>-1){
          this.path=val.domain
        }else {
          if(val.domain){
            this.path='http://'+val.domain
          }else{
            this.path=''
          }
        }
      }
    }
  },
  mounted() {
    this.radioFriend=this.row?.config?.friend || 0
    // 初始化
    this._initialize()
    if (this.$route.query.ym) {
      this.domain = this.$route.query.ym
    }
    this.pageType = this.pageSelect
    this.domain = this.row.domain
    if(this.domain && this.domain.indexOf('http')>-1){
      this.path=this.domain
    }else {
      if(this.domain){
        this.path='http://'+this.domain
      }else{
        this.path=''
      }
    }
    if(this.pageType==='nginx'){
      if (this.serid && this.domain) {
        this.getCodeData(this.serid, this.domain)
      }
    }else{
      EventBus.$on('orderCK', (order) => {
        // console.log(order)
        if (order) {
          this.domain = order
          if (this.domain && this.pageType != 'other') {
            this.fileGet(this.domain)
          }
        }
      })
      if (this.domain) {
        this.fileGet(this.domain)
      }
    }

  },
  methods: {
    getCodeData(id, domain) {
      const req = {
        server_id: id,
        name: 'clone',
        domain: domain
      }
      const load = this.$loading({
        lock: true,
        text: '加载中',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      });
      readSoftConfig1(req).then(response => {
        if (response.status) {
          const resData = response.data
          const codeArr = []
          for (const key in resData) {
            const obj = {
              pageCode: resData[key],
              filename: key
            }
            codeArr.push(obj)
          }
          this.codeArr = [...codeArr]
          this.code = this.codeArr[0].pageCode
          // 塞值
          this.coder.setValue(this.code)
        } else {
          this.$message({
            type: 'error',
            message: response.message
          })
        }
      }).finally(() => {
        load.close()
      })
    },
    changeFriend() {
      if (this.row.id) {
        debugger
        const req = {
          ...this.currentConfig,
          site_id: this.row.id,
          friend: this.radioFriend,
        }
        websiteConfig(req).then(response => {
          if (response.status) {
            // this.$message({
            //   type: 'success',
            //   message: '成功切换友链'
            // })
            this.$emit('updateCofing',req)
          } else {
            // this.$message({
            //   type: 'error',
            //   message: response.message
            // })
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    },
    onsubmit() { // 查
      if(this.pageType==='nginx'){
        this.onsubmitNgx()
      }else{
        if (!this.pageType) {
          this.loadingBtn = false
          return this.$message.info('请选择页面类型')
        }
        if (this.pageType == 'other' && !this.path) {
          this.loadingBtn = false
          return this.$message.info('请输入要编辑的页面链接地址')
        }
        if (!this.code) {
          this.loadingBtn = false
          return this.$message.info('请输入页面代码内容')
        }

        if (this.path) {
          this.filePost()
        } else {
          let domainArr = []
          this.resultList = []
          domainArr = this.domain.split(/[(\r\n\s)\r\n\s]+/)
          domainArr.forEach((item) => {
            if (item) {
              this.filePost(item)
            }
          })
        }
      }

    },
    onsubmitNgx() { // 查
      if (!this.code) {
        this.loadingBtn = false
        return this.$message.info('请输入代码内容')
      }
      const parmers = {
        server_id: this.serid,
        name: 'nginx',
        filename: this.codeArr[0].filename,
        data: this.code
      }
      writeSoftConfig(parmers).then(res => {
        if (res.status) {
          this.$message({
            type: 'success',
            message: '提交成功！'
          })
        } else {
          this.$message({
            type: 'error',
            message: res.message
          })
        }
        setTimeout(() => {
          this.loadingBtn = false
        }, 1.5 * 1000)
      }).catch(err => {
        console.log(err)
        setTimeout(() => {
          this.loadingBtn = false
        }, 1.5 * 1000)
      })
    },
    fileGet(domain) {
      this.pageType = this.pageSelect
      const query = {}
      query.domain = domain || this.domain
      query.type = this.pageType
      this.pageType === 'other' ? query.path = this.path : query.path = ''
      const load = this.$loading({
        lock: true,
        text: '加载中',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      });
      filesGet(query).then(res => {
        this.code = ''
        this.coder.setValue(this.code)
        	if (res.status) {
          this.code = res.data
          this.coder.setValue(this.code)
        	} else {
        		this.$message({
        			type: 'error',
        			message: res.message
        		})
        	}
      }).catch(err => {
        	console.log(err)
      }).finally(() => {
        load.close()
      })
    },
    filePost(domain) {
      this.loadingBtn = true
      const parmers = {}
      // parmers.content = this.code
      parmers.domain = domain || this.domain
      parmers.type = this.pageType
      parmers.path = this.path // type为：other时生效；要修改的URL
      console.log(this.pageType==='friendlink' && this.row?.id,'this.row?.id')
      if(this.pageType==='friendlink' && this.row?.id){
        this.changeFriend()
      }
      newFileGet(parmers,{content:this.code}).then(res => {
        const obj = {}
        obj.domain = domain
        	if (res.status) {
        		this.$message({
        			type: 'success',
        			message: '提交成功！'
        		})
          this.code = ''
          obj.message = '提交成功'
        	} else {
        		this.$message({
        			type: 'error',
        			message: res.message
        		})
          obj.message = res.message
        	}
        this.resultList.push(obj)
        	setTimeout(() => {
        		this.loadingBtn = false
        	}, 1.5 * 1000)
      }).catch(err => {
        	console.log(err)
        	setTimeout(() => {
        		this.loadingBtn = false
        	}, 1.5 * 1000)
      })
    },
    selectChange(data) {
      const domain = this.domain.split(/[(\r\n\s)\r\n\s]+/)[0]
      if (data && this.domain) {
        this.fileGet(domain)
      }
    },
    domainBlur(e) {
      const domain = e.target.value.split(/[(\r\n\s)\r\n\s]+/)[0]
      if (domain && this.pageType) {
        this.fileGet(domain)
      }
    },
    // 初始化
    _initialize() {
      // 初始化编辑器实例，传入需要被实例化的文本域对象和默认配置
      this.coder = CodeMirror.fromTextArea(this.$refs.textarea, this.options)
      // 编辑器赋值
      this.coder.setValue(this.value || this.code)

      // 支持双向绑定
      this.coder.on('change', (coder) => {
        this.code = coder.getValue()

        if (this.$emit) {
          this.$emit('input', this.code)
        }
      })
      // 尝试从父容器获取语法类型
      if (this.language) {
        // 获取具体的语法类型对象
        const modeObj = this._getLanguage(this.language)

        // 判断父容器传入的语法是否被支持
        if (modeObj) {
          this.mode = modeObj.label
        }
      }
    },
    // 获取当前语法类型
    _getLanguage(language) {
      // 在支持的语法类型列表中寻找传入的语法类型
      return this.modes.find((mode) => {
        // 所有的值都忽略大小写，方便比较
        const currentLanguage = language.toLowerCase()
        const currentLabel = mode.label.toLowerCase()
        const currentValue = mode.value.toLowerCase()
        // 由于真实值可能不规范，例如 java 的真实值是 x-java ，所以讲 value 和 label 同时和传入语法进行比较
        return currentLabel === currentLanguage || currentValue === currentLanguage
      })
    },
    // 更改模式
    changeMode(val) {
      // 修改编辑器的语法配置
      this.coder.setOption('mode', `text/${val}`)
      // 获取修改后的语法
      const label = this._getLanguage(val).label.toLowerCase()
      // 允许父容器通过以下函数监听当前的语法值
      this.$emit('language-change', label)
    }
  }
}
</script>

<style lang="less">
	.in-coder-panel {
		flex-grow: 1;
		display: flex;
		position: relative;

		.CodeMirror {
			flex-grow: 1;
			z-index: 1;
      height: calc(100% - 50px);

			.CodeMirror-code {
				line-height: 19px;
			}
		}

		.code-mode-select {
			position: absolute;
			z-index: 2;
			right: 10px;
			top: 10px;
			max-width: 130px;
		}
	}
</style>

<style scoped lang="scss">
.page-code {
flex: 1;
  height: 100%;
	.editor-container {
		margin-bottom: 30px;
	}

	.tag-title {
		margin-bottom: 5px;
	}

	.select-box {
		margin: 0 0 0;
		display: flex;
		align-items: center;
    .el-button--success {
      margin: 0 0 10px 0;
    }
		.server-select {
			margin-right: 15px;
		}
	}

	.panel-area {
		display: flex;
    margin: 10px 5px;

		.el-textarea {
			width: 300px;
			margin-right: 10px;
		}

		.el-button {
			float: right;
			margin: 5px 10px 0;
		}

		.left {}

		.right,
		.CodeMirror {
			width: 100%;
			border-radius: 5px;
		}
    .right {
      h5 {
          margin: 10px 0;
      }
      .row-second {
        margin: 0 0 10px;
        .el-input--medium {
           margin-left: 0!important;
        }
      }
    }
	}
}
#pane-moban {
  .select-box {
    .el-input--medium {
        margin: 10px 0 0 15px!important;
    }
  }
}
</style>
