<template>
  <div class="set-page">
    <el-tabs tab-position="left" style="height: calc(100vh - 203px);" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="功能大全" name="one">
        <div class="con-pane">
          <div class="form-item flex-form">
            <span>屏蔽PC蜘蛛：</span><el-switch
              v-model="pcSwitch"
              :disabled="isDisabled"
              @change="changeSwitch"
            />
            <el-tooltip  effect="dark" content="开启后，将屏蔽非移动端的百度蜘蛛" placement="right">
              <div style="margin-left: 20px"><i class="el-icon-question" style="color: #409EFF;font-size: 16px;width: auto;" /></div>
            </el-tooltip>
          </div>
         <div class="form-item flex-form">
          <span>蜘蛛视角：</span>
           <el-switch
             v-model="pureSwitch"
             :disabled="isDisabled"
             @change="changePureSwitch"
           />
           <el-tooltip  effect="dark" content="纯净蜘蛛视角：不加载自定义JS、不加载企业名称、蜘蛛访问只能看到克隆站" placement="right">
             <div style="margin-left: 20px"><i class="el-icon-question" style="color: #409EFF;font-size: 16px;width: auto;" /></div>
           </el-tooltip>
         </div>
          <div class="form-item flex-form">
            <span>是否自动更新首页：</span>
            <el-switch
              v-model="isUpdateSwitch"
              :disabled="isDisabled"
              @change="changeLive('switch')"
            />
            <div class="text-r" v-if="isUpdateSwitch">
              <el-input-number size="mini"   controls-position="right"   @change="changeLive('input')" v-model="updateNum"   :min="1" :max="200" label="N天更新一次"></el-input-number>
              <span>天更新一次</span>
<!--              <el-button size="mini" type="success" style="margin-left: 20px">保存</el-button>-->
            </div>

          </div>
          <div class="form-item">
            <span>友链展示：</span>
            <el-radio-group v-model="radioFriend" :disabled="isDisabled" size="small" @change="changeFriend">
              <el-radio :label="0">不显示</el-radio>
              <el-radio :label="1">首页</el-radio>
              <el-radio :label="2">首页和内页全站</el-radio>
            </el-radio-group>
          </div>
        </div>

      </el-tab-pane>
      <el-tab-pane label="Nginx配置" name="two">
        <div class="con-pane" v-if="showTwo">
          <code-page v-if="row" :row="row" :serid="row.ser_id" :domain="row.domain" />
        </div>
      </el-tab-pane>
      <el-tab-pane label="反向代理" name="three">待开发</el-tab-pane>
      <el-tab-pane label="301跳转" name="four">待开发</el-tab-pane>
      <el-tab-pane label="切换程序" name="five">
        <div class="proess-con">
          <el-form :inline="true" :model="languageData" class="demo-form-inline">
            <el-form-item label="">
              <el-radio-group v-model="languageData.language" :disabled="isDisabled">
                <el-radio label="php">Php</el-radio>
                <el-radio label="python">Python</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :disabled="isDisabled" size="small" @click="onSubmitLanguage">切换</el-button>
            </el-form-item>
          </el-form>
          <div class="list-li">
            <p>PHP性能高，如果站点起量，可以考虑切换。但是首次使用需要安装PHP环境</p>
            <p>Python原生自带</p>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="更换域名" name="six">
        <div class="change-con">
          <div class="red-text">当前域名:{{formData.domain}}</div>
          <el-form :inline="true" :model="formData" class="demo-form-inline">
            <el-form-item label="新域名">
              <el-input v-model="formData.new_domain" :disabled="isDisabled" size="small" placeholder="请输入" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" size="small" :disabled="isDisabled" @click="onSubmitDomain">更换</el-button>
            </el-form-item>
          </el-form>
          <div class="list-li">
            <p>1、请确保新域名在当前账户的DNS账户下；</p>
            <p>2、更换域名后，老域名将不能再访问该站点；</p>
            <p>3、如遇到证书申请不成功、自动解析不成功，请手动重试
            </p>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import {
  websiteConfig,
  changeLanguage,
  changeDomain
} from '@/api/website'
import codePage from '@/views/v2/website/code'
export default {
  components: { codePage },
  props: {
    // 外部传入的内容，用于实现双向绑定
    value: String,
    // 外部传入的语法类型
    language: {
      type: String,
      default: null
    },
    pageSelect: {
      type: String,
      default: false
    },
    showUrlInput: {
      type: Boolean,
      default: false
    },
    showPageSelect: {
      type: Boolean,
      default: ''
    },
    row: {
      type: Object,
      default: ''
    },
    currentConfig:{}
  },
  data() {
    return {
      activeName:'one',
      showTwo:false,
      radioFriend: 0,
      pcSwitch: false,
      pureSwitch: false,
      isUpdateSwitch: false,
      updateNum:1,
      languageData: { // 更换程序data
        domain: '',
        language: 'php',
        server_id: null
      },
      formData: { // 更换域名data
        domain: '',
        new_domain: ''
      },
      isDisabled: true,
      rowId:null
}
  },
  watch: {
    row(val) {
      if (val) {
        this.formData.domain = val?.domain
        this.formData.new_domain = val?.domain
        this.languageData.domain = val?.domain
        this.languageData.server_id = val?.ser_id
        this.isDisabled = !val.id
        this.rowId=val.id
        this.init()
      } else {
        this.rowId=null
        this.isDisabled = true
      }
    },
    currentConfig(val){
      console.log(val,'this.config')
    },
    rowId(){
      this.activeName='one'
    }
  },
  mounted() {
    if (this.row) {
      this.formData.domain = this.row?.domain
      this.formData.new_domain = this.row?.domain
      this.languageData.domain = this.row?.domain
      this.languageData.server_id = this.row?.ser_id
      this.isDisabled = !this.row.id
      this.rowId=this.row.id
    } else {
      this.rowId=null
      this.isDisabled = true
    }
    this.init()
    console.log(this.currentConfig,'currentConfig')
  },
  methods: {
    // 初始化值
    init(){
      this.pureSwitch=this.currentConfig?.pure==1? true :false
      this.isUpdateSwitch=this.currentConfig?.live==1? true :false
      this.pcSwitch=this.currentConfig?.nopcbot==1? true :false
      this.radioFriend=this.currentConfig.friend
    },
    handleClick(tab, event){
      console.log(tab,'tab');
      if(tab.name==='two'){
        this.showTwo=true
      }else{
        this.showTwo=false
      }
    },
    changeFriend() {
      if (this.row.id) {
        const req = {
          ...this.currentConfig,
          site_id: this.row.id,
          friend: this.radioFriend,

        }
        websiteConfig(req).then(response => {
          if (response.status) {
            this.$message({
              type: 'success',
              message: '操作成功'
            })
            this.$emit('updateCofing',req)
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    },

    // 百度蜘蛛开启和关闭
    changeSwitch() {
      if (this.row.id) {
        const req = {
          ...this.currentConfig,
          site_id: this.row.id,
          nopcbot: this.pcSwitch ? 1 : 0
        }
        console.log(req,this.pcSwitch,'req')

        websiteConfig(req).then(response => {
          if (response.status) {
            this.$message({
              type: 'success',
              message: this.pcSwitch ? '开启成功!' : '关闭成功!'
            })
             this.$emit('updateCofing',req)
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    },
    changeLive(type){
      let live=0
      if(!this.isUpdateSwitch && type==='switch'){
        live=0
      }
      if(this.isUpdateSwitch && type==='input'){
        live=this.updateNum
      }

      if (this.row.id) {
        const req = {
          ...this.currentConfig,
          site_id: this.row.id,
          live: live,
        }
        websiteConfig(req).then(response => {
          if (!response.status) {
            this.$message({
              type: 'error',
              message: response.message
            })
          }else{
            this.$emit('updateCofing',req)
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    },
    changePureSwitch(){
      if (this.row.id) {
        const req = {
          ...this.currentConfig,
          site_id: this.row.id,
          pure: this.pureSwitch ? 1 : 0,
        }
        websiteConfig(req).then(response => {
          if (response.status) {
            this.$message({
              type: 'success',
              message: this.pureSwitch ? '开启成功!' : '关闭成功!'
            })
            this.$emit('updateCofing',req)
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    },
    // 更换语言
    onSubmitLanguage() {
      if (this.row.id) {
        changeLanguage(this.languageData).then(response => {
          if (response.status) {
            this.$message({
              type: 'success',
              message: '操作成功!'
            })
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    },
    // 切换域名
    onSubmitDomain() {
      if (this.row.id) {
        changeDomain(this.formData).then(response => {
          if (response.status) {
            this.$message({
              type: 'success',
              message: '操作成功!'
            })
            this.formData.domain = this.formData.new_domain
            this.$emit('submitDomain')
          } else {
            this.$message({
              type: 'error',
              message: response.message
            })
          }
        })
      } else {
        this.$message({
          type: 'error',
          message: '请选择一个域名!'
        })
      }
    }
  }
}
</script>

<style  lang="scss" scoped>
  .set-page{
    flex:1;
    overflow: hidden;

      ::v-deep .el-tabs__item{
        background: none !important;
        height: 40px!important;
        line-height: 40px!important;
        margin: 0px!important;
        width: 120px;
        text-align: center;
      }
    ::v-deep  .is-active {
      color: #409EFF;
      background: #fff;
      border-radius: 10px 10px 0 0;
      margin: 0!important;
      &:first-child {
        border-top: 1px solid #bbb!important;
        border-left: 1px solid #bbb!important;
        border-right: 1px solid #bbb !important;
        border-radius: 10px 10px 0 0;
        margin: 0px!important;
      }
    }
    ::v-deep .el-tabs__content{
      flex:1;
      border: none !important;
      padding-left: 40px;
      min-width:600px !important;
      overflow-y: hidden !important;
      /*overflow-x: hidden !important;*/
      .el-tab-pane{
        padding-top: 20px;
        /*display: block !important;*/
      }
    }

  }
  .text{
    font-size: 12px;
    margin-bottom: 30px;
    width: 100%;
  }
  .list-li{
    font-size: 12px;
    color: #333;
  }
  .form-item{
    font-size: 14px;
    margin-bottom: 30px;
    width: 100%;

  }
  .flex-form{
    display: flex;
    align-items:center;
    ::v-deep .i,.text-r{
      margin-left: 20px;
    }

  }
  .change-con,.con-pane,.proess-con{
   flex: 1;
  }
  .con-pane{
    height: calc(100vh - 233px);
    overflow-y: hidden;
  }
  .change-con{
    .red-text{
      font-size: 14px;
      color: #ff4d51;
      font-weight: bold;
      margin-bottom: 30px;
    }
    ::v-deep .el-form-item__content{
      display: inline-block !important;
    }
  }

</style>
