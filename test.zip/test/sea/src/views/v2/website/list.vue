<template>
  <div class="left-part">
    <div class="header">
      <h3><i class="el-icon-tickets" />网站列表</h3>
      <h4 @click="addSsite"><i class="el-icon-plus" />添加站点</h4>
    </div>
    <div v-loading="listLoading" class="left-part-list">

      <div class="filter-box">
        <!-- 分组过滤 -->
        <!-- <group-select v-on:selectGroup="selectGroupFromSon" :showAllOpation="true" /> -->

        <!-- 状态过滤 -->
        域名列表（{{ websiteList.length }}）
        <div v-if="sid || ser_id">
          <!-- 刷新列表 -->
          <span style="cursor: pointer;font-size: 12px;margin-right: 5px;" @click="getList()"> 刷新</span>
          <span style="cursor: pointer;font-size: 12px;margin-right: 5px;" @click="getList('bdqz')"> 权重倒序</span>
          <!--          <span  @click="getList()" style="cursor: pointer;font-size: 12px;margin-right: 5px;"> 排队建站</span>-->
          <headerFilter
            :filter-list="statusList"
            filter-value="id"
            filter-label="name"
            :current-value="statusId"
            @filterChange="filterChangeStatus"
          />
        </div>

        <!-- 域名查询 -->
        <!-- <i class="el-icon-search" @click="showInput = true"></i>
        <el-input
          v-if="showInput"
          v-model="domainInput"
          class="input-search"
          @keyup.enter.native="getList"
          placeholder="请输入一个域名查询">
        </el-input>
        <i class="el-icon-close" @click="showInput = false" v-if="showInput"></i> -->
      </div>

      <!-- 列表 -->
      <div
        v-for="(item, index) in websiteList"
        :key="index"
        class="ym-list"
        :class="{'ym-list-active' : item.id == activeId}"
        @click="leftClick(item)"
        @mouseleave="mouseLeave(item)"
        @contextmenu.prevent.stop="rightClick($event,item)"
      >
        <!--       <div class="ym-btn" v-if="item.showBtn">-->
        <!--          <el-button-->
        <!--            size="mini"-->
        <!--            type="info"-->
        <!--            @click="handleCopy(item.domain,$event)">-->
        <!--            复制-->
        <!--          </el-button>-->
        <!--          &lt;!&ndash; <el-button-->
        <!--            size="mini"-->
        <!--            type="success"-->
        <!--            @click="openUrl(item.domain)">-->
        <!--            打开-->
        <!--          </el-button> &ndash;&gt;-->
        <!--        </div>-->

        <div class="left-baidu">
          <el-tag>
            <div class="bg-white">
              <svg-icon class-name="search-icon" icon-class="ico-bd" />
            </div>
            <div class="bg-blue">
              <span>{{ item.bdqz }}</span>
              <i v-if="item.bdqz > item.old_bdqz" class="el-icon-top" />
              <i v-if="item.bdqz < item.old_bdqz" class="el-icon-bottom" />
<!--              <span v-if="item.bdqz == item.old_bdqz">=</span>-->
            </div>
          </el-tag>
        </div>
        <div v-if="item.domain.length>30" class="name" :class="item.istatus == '5'?'label-red':'label-blue'">
          <el-tooltip class="item" effect="dark" :content="item.domain" placement="top-start">
            <label >{{ item.domain.substring(0,30) }}...</label>
          </el-tooltip>
        </div>
        <div v-else class="name" :class="item.istatus == '5'?'label-red':'label-blue'"><label>{{ item.domain }}</label></div>
        <div class="ym-more-con">
          <div class="ym-more-l">

            <span v-if="item.istatus == '-1'">全部</span>

            <!-- 0 站点处于禁用状态
              此时可以显示【启用】，启用操作，将设置站点状态为【1】@click="openSite(item)" -->
            <div v-if="item.istatus == '0'">
              <el-tag type="info" >站点禁用</el-tag>
            </div>

            <!-- 1 等待建站
            此时显示【开始建站】的操作入口 -->
            <div v-if="item.istatus == '1'">
              <el-tag type="primary">等待建站</el-tag>
            </div>

            <!-- 2 建站中
              此时显示【查询建站进度】和【取消建站】的操作入口 -->
            <div v-if="item.istatus == '2'">
              <el-tag type=""><i class="el-icon-loading"></i> 正在建站</el-tag>
              <!-- <el-button
                type="danger"
                size="mini"
                class="btn-row-2"
                icon="el-icon-document-delete"
                :loading="item.showLoading2"
                @click="cloneCancel(item)">
                取消建站
              </el-button> -->
              <!-- <el-button
              type="info"
              size="mini"
              class="btn-row-2"
              :loading="item.showLoading3"
              @click="cloneStatus(item, 'click')">
              {{ item.showLoading3 ? '更新中....' : '查看状态'}}
              </el-button> -->
            </div>

            <!-- 3 完成建站
              此时不显示任何操作 -->
            <div v-if="item.istatus == '3'">
            <span>
              <!-- 0代表关闭；1代表混合；2代表强制 -->
              <i v-if="item.config.ssl===0 || item.config.ssl==='0'" class="https https-gray">HTTP</i>
              <i v-else-if="item.config.ssl===1 || item.config.ssl==='1'" class="https"><i class="el-icon-lock  https-green" />HTTPS</i>
              <i v-else class="https  https-green"><i class="el-icon-lock" />HTTPS</i>
            </span>
              <!--            <el-tag type="success">完成建站</el-tag>-->
            </div>

            <el-tag v-if="item.istatus == '4'" type="danger">建站失败</el-tag>
            <div v-if="item.istatus === '5'|| item.istatus === 5" >
              <el-tag type="warning">站点异常</el-tag>
            </div>

            <div class="tip-btn">
              <el-tooltip v-if="item.istatus === '0'|| item.istatus === 0" class="item" effect="dark" content="如需建站，请先启用站点" placement="top-start">
                <i class="el-icon-question"  />
              </el-tooltip>
              <el-tooltip v-if="item.istatus === '1'|| item.istatus === 1" class="item" effect="dark" content="如未开始，请重试" placement="top-start">
                <i class="el-icon-question"  />
              </el-tooltip>
              <el-tooltip v-if="item.istatus === '2'|| item.istatus === 2" class="item" effect="dark" content="如1小时内不能结束，请联系技术人员" placement="top-start">
                <i class="el-icon-question"  />
              </el-tooltip>
              <el-tooltip v-if="item.istatus === '4'|| item.istatus === 4" class="item" effect="dark" content="请检查源站是否可访问" placement="top-start">
                <i class="el-icon-question"  />
              </el-tooltip>
              <el-tooltip v-if="item.istatus >3" class="item" effect="dark" :content="'在'+item.error_time+'检测站点发现失败'" placement="top-start">
                <i class="el-icon-question"  />
              </el-tooltip>
            </div>


          </div>
          <div class="ym-more-r">
            <el-button
              size="mini"
              type="primary"
              class="red"
              @click="handleDel(item.id,item.domain)"
            >
              删除
            </el-button>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>
<script>
import {
  websiteSaveone,
  websiteList,
  websiteDelete,
  websiteUpdate,
  tdkList,
  cloneStart,
  cloneStop,
  cloneStatus,
  sslSstatusApply,
  sslOpenApply,
  sslCloseApply
} from '@/api/website'
import EventBus from '@/utils/eventBus.js'
import groupSelect from '@/components/group-select'
import headerFilter from '@/components/headerFilter'
import clip from '@/utils/clipboard'
export default {
  components: {
    groupSelect,
    headerFilter
  },
  props: {
    ser_id: {
      type: Number,
      default: ''
    },
    siteId: {
      type: Number,
      default: ''
    },
  },
  data() {
    return {
      timer: null,
      activeId: null,
      site_id: null,
      action: '', // 删除 delete offline online
      valueGroup: '',
      domainInput: '',
      listLoading: false,
      showInput: false,
      total: 0,
      statusId: '-1', // 所有状态
      statusList: [ // 0:禁用；1等待建站；2建站中；3建站完成；4建站失败
        {
          id: '-1',
          name: '全部状态'
        }, {
          id: '0',
          name: '禁用站点'
        }, {
          id: '1',
          name: '等待建站'
        },
        {
          id: '2',
          name: '建站中'
        }, {
          id: '3',
          name: '建站完成'
        },
        {
          id: '4',
          name: '建站失败'
        }
      ],
      websiteList: [],
      sid: ''
    }
  },
  watch: {
    ser_id(val) {
      console.log('服务器id：',val)
      if (val) {
        this.sid = val
        this.getList()
      }
    }
  },
  mounted() {
    if (this.ser_id) {
      this.getList()
      // this.timer = setInterval(this.getList, 3000)
    }

    EventBus.$on('order', (order, id) => {
      // console.log("order ,id ===",order ,id)
      if (order === 'updateList') {
        this.getList()
      } else if (order === 'updateAddList') {
        this.site_id = id
        this.getList()
      }
    })
    // const _this=this
    // if (_this.websiteList.length > 0) {
    //   _this.getCloneStatusInterval(_this.websiteList)
    // }
    // this.timer = setInterval(() => {
    //   if (_this.websiteList.length > 0) {
    //     _this.getCloneStatusInterval(_this.websiteList)
    //   }
    // }, 3000)
  },
  beforeDestroy() {
    EventBus.$off('row')
    EventBus.$off('order')
  },
  methods: {
    getCloneStatusInterval(arr) {
      const _this = this
      arr.forEach((item, index) => { // 检测是否有正在建站的，有的话开启定时查状态
        if (item.istatus === 1 || item.istatus === '1' || item.istatus === 2 || item.istatus === '2') {
          _this.cloneStatus(item, 'auto')
        }
      })
    },
    addSsite() {
      if (!this.ser_id) {
        return this.$message.info('请在左侧栏先选择要操作的服务器')
      }
      EventBus.$emit('order', 'addsite') // 传递更新列表指令
      this.$emit('row', 'addsite') // 传递更新列表指令
    },
    leftClick(row) { // 点击域名
      if (row) {
        if(this.activeId ===row.id){
          return
        }else{
          this.activeId = row.id
          EventBus.$emit('row', row) // 传递row给配置页
          this.$emit('row', row) // 传递父级页
        }

      }
    },
    rightClick(ev, row) { // 域名右键
      this.$set(row, 'showBtn', true)
    },
    mouseLeave(row) {
      this.$set(row, 'showBtn', false)
    },
    selectGroupFromSon(msg, list) { // 来自公共组件传值
      this.page = 1
      if (list) {
        this.valueGroup = msg.toString() // 数组转字符串
      }
    },
    filterChangeStatus(id) {
      this.statusId = id
      this.page = 1
      this.getList() // 列表刷新的方法
    },
    getList(type,flag,getId) { // 查
      const query = {}
      query.server_ip = ''
      query.group = this.valueGroup // 分组
      query.ser_id = this.sid || this.ser_id
      query.domain = this.domainInput
      query.status = this.statusId // 站点状态：-1：未解析；0未建站；1等待建站；2建站中；3完成建站；4等待删除；5源站访问失败
      query.page = 1
      query.limit = 2000
      query.desc = type || ''
      this.listLoading = true
      this.showInput = false
      websiteList(query).then(response => {
        if (response.status) {
          this.websiteList = response.data.list
          this.total = response.data.total
          this.taskIds = []
          const _this = this
          // this.timer = setInterval(() => {
          //   _this.websiteList.forEach((item, index) => { // 检测是否有正在建站的，有的话开启定时查状态
          //     if(item.istatus === 1 || item.istatus == '1' || item.istatus === 2 || item.istatus == '2') {
          //       _this.cloneStatus(item, 'auto')
          //     }
          //   })
          // }, 3000)
          _this.websiteList.forEach((item, index) => {
            item.config = JSON.parse(item.config)
            // if((item.istatus === 5 || item.istatus == '5') && item.error_time){
            //   item.error_time=parseTime(item.error_time)
            // }

            // if(_this.activeId && item.id == _this.activeId){
            //   EventBus.$emit('row', item) // 传递row给配置页
            //   this.$emit('row', item,'flag') // 传递父级页
            // }
            if(item.id == _this.siteId) {
              this.$emit('getRowData', item); //传递row给配置页
            }
          })

        } else {
          this.$message({
            type: 'error',
            message: res.message
          })
        }
        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 10)
      }).catch(err => {
        console.log(err)
        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 10)
      })
    },
    sslSstatusCheck(row) { // ssl状态 ,未使用
      // console.log('row：',row.id)
      const query = {}
      query.siteid = row.id
      this.$set(row, 'showLoading3', true)
      sslSstatusApply(query).then(response => {
        if (response.status) {
          return row.ssl = true
        } else {
          return row.ssl = false
        }
        this.$set(row, 'showLoading3', false)
      }).catch(err => {
        console.log(err)
      })
    },
    cloneStatus(row, type) { // 克隆任务状态
      const query = {}
      if (!row.id) {
        return false
      }
      query.siteid = row.id
      this.$set(row, 'showLoading3', true)
      cloneStatus(query).then(response => {
        if (response.status) {
          if (response.message === 'FINISHED' || response.message === 'SUCCESS') {
            // this.$alert(`${row.domain} 建站完成`, '任务提示', {
            //   confirmButtonText: '确认'
            // })
            clearInterval(this.timer)// 清除interval定时器
            this.getList()
          } else if (response.message === 'FAILED') {
            // this.$alert(`${row.domain} 建站失败，请重试！`, '提示', {
            //   confirmButtonText: '确认'
            // })
            this.getList()
          } else if (response.message === 'PROCESS' || response.message === 'PROGRESS') {
            let statusStr = ''
            statusStr += '<p>当前状态：<i class="el-icon-loading"></i>' + response.data.message + '</p>' +
                           '<p>克隆进度：' + response.data.cur_deep + '/' + row.deep + '（已完成克隆层级 / 所有层级）</p>' +
                           '<p>开始时间：<i class="el-icon-time"></i>&nbsp;<i style="color: blue;margin: 0 5px;">' + response.data.start_time + '</i></p>' +
                           '<p>当前链接：<el-link type="success" href=' + response.data.cur_url + ' target="_blank">' + response.data.cur_url + '</el-link></p>'
            if (type === 'click') {
              this.$alert(statusStr, {
                dangerouslyUseHTMLString: true
              })
            }
          } else if (response.message === 'PENDING') {
            // this.$alert(`${row.domain} 建站中，请耐心等待！`, '提示', {
            //   confirmButtonText: '确认'
            // })
          }
        } else {
          // this.$alert(`域名：${row.domain} 已建站完成`, '任务提示', {
          //   confirmButtonText: '确认'
          // })
          clearInterval(this.timer)// 清除interval定时器
          this.getList()
        }
        this.$set(row, 'showLoading3', false)
      }).catch(err => {
        console.log(err)
      })
    },
    handleDel(id,domain) {
      const _this = this
      const req = {
        site_id: id,
        action: 'delete'
      }
      let tipMsg='站点数据将全部移除，是否确认删除?'
        tipMsg+="<span style='color:#ff0000'>将会删除"+domain+"域名</span>"

      this.$confirm(tipMsg, '操作确认', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        showClose:false,
          dangerouslyUseHTMLString:true,
          type: 'warning'
      }).then(() => {
        websiteDelete(req).then(response => {
          if (response.status) {
            _this.$message({
              type: 'success',
              message: '操作成功！'
            })
            _this.getList()
          }
        })

      }).catch(() => {
        this.$message({
          type: 'success',
          message: '取消操作'
        });
      });


    },
    handleCopy(text, event) {
      clip(text, event)
    },
    openUrl(path) {
      if (path.substr(0, 7).toLowerCase() != 'http://' && path.substr(0, 8).toLowerCase() != 'https://') {
        path = 'http://' + path
      }
      window.open(path)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~@/styles/box.scss";
i{
  font-style: normal;
}
 .el-dropdown-menu--mini {
   z-index: 9999!important;
 }
 .filter-box {
    margin: 0 -5px 0 -5px;
    padding: 0 5px;
    height: 30px;
    line-height: 30px;
    background-color: #f5f5f5;
 }
.left-part{
 width: 430px;
}
 .left-part-list .el-button-group>.el-button:first-child {
  opacity: 0!important;
  padding: 0;
 }
 .https {
    margin-left: 5px;
    border-radius: 3px;
    padding: 2px 6px;
 }
 .https-green {
    background-color: #f0f9eb;
    border: 1px solid #e1f3d8;
    color: #67c23a;
 }
 .https-gray {
   background-color: #f0f9eb;
   border: 1px solid #e1f3d8;
    color: #333;
 }
.left-baidu{
  height: 20px;
  margin-top: 1px;
  align-items: center;
  justify-content: space-around;
  min-width: 40px;
  margin-right: 10px;
  float: left;
  span,i {
    cursor: pointer;
    height: 20px;
    line-height: 20px;
    font-size: 12px;
  }
  .el-tag {
    margin-top: 0;
    display: flex;
    align-items: center;
    color: #fff;
    padding: 0 !important;
    border-color: #268fff;
    i {
      margin: 0 4px 0 0;
      padding: 0;
      width: 10px;
      text-align: center;
      display: inline-block;
    }
    .bg-white {
      background-color: #fff;
      border-radius: 3px 0 0 3px;
      padding: 0 5px;
      height: 18px;
      .svg-icon {
        font-size: 14px;
      }
    }
    .bg-blue {
      background-color: #268fff;
      border-radius: 0 3px 3px 0;
      padding-left: 2px;
      min-width: 18px;
    }
  }
}
  .name{
    margin-right: 10px;
    float: left;
    width: 38%;

  }
.label-blue{
  label{
    color: #409eff;
    background: #ecf5ff;
    border:1px solid #b3d8ff;
    border-radius: 3px;
    padding: 0px 6px;
    height: 24px;
    line-height: 24px;
    display: inline-block;
    margin-top: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

}
.label-red{
  label{
    color: #f56c6c;
    background: #fef0f0;
    border:1px solid #f56c6c;
    border-radius: 3px;
    padding: 0px 6px;
    height: 24px;
    line-height: 24px;
    display: inline-block;
    margin-top: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

}
  .ym-more-con{
    float: right;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .ym-more-l{
      font-size: 12px;
      color: #c35d5d;
      display: flex;
      align-items: center;
      .el-button--mini, .el-button--mini.is-round {
        padding: 1px 3px !important;
        // background: transparent!important;
        border: none!important;
      }
      span {
        cursor: pointer;
        margin-right: 10px;
        margin-top: 1px;
        display: block;
        i{
          /*height: 20px;*/
          display: inline-block;
          line-height: 15px !important;
          vertical-align: top !important;
        }
        .el-icon-loading{
         width: 12px;
          height: 12px;
          overflow: hidden;
          margin-top: 3px;
          margin-right: -5px;
        }
      }
      .el-tag {
        margin-top: 0px !important;
        height: 20px!important;
        line-height: 20px!important;
        padding: 0 2px !important;
        margin-right: 10px;
      }
      .tip-btn{
        width: 30px;
        ::v-deep .i{
          margin: 0 10px;
        }
      }
    }
    .ym-more-r{
      font-size: 12px;
      color: #c35d5d;

      .el-button--mini, .el-button--mini.is-round {
        padding:3px 5px !important;
        // background: transparent!important;
        border: none!important;
      }
      .red{
        background: #F56C6C!important;
        color: #fff!important;
      }
    }
  }

</style>
