<template>
  <div class="add-con">
  <el-form ref="formAdd" v-loading="loadingRight" :model="formAdd" label-width="115px" class="add-page">

    <el-row :gutter="8" class="el-row-custom-single">
      <el-col v-if="siteType === 'edit'" class="top-tip">
        <template v-if="formAdd.istatus===3||formAdd.istatus==='3'">
          <el-button  class="btn-bottom" size="mini" type="warning" @click="closeSite(formAdd,9)">关站</el-button>
          <el-tooltip class="item" effect="dark" content="关闭站点，访问网址将返回500的HTTP响应码" placement="top-start">
            <div ><i class="el-icon-question"  /></div>
          </el-tooltip>
        </template>
        <template v-if="formAdd.istatus===9||formAdd.istatus==='9'">
          <el-button  class="btn-bottom" size="mini" type="warning" @click="closeSite(formAdd,3)">开站</el-button>
          <el-tooltip class="item" effect="dark" content="关闭站点，访问网址将返回500的HTTP响应码" placement="top-start">
            <div ><i class="el-icon-question"  /></div>
          </el-tooltip>
        </template>

        <el-button v-if="formAdd.istatus===0||formAdd.istatus==='0'" class="btn-bottom" size="mini" type="primary" @click="openSite(formAdd)">启用站点</el-button>
        <el-button v-if="formAdd.istatus===1||formAdd.istatus==='1'||formAdd.istatus===3||formAdd.istatus==='3'||formAdd.istatus===4||formAdd.istatus==='4'||formAdd.istatus==='2'||formAdd.istatus==2" class="btn-bottom" size="mini" type="danger" @click="stopSite(formAdd)">禁用站点</el-button>
        <el-tooltip  v-if="formAdd.istatus===0||formAdd.istatus==='0'||formAdd.istatus===1||formAdd.istatus==='1'||formAdd.istatus===3||formAdd.istatus==='3'||formAdd.istatus===4||formAdd.istatus==='4'||formAdd.istatus==='2'||formAdd.istatus==2" class="item" effect="dark" content="禁用站点后，将删除已克隆的站点文件，可以重新建站" placement="top-start">
          <div ><i class="el-icon-question"  /></div>
        </el-tooltip>
      </el-col>
      <el-col>
        <el-form-item label="网站域名：">
          <div class="el-form-item-two">
            <el-input
              v-model="formAdd.domain"
              wrap="off"
              style="margin-right: 20px;"
              :disabled="noEdit"
              rows="20"
              class="width-half"
              placeholder="请填写根域名,不用带http或https,网址最后不要带 / "
            />
            <el-checkbox v-model="domain_w">www</el-checkbox>
            <el-checkbox v-model="domain_at">@</el-checkbox>
            <el-checkbox v-model="domain_m">m</el-checkbox>
            <el-tooltip
              :open-delay="1000"
              class="item"
              effect="dark"
              content="自定义二级前缀,多个用英文逗号隔开"
              placement="bottom"
              style="margin-left:10px;width: 140px;"
            >
              <el-input
                v-model="domain_more"
                placeholder="自定义"
                style="width: 200px;"
                @change="changeDomainMore"
              />
            </el-tooltip>
            <el-button type="primary" size="small" v-if="siteType === 'edit' && this.site_id" style="margin-left: 10px" @click="dialogDomainVisible = true">更换域名</el-button>
          </div>
        </el-form-item>
      </el-col>

      <el-col>
        <el-form-item label="网站证书：" style="width: 99%;">
          <!-- <el-checkbox
                :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0"
                v-model="onlyHttp"
                border size="mini"
                style="margin:0 10px 0 0;line-height: 20px;">
                只开启HTTP
              </el-checkbox> -->

          <!-- <el-checkbox
                :disabled="true"
                v-model="onlyHttps"
                border size="mini"
                style="margin:0 5px 0 0;line-height: 20px;">
                强制HTTPS
              </el-checkbox> -->
<!--          @change="reOpenApplySsl('open',formAdd)"-->
          <el-radio-group
            v-model="onlyHttps"
            :disabled="!site_id && siteType == 'edit'"
            style="margin:0 15px 0 0;line-height: 30px;height: 18px;"
          >
            <el-radio :label="0">单http</el-radio>
            <el-radio :label="2">单https</el-radio>
            <el-radio :label="1">混合模式</el-radio>
          </el-radio-group>

          <!--          <el-tooltip-->
          <!--            :open-delay="1000"-->
          <!--            effect="dark"-->
          <!--            placement="top"-->
          <!--            style="margin:2px 0 0 0;"-->
          <!--          >-->
          <!--            <i class="el-icon-question" />-->
          <!--            <div slot="content">-->
          <!--              　　 建议选择默认混合模式;<br>-->
          <!--              1、单http指关闭ssl证书，只开启http;<br>-->
          <!--              2、单https指强制开启证书;<br>-->
          <!--              3、混合模式指http和https都能单独打开;<br>-->
          <!--            </div>-->
          <!--          </el-tooltip>-->

          <!--          <el-button-->
          <!--            v-if="siteType == 'edit' && onlyHttps == 0"-->
          <!--            :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0"-->
          <!--            class="btn-row-2"-->
          <!--            type="warning"-->
          <!--            plain-->
          <!--            size="mini"-->
          <!--            icon="el-icon-refresh-right"-->
          <!--            style="margin: 0 5px 0 5px;"-->
          <!--            :loading="loadingRetry"-->
          <!--            @click="reOpenApplySsl('open',formAdd)"-->
          <!--          >-->
          <!--            重试申请-->
          <!--          </el-button>-->

          <div
            v-if="taskMsgSsl != '' && taskId != ''"
            class="el-alert el-alert--info is-light el-alert-msg"
            @click="showmore(taskMsgSsl)"
          >
            <i class="el-icon-loading" />
            <p>{{ taskMsgSsl }}</p>
            <span>更多</span>
          </div>

        </el-form-item>
      </el-col>

      <el-col>
        <el-form-item label="网站配置：" style="width: 99%;">

          <!--          <el-button-->
          <!--            v-if="siteType == 'edit'"-->
          <!--            :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0"-->
          <!--            class="btn-row-2"-->
          <!--            type="danger"-->
          <!--            plain-->
          <!--            size="mini"-->
          <!--            style="margin: 0 5px 0 0;"-->
          <!--            @click="delSite(formAdd)"-->
          <!--          >-->
          <!--            <i class="el-icon-delete" />-->
          <!--            删除站点-->
          <!--          </el-button>-->

          <!--          <el-button-->
          <!--            v-if="formAdd.istatus != '0' && siteType == 'edit'"-->
          <!--            :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0"-->
          <!--            class="btn-row-2"-->
          <!--            type="danger"-->
          <!--            plain-->
          <!--            size="mini"-->
          <!--            style="margin: 0 5px 0 0;"-->
          <!--            @click="stopSite(formAdd)"-->
          <!--          >-->
          <!--            <i class="el-icon-switch-button" />-->
          <!--            禁用站点-->
          <!--          </el-button>-->

          <!--          <el-button-->
          <!--            v-if="formAdd.istatus == '0'"-->
          <!--            :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0"-->
          <!--            class="btn-row-2"-->
          <!--            type="info"-->
          <!--            plain-->
          <!--            size="mini"-->
          <!--            style="margin: 0 5px 0 0;"-->
          <!--            @click="openSite(formAdd)"-->
          <!--          >-->
          <!--            <i class="el-icon-switch-button" />-->
          <!--            启用站点-->
          <!--          </el-button>-->

          <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top">
            <el-checkbox v-model="face_code" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">代码干扰</el-checkbox>
          </el-tooltip>
          <el-checkbox v-model="is_zhuanma" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">TKD转码</el-checkbox>

          <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top">
            <el-checkbox v-model="is_rewrite" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">伪原创</el-checkbox>
          </el-tooltip>
          <el-checkbox v-model="is_title" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">替换文章标题</el-checkbox>
          <el-tooltip :open-delay="1000" class="item" effect="dark" content="修改并替换img标签的alt、title属性为随机关键词" placement="top">
            <el-checkbox v-model="is_img" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">IMG标签修改</el-checkbox>
          </el-tooltip>
          <el-tooltip :open-delay="1000" class="item" effect="dark" content="修改并替换a标签的title属性为随机关键词" placement="top">
            <el-checkbox v-model="is_a" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">A标签修改</el-checkbox>
          </el-tooltip>
          <el-checkbox v-model="is_ua" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">克隆pc</el-checkbox>
          <!--          <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top">-->
          <!--            <el-checkbox v-model="no_js" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">禁用页面JS</el-checkbox>-->
          <!--          </el-tooltip>-->

          <!--          <el-checkbox v-model="is_insert" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" :true-label="1" :false-label="0" border size="mini" style="margin:0 5px 0 0;line-height: 20px;">写入关键词到页面</el-checkbox>-->

        </el-form-item>
      </el-col>

      <el-col v-if="is_img || is_a">
        <el-form-item label="关键词密度：" style="width: 99%;">
          <div style="float: left; display: flex">
           <el-slider :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" v-model="formAdd.config.twnum" :min="0" :max="100" style="width:260px; float: left" />
          </div>
          <div style="float: left; margin-left: 20px; font-size: 14px; font-weight: bold;">
            <span style="margin-right: 20px"> 随机替换A标签的可视文本：</span> <el-switch
              v-model="formAdd.config.tagtxt"
              :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0"
              active-color="#13ce66"
              inactive-color="#ddd"
            />
          </div>
        </el-form-item>
      </el-col>
      <el-col>
        <el-form-item label="解析ip：" style="width: 99%;" class="el-form-item__content_ip">
          <el-input
            v-model="formAdd.dns_ip"
            :disabled="!site_id && siteType == 'edit'"
            wrap="off"
            style="width: 27%;"
            placeholder="输入要解析的ip"
            @blur="ipChangeConfirm(formAdd.dns_ip)"
          />
          <el-tooltip :open-delay="1000" class="item" effect="dark" content="勾上自动解析后程序会自动解析ip,否则需要去cf等平台手动解析" placement="left">
            <el-checkbox v-model="dns_auto" :disabled="!site_id && siteType == 'edit'" style="margin-left: 10px;">自动解析</el-checkbox>
          </el-tooltip>

          <el-button
            class="btn-row-2"
            type="warning"
            plain
            size="mini"
            :loading="loadingBtn1"
            icon="el-icon-refresh-left"
            style="margin: 0 0px 0px 10px;"
            @click="dnsRretry()"
          >
            重试解析
          </el-button>

          <el-button
            class="btn-row-2"
            type="warning"
            plain
            :loading="loadingBtn2"
            size="mini"
            icon="el-icon-circle-check"
            style="margin: 0 0px 0px 10px;"
            @click="dnsCheckIP()"
          >
            校验解析
          </el-button>
          <span v-if="ipListOnline" style="margin-left: 10px;">线上解析ip: {{ ipListOnline }}</span>
        </el-form-item>
      </el-col>

      <el-col>
        <el-form-item label="文件格式：" style="width: 100%;">
<!--          html/php/jsp/asp/aspx。默认是html-->
          <el-radio-group v-model="formAdd.config.ext" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0">
            <el-radio label="html">html</el-radio>
            <el-radio label="php">php</el-radio>
<!--            <el-radio label="jsp">jsp</el-radio>-->
<!--            <el-radio label="asp">asp</el-radio>-->
<!--            <el-radio label="aspx">aspx</el-radio>-->
          </el-radio-group>
<!--          <el-input-->
<!--            v-model="formAdd.config.ext"-->
<!--            class="width-half"-->
<!--            wrap="off"-->
<!--            placeholder="默认静态文件格式:html,可输入php等代码文件格式"-->
<!--          />-->
        </el-form-item>
      </el-col>

      <el-col>
        <el-form-item label="内页TKD替换：" style="width: 100%;">
          <el-checkbox v-model="tkd_tag_dir" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0">目录页</el-checkbox>
          <el-checkbox v-model="tkd_tag_detail" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0">详情页</el-checkbox>
        </el-form-item>
      </el-col>

      <el-col>
        <el-form-item label="克隆网站：">
          <div class="el-form-item-two">
            <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top"  >
              <el-input class="width-half" v-model="formAdd.origin" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" wrap="off" rows="20" placeholder="带上http或https,网址最后不要带 /" style="margin-right: 10px;" />
            </el-tooltip>
            <span style="width: 132px;">
              <el-tooltip :open-delay="1000" class="item" effect="dark" content="克隆内页层级数,默认是2，层级大会耗时" placement="left">
                <i class="el-icon-question" style="color: #409EFF;font-size: 16px;width: auto;" />
              </el-tooltip>
              克隆深度：
            </span>

            <el-select v-model="formAdd.deep" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" placeholder="" style="width: 115px;">
              <el-option label="1" value="1" />
              <el-option label="2" value="2" />
              <el-option label="3" value="3" />
              <el-option label="4" value="4" />
              <el-option label="5" value="5" />
              <el-option label="6" value="6" />
              <el-option label="7" value="7" />
              <el-option label="8" value="8" />
              <el-option label="9" value="9" />
              <el-option label="10" value="10" />
            </el-select>
          </div>
        </el-form-item>
      </el-col>

      <el-col>
        <el-form-item label="企业名称：">
          <div class="el-form-item-two">
            <el-input class="width-half" v-model="formAdd.org_name" :disabled="!site_id && siteType == 'edit'" wrap="off" rows="20" placeholder="填好后需要再后边勾上开启状态" style="margin-right: 10px;" />
            <el-tooltip :open-delay="1000" class="item" effect="dark" content="养站模式:标题=企业名名称" placement="top-start">
              <el-checkbox v-model="qyStatus" :disabled="!site_id && siteType == 'edit'" :true-label="1" :false-label="0">
                养站模式
              </el-checkbox>
            </el-tooltip>
            <!-- <el-tooltip :open-delay="1000" class="item" effect="dark" content="选择后不用填写,直接随机生成企业名名称" placement="top-start"> -->
            <el-button
              class="btn-row-2"
              type="warning"
              plain
              size="mini"
              style="margin: 4px 0px 0px 10px;"
              @click="qyAutochange()"
            >
              <i class="el-icon-refresh" />
              自动企业名称
            </el-button>
            <div class="flex-form">
            <span>蜘蛛视角：</span>
            <el-switch
              v-model="pureSwitch"
              :disabled="!site_id && siteType == 'edit'"
            />
            <el-tooltip  effect="dark" content="纯净蜘蛛视角：不加载自定义JS、不加载企业名称、蜘蛛访问只能看到克隆站" placement="right">
              <div style="margin-left: 20px"><i class="el-icon-question" style="color: #409EFF;font-size: 16px;width: auto;" /></div>
            </el-tooltip>
            </div>
          </div>
        </el-form-item>
      </el-col>

      <el-col :span="12">
        <el-form-item label="首页标题：">
          <el-input v-model="formAdd.idxt" :disabled="!site_id && siteType == 'edit'" type="textarea" :rows="rows" placeholder="" @blur="checkBlur($event,'index')" />
        </el-form-item>
      </el-col>

      <el-col :span="12">
        <el-form-item label="内页标题：">
          <div class="random">
            随机取几个
            <el-input v-model="formAdd.innt_num" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" size="mini" />
          </div>
          <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top">
            <el-input v-model="formAdd.innt" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" type="textarea" :rows="rows" placeholder="可以批量输入,用｜隔开" @blur="checkBlur($event,'inner')" />
          </el-tooltip>
        </el-form-item>
      </el-col>

      <el-col v-show="!tdkSameIndex" :span="12">
        <el-form-item label="首页关键词：">
          <el-input v-model="formAdd.idxk" :disabled="!site_id && siteType == 'edit'" type="textarea" :rows="rows" placeholder="" />
        </el-form-item>
      </el-col>

      <el-col v-show="!tdkSameInner" :span="12">
        <el-form-item label="内页关键词：">
          <div class="random">
            随机取几个
            <el-input v-model="formAdd.innk_num" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" size="mini" />
          </div>
          <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top">
            <el-input v-model="formAdd.innk" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" type="textarea" :rows="rows" placeholder="可以批量输入,用｜隔开" />
          </el-tooltip>
        </el-form-item>
      </el-col>

      <el-col v-show="!tdkSameIndex" :span="12">
        <el-form-item label="首页描述：">
          <el-input v-model="formAdd.idxd" :disabled="!site_id && siteType == 'edit'" type="textarea" :rows="rows" placeholder="" />
        </el-form-item>
      </el-col>

      <el-col v-show="!tdkSameInner" :span="12">
        <el-form-item label="内页描述：">
          <div class="random">
            随机取几个
            <el-input v-model="formAdd.innd_num" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" size="mini" />
          </div>
          <el-tooltip :open-delay="1000" class="item" effect="dark" content="若更改此项,需要重新克隆网站,慎重选择" placement="top">
            <el-input v-model="formAdd.innd" :disabled="(!site_id && siteType == 'edit') || currentIstatus!=0" type="textarea" :rows="rows" placeholder="可以批量输入,用｜隔开" />
          </el-tooltip>
        </el-form-item>
      </el-col>

      <el-col>
        <el-button
          :class="siteType == 'edit' ? 'btn-save-edit' : 'btn-save-add'"
          class="btn-save"
          type="success"
          icon="el-icon-circle-check"
          :loading="loadingBtn3"
          size="mini"
          @click="startCreate"
        >
          {{ title || '开始建站' }}
        </el-button>

      </el-col>

    </el-row>

  </el-form>
    <changeDomain :row="rowData" v-if="dialogDomainVisible" @closeDialog="closeDialog"/>
    <el-dialog
      title="提示成功"
      :visible.sync="showLineMsg"
      width="800px"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      class="show-msg-dia"
    >
      <el-timeline-item
        v-for="(item, index) in showMsgList"
        :key="index"
        icon="el-icon-check"
        color="#0bbd87"
        size="small"
        :timestamp="item.title">
        {{item.content}}
      </el-timeline-item>
      <span slot="footer" class="dialog-footer">
    <el-button type="primary" @click="showLineMsg = false">确 认</el-button>
  </span>
    </el-dialog>
  </div>
</template>

<script>
import { Loading } from 'element-ui'
import EventBus from '@/utils/eventBus.js'
import { parseTime, formatTime } from '@/utils/index'
import groupSelect from '@/components/group-select'
import changeDomain from './changeDomain'
import QY from '@/utils/qiyeName'
import {
  websiteSaveAll,
  websiteList,
  websiteDelete,
  websiteUpdate,
  tdkList,
  tkdUpdate,
  cloneStart,
  cloneStop,
  sslSstatusApply,
  sslOpenApply,
  sslCloseApply,
  sslSstatusProcess,
  cloneStatus,
  updateDns,
  updateSiteStatus
} from '@/api/website'

import {
  dnsQuery
} from '@/api/dns'
import clip from '@/utils/clipboard'

export default {
  components: {
    groupSelect,changeDomain
  },
  filters: {
    parseTime(value) {
      return formatTime(value, '{y}-{m}-{d}')
    }
  },
  props: {
    order: String,
    sid: Number,
    valueServer: String,
    title: String,
    siteType: String,
    rowData: Object
  },
  data() {
    return {
      dialogDomainVisible:false,
      showLineMsg:false,
      showMsgList:[],
      pureSwitch: true,
      currentIstatus:0,
      timer: null,
      clonetimer: null,
      ipListOnline: '',
      taskId: '',
      taskMsgSsl: '',
      tkdData: {},
      noEdit: true,
      flag: true,
      site_id: null,
      rows: 4,
      dns_auto: true,
      dnsauto: 0,
      tkd_tag: 0,
      tkd_tag_dir: false,
      tkd_tag_detail: false,
      face_code: 1,
      is_zhuanma: 1,
      is_insert: 1,
      is_rewrite: 1,
      is_ua: 1,
      is_title: 1,
      no_js: 1,
      forceHttps: 1,
      onlyHttp: false,
      allSsl: false,
      onlyHttps: 1, // "ssl": 0, # SSL状态：只HTTP、只HTTPS、混合 传值分别是0,2,1
      domain_w: true,
      domain_at: true,
      domain_m: true,
      domain_more: '',
      alias: 'www,@,m',
      innt_num_row: 3,
      innk_num_row: 3,
      innd_num_row: 3,
      qyStatus: 0,
      qyAutoStatus: false,
      loading: false,
      loadingRetry: false,
      loadingBtn: false,
      loadingRight: false,
      loadingBtn3: false,
      loadingBtn1: false,
      loadingBtn2: false,
      tdkSameIndex: false,
      tdkSameInner: false,
      dynamicTags: [],
      valueGroup: '',
      aliasArr: [],
      aliasArr2: [],
      row: {},
      formRow: {},
      is_a: false,
      is_img: false,
      formAdd: {
        dns_ip: '',
        server: '',
        ser_id: '',
        deep: 3,
        domain: '',
        group: '',
        origin: '',
        org_name: '',
        qiyeStatus: 0, // 0关闭
        idxt: '',
        idxd: '',
        idxk: '',
        innt: '',
        innd: '',
        innk: '',
        innt_num: 3,
        innk_num: 3,
        innd_num: 3,
        websiteStatus: '',
        config: {
          twnum: 0, // 密度
          tagtxt: false, // 随机替换A标签的可视文本
          ssl: 0, // SSL状态：0未开启；1开启并共存；2强制
          js_title: 1,
          ascii: 1, // TKD是否转码：config.ascii=1或者0
          insert: 1, // 是否写入关键词到页面（保留原标题），将会查找以下标签：<h1><h2><h3><strong>进行插入关键词。插入的词为当前页面TKD里面配置的词
          pure:0,
          is_rewrite: 0, // 是否伪原创
          is_ua:0,
          h1:0,//替换文章标题
          to_cn: 1, // 是否翻译成中文（目前只有繁体转中文）
          face_code: 1, // 是否开启干扰码
          no_js: 1, // 是否禁用页面JS
          tkd_mode: 'monster', // TKD模式：simple 简单模式；mixed 混合模式，此时支持tkd_tag配置保留源页面的TKD; monster 怪异模式，此时传给接口的TKD配置是数字，内容会存储到文本
          ext: 'html', // 自定义伪静态文件格式 默认值是html，config字段传：ext，值：php
          tkd_tag: '' // config字段名称：tkd_tag，多个值用英文逗号分隔。目录页，值：dir；详情页，值：detail
        }
      }
    }
  },
  watch: {
    valueServer(val) {
      if (val) {
        this.formAdd.server = val
      }
    },
    rowData(val){
      this.currentIstatus=val.istatus
      console.log(this.currentIstatus,'this.currentIstatus');
    }
  },
  beforeDestroy() {
    clearInterval(this.timer)
    clearInterval(this.clonetimer)
  },
  mounted() {
    // 再次进入时更新编辑面板数据
    if (this.siteType === 'edit' && this.rowData.id) {
      this.getTDK(this.rowData, this.rowData.id)
      this.currentIstatus=this.rowData.istatus
    }
    this.siteType === 'edit' ? this.noEdit = true : this.noEdit = false
    if (this.sid) {
      this.formAdd.server = this.valueServer
    }
    // const _this = this
    // this.timer = setInterval(function() {
    //   _this.sslSstatusProcessCheck()
    // }, 2000)
    EventBus.$on('row', (row) => {
      // console.log("add row",row.id)
      this.row = row
      this.site_id = row.id
      this.ipListOnline = ''
      this.getTDK(row, row.id)
      sessionStorage.setItem('currentRow', JSON.stringify(this.row))
      // 判断是否执行查看ssl状态
      const localSid = JSON.parse(localStorage.getItem(`sId_${row.id}`))
      // 定时获取ssl状态
      this.taskId = ''
      this.taskMsgSsl = ''
      if (localSid && localSid.sid === this.site_id) {
        this.taskId = localSid.tid
      } else {
        this.taskId = ''
        this.taskMsgSsl = ''
      }
    })
    document.body.clientWidth > 1680 ? this.rows = 6 : this.rows = 4
  },
  methods: {
    // no_change(e) {
    //   const reg = /[^a-z]/g
    //   console.log(reg.test(e),e ,'reg.test(this.formAdd.config.ext)')
    //   this.$nextTick(() => {
    //     if (reg.test(e)) {
    //       console.log(1111)
    //       this.$message.error('文件格式只允许小写')
    //     }
    //   })
    // },
    closeDialog(domain){
      this.dialogDomainVisible=false
      if(domain){
        this.$emit('submitDomain',domain)
      }
    },
    changeDomainMore() {
      console.log(this.domain_more)
    },
    getRandomName() {
      const citeNames = ['北京市','石家庄市','唐山市','秦皇岛市','邯郸市','邢台市','保定市','张家口市','承德市','沧州市','廊坊市','衡水市','太原市','大同市','阳泉市','长治市','晋城市','朔州市','晋中市','运城市','忻州市','临汾市','吕梁市','呼和浩特市','包头市','乌海市','赤峰市','通辽市','鄂尔多斯市','呼伦贝尔市','巴彦淖尔市','乌兰察布市','兴安盟','锡林郭勒盟','阿拉善盟','沈阳市','大连市','鞍山市','抚顺市','本溪市','丹东市','锦州市','营口市','阜新市','辽阳市','盘锦市','盘锦市','朝阳市','葫芦岛市','长春市','吉林市','四平市','辽源市','通化市','白山市','松原市','白城市','延边','哈尔滨市','齐齐哈尔市','鸡西市','鹤岗市','双鸭山市','大庆市','伊春市','佳木斯市','七台河市','牡丹江市','黑河市','绥化市','大兴安岭地区','上海市','南京市','无锡市','徐州市','常州市','苏州市','南通市','连云港市','淮安市','盐城市','扬州市','镇江市','泰州市','宿迁市','杭州市','宁波市','温州市','嘉兴市','湖州市','绍兴市','金华市','衢州市','舟山市','台州市','丽水市','合肥市','芜湖市','蚌埠市','淮南市','马鞍山市','淮北市','铜陵市','安庆市','黄山市','滁州市','阜阳市','宿州市','六安市','亳州市','池州市','宣城市','福州市','厦门市','莆田市','三明市','泉州市','漳州市','南平市','龙岩市','宁德市','南昌市','景德镇市','萍乡市','九江市','新余市','鹰潭市','赣州市','吉安市','宜春市','抚州市','上饶市','山东省','济南市','青岛市','淄博市','枣庄市','东营市','烟台市','潍坊市','济宁市','泰安市','威海市','日照市','莱芜市','临沂市','德州市','聊城市','滨州市','菏泽市','河南省','郑州市','开封市','洛阳市','平顶山市','安阳市','鹤壁市','新乡市','焦作市','济源市','濮阳市','许昌市','漯河市','三门峡市','南阳市','商丘市','信阳市','周口市','驻马店市','湖北省','武汉市','黄石市','十堰市','宜昌市','襄阳市','鄂州市','荆门市','孝感市','荆州市','黄冈市','咸宁市','随州市','恩施','仙桃市','潜江市','天门市','神农架林区','湖南省','长沙市','株洲市','湘潭市','衡阳市','邵阳市','岳阳市','常德市','张家界市','益阳市','郴州市','永州市','怀化市','娄底市','湘西','广东省','广州市','韶关市','深圳市','珠海市','汕头市','佛山市','江门市','湛江市','茂名市','肇庆市','惠州市','梅州市','汕尾市','河源市','阳江市','清远市','东莞市','中山市','东沙群岛','潮州市','揭阳市','云浮市','广西壮族自治区','南宁市','柳州市','桂林市','梧州市','北海市','防城港市','钦州市','贵港市','玉林市','百色市','贺州市','河池市','来宾市','崇左市','海南省','海口市','三亚市','三沙市','五指山市','琼海市','儋州市','文昌市','万宁市','东方市','定安县','屯昌县','澄迈县','临高县','白沙','昌江','乐东','陵水','保亭','琼中','重庆','重庆市','四川省','成都市','自贡市','攀枝花市','泸州市','德阳市','绵阳市','广元市','遂宁市','内江市','乐山市','南充市','眉山市','宜宾市','广安市','达州市','雅安市','巴中市','资阳市','阿坝','甘孜','凉山','贵州省','贵阳市','六盘水市','遵义市','安顺市','铜仁市','黔西南','毕节市','黔东南','黔南','云南省','昆明市','曲靖市','玉溪市','保山市','昭通市','丽江市','普洱市','临沧市','楚雄','红河','文山','西双版纳','大理','德宏','怒江','迪庆','西藏自治区','拉萨市','昌都地区','山南地区','日喀则地区','那曲地区','阿里地区','林芝地区','陕西省','西安市','铜川市','宝鸡市','咸阳市','渭南市','延安市','汉中市','榆林市','安康市','商洛市','甘肃省','兰州市','嘉峪关市','金昌市','白银市','天水市','武威市','张掖市','平凉市','酒泉市','庆阳市','定西市','陇南市','临夏','甘南','青海省','西宁市','海东市','海北','黄南','海南','果洛','玉树','海西','宁夏回族自治区','银川市','石嘴山市','吴忠市','固原市','中卫市','新疆维吾尔自治区','乌鲁木齐市','克拉玛依市','吐鲁番地区','哈密地区','昌吉','博尔塔拉','巴音郭楞','阿克苏地区','克孜勒苏柯尔克孜自治州','喀什地区','和田地区','伊犁','塔城地区','阿勒泰地区','石河子市','阿拉尔市','图木舒克市','五家渠市','台湾','台北市','高雄市','台南市','台中市','金门县','南投县','基隆市','新竹市','嘉义市','新北市','宜兰县','新竹县','桃园县','苗栗县','彰化县','嘉义县','云林县','屏东县','台东县','花莲县','澎湖县','连江县','香港特别行政区','香港岛','香港岛','新界','澳门特别行政区','澳门','离岛'
      ]
      const familyNames = ['益辰', '益帆', '冰枫', '春齐', '建政', '润莎', '佳毅',
        '浙江', '亿丰', '环宇', '通达', '腾云', '美林', '迟暮', '抑风', '清运', '青云', '国贤', '贺祥', '晨涛',
        '昊轩', '易轩', '益辰', '益帆', '益冉', '瑾春', '瑾昆', '春齐', '文昊',
        '东东', '雄霖', '浩晨', '熙涵', '冰枫', '欣欣', '宜豪', '欣慧', '建政',
        '美欣', '淑慧', '文轩', '文杰', '欣源', '忠林', '榕润', '欣汝', '慧嘉',
        '建林', '亦菲', '冰洁', '佳欣', '禹辰', '淳美', '泽惠', '伟洋',
        '涵越', '润丽', '淑华', '晶莹', '凌晶', '苒溪', '雨涵', '嘉怡', '佳毅',
        '佳琪', '紫轩', '瑞辰', '昕蕊', '明远', '欣宜', '泽远', '欣怡',
        '佳怡', '佳惠', '晨茜', '晨璐', '运昊', '汝鑫', '淑君', '晶滢', '润莎', '榕汕',
        '佳钰', '佳玉', '晓庆', '一鸣', '语晨', '添池', '添昊', '雨泽', '雅晗', '雅涵',
        '清妍', '诗悦', '嘉乐', '晨涵', '天赫', '佳昊', '天昊', '若萌']
      const givenNames = ['有限公司', '国电有限公司', '电气有限公司', '科技有限公司', '医药公司', '科技公司', '_科技公司', '_网络公司', '_网络有限公司', '网络公司']
      const c = parseInt(Math.random() * 100 + 0)
      const citeName = citeNames[c]
      const i = parseInt(Math.random() * 100 + 0)
      const familyName = familyNames[i]
      const j = parseInt(Math.random() * 10 + 0)
      const givenName = givenNames[j]

      const name =citeName + familyName + givenName
      return name
      // const random = Math.floor(Math.random() * (99 - 1)) + 1
      // return QY.qiyeName[random]
    },
    selectGroupFromSon(msg, list) { // 来自公共组件传值
      _this.page = 1
      if (_this.dialogGroupEdit) { // 仅适用于分组编辑弹窗
        if (this.dynamicTags.indexOf(msg[msg.length - 1]) > -1) {
          return this.$message.info('已存在，无须重复添加')
        } else {
          this.dynamicTags.push(msg[msg.length - 1])
        }
        this.dynamicTags.forEach((item, index) => {
          if (!item) {
            this.dynamicTags.splice(index, 1)
          }
        })
      }
      if (list) {
        this.valueGroup = msg
        this.formAdd.group = msg.toString() // 数组转字符串
      }
    },
    showmore(msg) {
      this.$alert(msg, '进度详情', {
        confirmButtonText: '确定'
      })
    },
    unique(arr) {
      return Array.from(new Set(arr))
    },
    startCreate() {
      if (this.formAdd.config.ext) {
        const reg = /[^a-z]/g
        const e = this.formAdd.config.ext
        if (reg.test(e)) {
          this.$message.error('文件格式只允许小写')
        }
      }
      // 二级别名处理
      if (this.domain_w) {
        this.aliasArr.push('www')
      } else {
        for (let i = 0; i < this.aliasArr.length - 1; i++) {
          if (this.aliasArr[i] == 'www') {
            this.aliasArr.splice(i, 1)
          }
        }
      }
      if (this.domain_at) {
        this.aliasArr.push('@')
      } else {
        for (let i = 0; i < this.aliasArr.length - 1; i++) {
          if (this.aliasArr[i] == '@') {
            this.aliasArr.splice(i, 1)
          }
        }
      }
      if (this.domain_m) {
        this.aliasArr.push('m')
      } else {
        for (let i = 0; i < this.aliasArr.length - 1; i++) {
          if (this.aliasArr[i] == 'm') {
            this.aliasArr.splice(i, 1)
          }
        }
      }
      if (this.domain_more) {
        this.domain_more = this.domain_more.replace('，', ',')
        this.aliasArr2 = this.domain_more.split(',')
      } else {
        this.domain_more = ''
        this.aliasArr2 = []
      }
      this.aliasArr = this.aliasArr.concat(this.aliasArr2)
      this.aliasArr = this.unique(this.aliasArr)
      this.alias = this.aliasArr.join(',')
      if (!this.formAdd.server) {
        return this.$message.info('请选择要操作的服务器')
      } else if (!this.formAdd.domain) {
        let title = ''
        this.siteType === 'edit' ? title = '请先在网站列表里选择一个域名' : title = '网站域名不能为空'
        return this.$message.info(title)
      } else if (!this.formAdd.origin) {
        return this.$message.info('克隆网站不能为空')
      } else if (!this.formAdd.dns_ip) {
        return this.$message.info('解析ip不能为空')
      } else if (!this.formAdd.idxt) {
        return this.$message.info('首页标题不能为空')
      }

      let domainArr = this.formAdd.domain
      let originArr = this.formAdd.origin
      const idxtArr = this.formAdd.idxt
      const idxdArr = this.formAdd.idxd
      const idxkArr = this.formAdd.idxk
      const inntArr = this.formAdd.innt
      const inndArr = this.formAdd.innd
      const innkArr = this.formAdd.innk
      const org_nameArr = this.formAdd.org_name || '无'

      if (!this.formAdd.innt) {
        this.formAdd.innt_num = 0
      } else if (!this.formAdd.innk) {
        this.formAdd.innk_num = 0
      } else if (!this.formAdd.innd) {
        this.formAdd.innd_num = 0
      }

      this.newArr = []
      const tempObj = {}
      /**
         * 域名格式处理
         */
      // cloneurl 去掉最后一位 /
      originArr = originArr.replace(/([\w\W]+)\/$/, '$1') // 去掉最后 /
      domainArr = domainArr.replace(/([\w\W]+)\/$/, '$1') // 去掉最后 /

      // 检测 cloneurl 如果未带https或http就自动补上
      if (originArr.substr(0, 7).toLowerCase() == 'http://' || originArr.substr(0, 8).toLowerCase() == 'https://') {
        originArr = originArr
      } else {
        originArr = 'http://' + originArr
      }
      // 检测 domain 如果未带https或http就自动补上
      if (domainArr.substr(0, 7).toLowerCase() == 'http://') {
        domainArr = domainArr.split('http://')[1]
      } else if (domainArr.substr(0, 8).toLowerCase() == 'https://') {
        domainArr = domainArr.split('https://')[1]
      }

      tempObj.domain = domainArr
      tempObj.origin = originArr
      tempObj.idxt = idxtArr
      tempObj.idxd = idxdArr
      tempObj.idxk = idxkArr
      tempObj.innt = inntArr
      tempObj.innd = inndArr
      tempObj.innk = innkArr
      tempObj.innt_num = this.formAdd.innt_num
      tempObj.innk_num = this.formAdd.innk_num
      tempObj.innd_num = this.formAdd.innd_num
      tempObj.org_name = org_nameArr || '无'
      tempObj.server = this.formAdd.server
      tempObj.ser_id = this.formAdd.server
      tempObj.group = this.formAdd.group
      tempObj.qiyeStatus = this.formAdd.qiyeStatus
      tempObj.websiteStatus = this.formAdd.websiteStatus
      tempObj.deep = this.formAdd.deep
      tempObj.alias = this.alias
      tempObj.dns_ip = this.formAdd.dns_ip

      // 内页TKD替换 单选框处理成字符串格式
      const tdkTagArr = []
      if (this.tkd_tag_detail) {
        tdkTagArr.push('detail')
      }
      if (this.tkd_tag_dir) {
        tdkTagArr.push('dir')
      }
      if (tdkTagArr.length > 0) {
        this.formAdd.config.tkd_tag = tdkTagArr.join(',')
      }

      // 新加参数 config
      tempObj.config = {}
      tempObj.config.js_title = this.qyStatus, // 养站模式
      tempObj.config.ssl =this.siteType == 'edit'? this.onlyHttps :0, // SSL状态：0未开启；1开启并共存；2强制
      tempObj.config.is_rewrite = this.is_rewrite, // 是否伪原创
      tempObj.config.ua = this.is_ua, // 克隆pc
      tempObj.config.h1 = this.is_title, // 替换文章标题
      tempObj.config.ascii = this.is_zhuanma, // 是否转码
      tempObj.config.insert = this.is_insert, // 是否插入到内页
      tempObj.config.face_code = this.face_code, // 是否开启干扰码
      tempObj.config.ext = this.formAdd.config.ext || 'html', // 自定义伪静态文件格式 默认值是html，config字段传：ext，值：php
      tempObj.config.tkd_tag = this.formAdd.config.tkd_tag, // config字段名称：tkd_tag，多个值用英文逗号分隔。目录页，值：dir；详情页，值：detail
      tempObj.config.to_cn = 1, // 是否翻译成中文（目前只有繁体转中文）
      tempObj.config.no_js = this.no_js, // 是否禁用页面JS
      tempObj.config.tkd_mode = 'monster', // TKD模式：simple 简单模式；mixed 混合模式，此时支持tkd_tag配置保留源页面的TKD; monster 怪异模式，此时传给接口的TKD配置是数字，内容会存储到文本
      // tempObj.config.tkd_tag = '' // 要保留的源页面TKD "title,keywords,description"
      // tempObj.ext = this.formAdd.ext
      tempObj.config.pure = this.pureSwitch ? 1 : 0
      this.newArr.push(tempObj)

      this.loadingBtn3 = true
      this.newArr.forEach((item) => {
        this.submitCreate(item)
      })
    },
    submitCreate(item) { // 增
      // Loading.service()

      // 转码
      if (this.zhuanma) {
        item.idxt = this.ascii(item.idxt)
        item.idxd = this.ascii(item.idxd)
        item.idxk = this.ascii(item.idxk)
        item.innt = this.ascii(item.innt)
        item.innd = this.ascii(item.innd)
        item.innk = this.ascii(item.innk)
      }

      // 自动解析值转换
      let auto = 0
      this.dns_auto === true ? auto = 1 : auto = 0

      // 添加时site_id设置为0
      const parmers = {}
      this.siteType == 'edit' ? this.site_id = this.site_id : this.site_id = 0

      parmers.site_id = this.site_id
      parmers.ser_id = this.sid
      parmers.server = item.server
      parmers.group = '默认'
      parmers.org_name = item.org_name
      parmers.qiyeStatus = item.qiyeStatus
      parmers.dnsauto = auto

      parmers.idxt = item.idxt
      parmers.idxd = item.idxd
      parmers.idxk = item.idxk
      parmers.innt = item.innt
      parmers.innd = item.innd
      parmers.innk = item.innk
      parmers.innt_num = item.innt_num
      parmers.innk_num = item.innk_num
      parmers.innd_num = item.innd_num
      parmers.origin = item.origin
      parmers.deep = item.deep
      parmers.domain = item.domain
      parmers.alias = item.alias, // 别名
      parmers.dns_ip = item.dns_ip
      parmers.config = item.config
      let addConfig={}
      const tagword = []
      if (this.is_a || this.is_img) {
        if (this.is_a) {
          tagword.push('a')
        }
        if (this.is_img) {
          tagword.push('img')
        }
        addConfig.twnum = this.formAdd.config.twnum
        addConfig.tagtxt = this.formAdd.config.tagtxt ? 1 : 0
      } else {
        addConfig.twnum = 0
        addConfig.tagtxt = 0
      }
      addConfig.tagword = tagword.length > 0 ? tagword.toString() : ''
      parmers.config={
        ...parmers.config,
        ...addConfig
      }
      websiteSaveAll(parmers).then(res => {
        if (res.status) {
          // clone: 站点 xxx 已推送克隆
          // siteconf: 站点配置已通知客户机更新
          // dns: DNS 任务提交成功
          // ssl: 证书配置已推送
          // ssl_apply: 证书申请任务已提交
          const clone = res?.data?.clone
          const siteconf = res?.data?.siteconf
          const dns = res?.data?.dns
          const ssl = res?.data?.ssl
          const ssl_apply = res?.data?.ssl_apply
          let  messageList=[]
          if(clone){
            messageList.push({
              title:'站点'+ this.formAdd.domain +'已推送克隆',
              content:clone?.data
            })
          }
          debugger
          if(siteconf){
            messageList.push({
              title:'站点配置已通知客户机更新',
              content:siteconf?.data
            })

          }
          if(dns){
            messageList.push({
              title:'DNS任务提交成功',
              content:dns?.data
            })
          }
          if(ssl){
            messageList.push({
              title:'证书配置已推送',
              content:ssl?.data
            })
          }
          if(ssl_apply){
            messageList.push({
              title:'证书申请任务已提交',
              content:ssl_apply?.data
            })
          }
          this.showMsgList=[...messageList]
          this.showLineMsg=true

          // console.log(messageHtml,'messageHtml')
          // this.$alert(messageHtml, '提交成功', {
          //   type: 'success',
          //   confirmButtonText: '确认',
          //   dangerouslyUseHTMLString: true,
          // })

          if(this.siteType !== 'edit'){
            //新增的时候
            this.$emit('clsoeDialog')
          }
          this.getList()
          if (res.data.site_id) {
            this.site_id = res.data.site_id

            // console.log(this.currentIstatus,this.siteType,this.siteType !== 'edit' ,'this.currentIstatus ')
            //
            // if (this.currentIstatus === 1 || this.currentIstatus === '1' || this.siteType !== 'edit' ) {
            //   this.submitCloneTask()
            // }
            if (this.currentIstatus === 2 || this.currentIstatus === '2' || this.siteType !== 'edit') {
              const _this = this
              this.clonetimer = setInterval(() => {
                _this.getCloneStatusInterval(this.rowData)
              }, 3000)
            }
          }
          this.$emit('sonOrder', 'close') // 告诉父组建关窗口
          EventBus.$emit('startClone', this.formAdd) // 告诉兄弟config 开始克隆建站
          this.formAdd.group = ''
          this.valueServer == 0
          this.valueGroup == '不限'
          this.loadingBtn3 = false
        } else {
          this.$alert(res.message, '失败提示', {
            confirmButtonText: '确认',
            type: 'error'
          })
        }
        this.loadingBtn3 = false
        this.loadingClose()
      }).catch(err => {
        this.loadingBtn3 = false
        console.log(err)
      })
    },
    getTDK(row, siteid) { // 查
      // 拆分二级别名
      const moreArr = []
      this.domain_w = false
      this.domain_at = false
      this.domain_m = false
      this.tkd_tag_dir = false
      this.tkd_tag_detail = false
      this.domain_more = ''

      // 网站证书
      if (typeof (row.config) === 'string') {
        row.config = JSON.parse(row.config)
      }
      if (row.config.tkd_tag) {
        let tempArr = []
        tempArr = row.config.tkd_tag.split(',')
        tempArr.indexOf('detail') > -1 ? this.tkd_tag_detail = true : this.tkd_tag_detail = false
        tempArr.indexOf('dir') > -1 ? this.tkd_tag_dir = true : this.tkd_tag_dir = false
      }
      this.onlyHttp = row.config.ssl
      this.onlyHttps = row.config.ssl
      this.face_code = row.config.face_code
      this.is_rewrite = row.config.is_rewrite
      this.is_ua = row.config.ua
      this.pureSwitch=row.config?.pure==1? true :false
      this.is_title = row.config.h1
      this.is_insert = row.config.insert
      this.is_zhuanma = row.config.ascii
      if (row.config?.tagword) {
        this.formAdd.config.twnum = row.config.twnum || 0
        const tagtxt = row?.config?.tagtxt === 1 || row?.config?.tagtxt === '1'
        this.formAdd.tagtxt = tagtxt || false
        if (row?.config?.tagword && row?.config?.tagword.indexOf('a') > -1) {
          this.is_a = true
        } else {
          this.is_a = false
        }
        if (row?.config?.tagword && row?.config?.tagword.indexOf('img') > -1) {
          this.is_img = true
        } else {
          this.is_img = false
        }
      } else {
        this.is_a = false
        this.is_img = false
        this.formAdd.config.twnum = 0
        this.formAdd.config.tagtxt = false
      }
      // console.log("==getTDK,row.config.ext===",row.config.ext)

      row.config.ext ? this.formAdd.config.ext = row.config.ext : row.config.ext = ''

      this.no_js = row.config.no_js || 0
      this.qyStatus = row.config.js_title
      if (row.alias) {
        if (typeof (row.alias) === 'string') {
          row.alias = row.alias.split(',')
          row.alias.forEach((item) => {
            if (item === 'www') {
              this.domain_w = true
            } else if (item === 'm') {
              this.domain_m = true
            } else if (item === '@') {
              this.domain_at = true
            } else {
              moreArr.push(item)
            }
          })
          this.domain_more = moreArr.join(',')
        }
      }
      this.formRow = {}
      // row = JSON.parse(JSON.stringify(row));
      // 发起请求
      const parmers = {}
      parmers.site_id = siteid
      this.loadingRight = true
      tdkList(parmers).then(response => {
        // console.log("==response===",response)
        if (response.status && response.message != '没有找到该站点的TKD配置') {
          this.tkdData = response.data
          this.formRow.idxt = response.data.idx_t
          this.formRow.idxk = response.data.idx_k
          this.formRow.idxd = response.data.idx_d
          this.formRow.innt = response.data.inner_t
          this.formRow.innk = response.data.inner_k
          this.formRow.innd = response.data.inner_d
          this.formRow.innt_num = response.data.innt_num
          this.formRow.innk_num = response.data.innk_num
          this.formRow.innd_num = response.data.innd_num
        }

        // 更新右侧面板数据
        this.tkdData.domain = row.domain
        this.formRow.istatus = row.istatus
        this.formRow.site_id = row.id
        this.site_id = row.id
        this.formRow.domain = row.domain
        this.formRow.ser_id = row.ser_id
        this.formRow.origin = row.origin_domain
        this.formRow.group = row.igroup
        this.formRow.org_name = row.org_name
        this.formRow.jstitle = row.jstitle
        this.formRow.dns_ip = row.dns_ip
        this.formRow.bdqz = row.bdqz
        this.formRow.deep = row.deep
        this.formRow.alias = row.alias
        this.formRow.config = row.config
        this.formRow.server = row.server_ip
        this.formAdd = JSON.parse(JSON.stringify(this.formRow))
        // console.log("==alias===",this.formAdd.alias)
        // 更新二级域名单选框
        const moreArr = []
        this.formAdd.alias.forEach((item) => {
          if (item == 'www') {
            this.domain_w = true
          } else if (item == 'm') {
            this.domain_m = true
          } else if (item == '@') {
            this.domain_at = true
          } else {
            moreArr.push(item)
          }
        })
        this.domain_more = moreArr.join(',')

        if (this.domain_w) {
          this.aliasArr.push('www')
        }
        if (this.domain_at) {
          this.aliasArr.push('@')
        }
        if (this.domain_m) {
          this.aliasArr.push('m')
        }
        if (this.domain_more) {
          this.domain_more = this.domain_more.replace('，', ',')
          this.aliasArr2 = this.domain_more.split(',')
        }
        this.loadingRight = false
      }).catch(err => {
        this.loadingRight = false
        console.log(err)
      })
    },
    delSite(row) { // 单个删除
      this.action = 'delete'
      const delId = row.id || row.site_id
      this.delWebsit(delId)
    },
    stopSite(row) { // 单个禁用
      this.action = 'offline'
      const delId = row.id || row.site_id
      this.delWebsit(delId)
    },
    closeSite(row,status){
      // siteid,status=[0,1]0关闭；1开启
      const parmers={
        siteid:row.id || row.site_id,
        status:status
      }
      updateSiteStatus(parmers).then(res => {
        if (res.status) {
          this.$message({
            type: 'success',
            message: '操作成功！'
          })
          this.$emit('changeRow',row.id)
          this.getList()
          // 临时改变按钮状态

            this.formAdd.istatus = status
            this.currentIstatus = status
          // if (this.action == 'offline') {
          //   this.formAdd.istatus = 0
          //   this.currentIstatus = 0
          // } else if (this.action == 'online') {
          //   this.currentIstatus = 1
          // }
        } else {
          this.$message({
            type: 'error',
            message: res.message
          })
        }

      }).catch(err => {

      })
    },
    openSite(row) { // 启用站点
      // this.site_id = row.id
      this.action = 'online'
      const delId = row.id || row.site_id
      this.delWebsit(delId, row.id)
    },
    checkBlur(e, type) { // TDK设置一样
      // if(type === 'index' && this.tdkSameIndex) {
      //   this.formAdd.idxk = this.formAdd.idxt
      //   this.formAdd.idxd = this.formAdd.idxt
      // } else {
      //   this.formAdd.innk = this.formAdd.innt
      //   this.formAdd.innd = this.formAdd.innt
      // }
    },
    loadingClose() {
      const loadingInstance = Loading.service()
      this.$nextTick(() => {
        this.loading = false
        loadingInstance.close()
      })
    },
    delWebsit(siteid,rowId) { // 删
      let tipMsg='确定继续此操作?'
      if( this.action === 'offline' || this.action === 'delete' ){
        tipMsg+="<span style='color:#ff0000'>将会删除"+this.rowData.domain+"域名</span>"
      }

      this.$confirm(tipMsg, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        dangerouslyUseHTMLString:true,
        callback: action => {
          if (action == 'confirm') {
            const parmers = {}
            parmers.site_id = siteid
            parmers.action = this.action
            websiteDelete(parmers).then(res => {
              if (res.status) {
                this.$message({
                  type: 'success',
                  message: '操作成功！'
                })

                // this.formAdd= {}
                // this.getList()

                this.$emit('changeRow',rowId)

                // 临时改变按钮状态
                if (this.action == 'offline') {
                  // 禁用
                  this.formAdd.istatus = 0
                  this.currentIstatus = 0
                } else if (this.action == 'online') {
                  this.formAdd.istatus = 1
                  this.currentIstatus = 1
                }
              } else {
                this.$message({
                  type: 'error',
                  message: res.message
                })
              }
              setTimeout(() => {
                this.listLoading = false
              }, 1.5 * 1000)
            }).catch(err => {
              console.log(err)
              setTimeout(() => {
                this.listLoading = false
              }, 1.5 * 1000)
            })
          }
        }
      })
    },
    getCloneStatusInterval(item) {
      const _this = this
      _this.cloneStatus(item, 'auto').then(res => {
        if (res.status) {
          if (res.message === 'FAILED' || res.message === 'SUCCESS' || res.message === 'FINISHED') {
            clearInterval(_this.clonetimer)
          }
        }
      }).catch(err => {
        console.log(err)
      })
    },
    submitCloneTask() {
      const query = {}
      query.siteid = this.site_id
      query.fanti = 'no'
      // this.$set(row, 'showLoading', true)
      cloneStart(query).then(response => {
        if (response.status) {
          this.getList()

        }
      }).catch(err => {
        console.log(err)
      })
    },
    cloneCancel(row) {
      this.$alert('此操作取消克隆任务并不会删除已经克隆的站点, 是否继续?', '提示', {
        confirmButtonText: '确定',
        callback: action => {
          if (action == 'confirm') {
            const query = {}
            query.siteid = this.site_id
            this.$set(row, 'showLoading2', true)
            cloneStop(query).then(response => {
              if (response.status) {
              }
              setTimeout(() => {
                this.$set(row, 'showLoading2', false)
              }, 1.5 * 1000)
            }).catch(err => {
              console.log(err)
              setTimeout(() => {
                this.$set(row, 'showLoading2', false)
              }, 1.5 * 1000)
            })
          }
        }
      })
    },
    reOpenApplySsl(type, row) {
      if(this.siteType == 'edit'){
        let title = ''
        let msg = ''
        type == 'open' ? title = '开启' : title = '关闭'
        msg = `此操作将${title}申请证书, 是否继续?`
        if(type==='open'){
          this.sslChangePost(type, row)
        }else{
          if (type == 'force') {
            msg = '确定要操作吗？'
          }
          this.$alert(msg, '提示', {
            confirmButtonText: '确定',
            callback: action => {
              if (action == 'confirm') {
                this.sslChangePost(type, row)
              }
            }
          })
        }
      }


    },
    sslChangePost(type, row) {
      const _this = this
      const query = {}
      let sId = null
      if (row.id) {
        sId = row.id
      } else {
        sId = this.site_id
      }
      query.siteid = sId
      query.dns_id = 0, // DNSAPI的配置ID，没有则传0
      query.ssl_status = this.onlyHttps // 0关闭；1开启；2开启并强制
      this.loadingRetry = true
      if (type == 'open') { // 开启
        sslOpenApply(query).then(response => {
          if (response.status) {
            _this.$alert(response.message, '提示', {
              confirmButtonText: '确认'
            })
            if (response.data) {
              const obj = {}
              obj.sid = sId
              obj.tid = response.data
              localStorage.setItem(`sId_${sId}`, JSON.stringify(obj))
              _this.taskId = response.data
              this.timer = setInterval(() => {
                _this.sslSstatusProcessCheck()
              }, 2000)
            }
            _this.loadingRetry = false
          } else {
            this.$alert(response.data || response.message, '提示', {
              confirmButtonText: '确认'
            })
            this.taskMsgSsl = ''
            this.loadingRetry = false
          }
        }).catch(err => {
          this.loadingRetry = false
          console.log(err)
        })
      } else { // 关闭
        sslCloseApply(query).then(response => {
          if (response.status) {
            this.$alert(response.data, '提示', {
              confirmButtonText: '确认'
            })
          } else {
            this.$alert(response.message || response.data, '提示', {
              confirmButtonText: '确认'
            })
          }
        }).catch(err => {
          console.log(err)
        })
      }
    },
    ipChangeConfirm(newIp) {
      // const _this = this
      // if(this.formRow.server != newIp) {
      //   this.$confirm(`确定使用新ip：${newIp}？`, '操作确认', {
      //     confirmButtonText: '确定改',
      //     cancelButtonText: '不改了',
      //     type: 'warning'
      //   }).then(() => {
      //     _this.formRow.server = newIp
      //     this.formAdd.server = _this.formRow.server
      //   }).catch(() => {
      //     this.formAdd.server = JSON.parse(JSON.stringify(this.formRow.server));
      //     this.formAdd.dns_ip = JSON.parse(JSON.stringify(this.formRow.server));
      //   });
      // }
    },
    sslSstatusProcessCheck() { // 查询安装状态
      if (!this.taskId) {
        return
      }
      const parmers = {}
      parmers.taskid = this.taskId
      const _this = this
      sslSstatusProcess(parmers).then(res => {
        // console.log(res.message)
        if (res.status) {
          if (res.message === 'PROCESS') {
            _this.taskMsgSsl = res.data.message
          } else if (res.message === 'FAILED') {
            _this.taskMsgSsl = ''
            clearInterval(_this.timer)
          } else if (res.message === 'SUCCESS' || res.message === 'FINISHED') {
            _this.taskMsgSsl = ''
            clearInterval(_this.timer)
          } else {
            _this.taskMsgSsl = ''
          }
        }
      }).catch(err => {
        console.log(err)
      })
    },
    qyAutochange() {
      const _this = this
      _this.$confirm('将随机生成一个新的企业名覆盖当前的, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        _this.formRow.org_name = _this.getRandomName() || '浙江鸿森机械有限公司'
        _this.formAdd.org_name = JSON.parse(JSON.stringify(_this.formRow.org_name))
      })
    },
    getList() {
      EventBus.$emit('order', 'updateAddList', this.site_id) // 传递更新列表指令
    },
    dnsCheckIP() { // 查询ip
      const query = {}
      query.domain = this.formAdd.domain
      query.type = 'A'
      this.loadingBtn2 = true
      dnsQuery(query).then(response => {
        if (response.status && response.data) {
          this.ipListOnline = response.data.toString()
        } else {
          this.ipListOnline = response.message
        }
        this.loadingBtn2 = false
      }).catch(err => {
        console.log(err)
        this.loadingBtn2 = false
      })
    },
    dnsRretry() { // updateDns
      if (!this.formAdd.domain) {
        return this.$message.info('网站域名不能为空')
      } else if (!this.formAdd.dns_ip) {
        return this.$message.info('要解析的ip不能为空')
      }

      // 二级别名处理
      if (this.domain_w) {
        this.aliasArr.push('www')
      }
      if (this.domain_at) {
        this.aliasArr.push('@')
      }
      if (this.domain_m) {
        this.aliasArr.push('m')
      }
      if (this.domain_more) {
        this.domain_more = this.domain_more.replace('，', ',')
        this.aliasArr2 = this.domain_more.split(',')
      }
      this.aliasArr = this.aliasArr.concat(this.aliasArr2)
      this.aliasArr = this.unique(this.aliasArr)
      this.alias = this.aliasArr.join(',')

      const parmers = {}
      parmers.site_id = this.site_id
      parmers.domain = this.formAdd.domain // 域名
      parmers.alias = this.alias // 别名
      parmers.dns_ip = this.formAdd.dns_ip // 要设置的ip

      const _this = this
      // _this.$confirm('确定要重试解析操作吗?', '提示', {
      //   confirmButtonText: '确定',
      //   cancelButtonText: '取消',
      //   type: 'warning'
      // }).then(() => {
        _this.loadingBtn1 = true
        updateDns(parmers).then(res => {
          if (res.status && res.data[0].domainId) {
            _this.$alert(res.message, '成功提示', {
              confirmButtonText: '确认'
            })
          } else {
            _this.$alert(res.message, '失败提示', {
              confirmButtonText: '确认'
            })
          }
          _this.loadingBtn1 = false
        }).catch(err => {
          _this.loadingBtn1 = false
          console.log(err)
        })
      // })
    }
  }
}
</script>

<style lang="scss" >
@import "~@/styles/common.scss";
@import "~@/styles/website.scss";
.add-page {
  position: relative;
  .el-button [class*=el-icon-]+span {
    margin:0!important;
  }
}
.top-tip{
  position: absolute;
  top: -50px;
  left: 20px;
  width: 620px;
  height: 30px;
  display: flex;
  align-items: center;
  i{
    font-size: 16px;
    margin-right:10px;
    position: relative;
    margin-left:10px;
  }
  .el-button--mini{
    height: 28px;
  }
  .btn-bottom{
    border-bottom: none !important;
  }
}


</style>
<style lang="scss" scoped>
  .width-half{
    width: 50%;
  }
  .el-form-item-two{

    ::v-deep .width-half{
      width: 50% !important;
    }
    .flex-form{
      display: flex;
      align-items: center;
      margin-left: 10px;
    }
  }
  .show-msg-dia{
    ::v-deep li.el-timeline-item {
      list-style-type:none !important;

    }
  }
</style>

