<template>
  <div class="wrap-new">
    <div class="kx-main">
      <div class="kx-header">
        <h1>
          <label>狂侠站群系统</label>
          <div v-if="titleServer" class="title-box"
               :class="cloneLoadNum < 3000?'bg-green':cloneLoadNum > 5999?'bg-red':'bg-yellow'">
            <el-tooltip class="item" effect="light" placement="left">
              <div slot="content">
                计划任务：{{ unplanNum }}
                进行中：{{ cloneLoadNum }}
              </div>
              <span style="color: #fff">{{ titleServer }} - {{ valueServer }}</span>
            </el-tooltip>
          </div>
          <span v-if="!valueServer" style="color:#ffffff">未选择服务器</span>
          <span class="right-btn"/>
        </h1>
      </div>
      <div class="new-content">
        <servers-card
          :show-all-opation="true"
          :clone-deploy="true"
          @selectVal="selectServerFromSon"
        />

        <div class="new-content-right">
          <ul class="big-menus">
            <li
              v-for="(item, index) in bigMenus"
              :key="index"
              :class="{'active' : item.name === activeSys}"
              @click="menusChange(item.name)"
            >
              <i :class="`el-icon-${item.icon}`"/>
              <label>{{ item.title }}</label>
            </li>
            <li style="margin-left: auto; cursor: pointer;" @click="menusChange('home')">
              <i class="el-icon-s-home"/>
              <label>回到首页</label>
            </li>
            <li style="cursor: pointer;" @click="logout">
              <i class="el-icon-switch-button"/>
              <label>{{ $store.state.user.name }}</label>
            </li>
          </ul>
          <div id="container">
            <div class="left">
              <template
                v-if="(activeSys !== 'servers' &&  activeSys !== 'tools') ||(activeSys === 'tools' && toolsActiveName==='tools')">
                <site-list
                  v-if="showSiteList"
                  ref="siteListRef"
                  :ser_id="sid"
                  :row="row"
                  :siteId="Number(row.id)"
                  @row="getRow"
                  @getRowData="getRowData"
                />
              </template>
              <tool-list v-if="activeSys == 'tools' && toolsActiveName !='tools'" :sid="sid" :titleServer="titleServer"
                         @getToolsBatch="getToolsBatch"/>

            </div>


            <div class="right" v-if="isShow">

              <!-- 网站设置 -->
              <el-tabs
                v-if="activeSys == 'site' "
                v-model="activeSite"
                type="card"
                @tab-click="handleClickSite"
              >
                <el-tab-pane
                  v-for="(item, index) in webConfig"
                  :key="item.id"
                  :label="item.title"
                  :name="item.name"
                >
                  <div v-if="item.active && activeSite == 'config'" class="site-edit">
                    <site-add
                      :sid="sid"
                      :value-server="valueServer"
                      :row-data="row"
                      :title="title"
                      :site-type="siteType"
                      @changeRow="changeRow"
                    />
                  </div>
                </el-tab-pane>
              </el-tabs>


              <!-- 收录统计 -->
              <el-tabs v-if="activeSys == 'shoulu'" v-model="activeShoulu" type="card">
                <el-tab-pane label="网站收录" name="shoulu">
                  <shoulu-page v-if="activeSys == 'shoulu'" :sid="sid" :rowData="row"/>
                </el-tab-pane>
              </el-tabs>

              <!-- 蜘蛛统计 -->
              <el-tabs v-if="activeSys == 'spider'" v-model="activeSpider" type="card">
                <el-tab-pane label="蜘蛛统计" name="spider">
                  <spiderHistory v-if="activeSys == 'spider'" :sid="sid"/>
                </el-tab-pane>
              </el-tabs>

              <!-- 功能大全 -->
              <el-tabs v-if="activeSys == 'tools'" v-model="activeTools" type="card" @tab-click="handleClickTools">
                <!--                <el-tab-pane label="功能大全" name="tools">-->
                <!--                  <tools-page   :sid="sid" :titleServer="titleServer" />-->
                <!--                </el-tab-pane>-->
                <el-tab-pane label="批量广告" name="toolsUpdate">
                  <batch-update type="update" v-if="toolsActiveName =='toolsUpdate'" :toolsWebList="toolsWebList"
                                :sid="sid" :titleServer="titleServer"/>
                </el-tab-pane>
                <el-tab-pane label="批量统计" name="toolsReport">
                  <batch-update type="report" v-if="toolsActiveName =='toolsReport'" :toolsWebList="toolsWebList"
                                :sid="sid" :titleServer="titleServer"/>
                </el-tab-pane>
              </el-tabs>
              <!-- 泛站群 -->
              <el-tabs v-if="activeSys === 'moresites'" v-model="activeMoreSite" type="card"
                       @tab-click="handleClickMoreSites">
                <el-tab-pane label="网站配置" name="siteconfig">
                  <moreSiteOne ref="moreSiteOne" v-if="moreSitesActiveName ==='siteconfig'" :sid="sid" :row="row"
                               :spiderConfig="spiderConfig"/>
                </el-tab-pane>
                <el-tab-pane label="服务配置" name="serveconfig">
                  <moreSiteTwo v-if="moreSitesActiveName ==='serveconfig'"/>
                </el-tab-pane>
                <template v-if="showUpdate">
                  <el-tab-pane label="批量广告" name="MoreSiteUpdate">
                    <batch-update isFrom="fanzhanqun" :groupName="currentGroupName" :site_id="currentSiteId"
                                  type="update" :checkDomain="row.domain"
                                  v-if="moreSitesActiveName ='MoreSiteUpdate'   " :toolsWebList="toolsWebList"
                                  :sid="sid" :titleServer="titleServer"/>
                  </el-tab-pane>
                  <el-tab-pane label="批量统计" name="MoreSiteReport">
                    <batch-update isFrom="fanzhanqun" :groupName="currentGroupName" :site_id="currentSiteId"
                                  type="report" :checkDomain="row.domain"
                                  v-if="moreSitesActiveName ==='MoreSiteReport'   " :toolsWebList="toolsWebList"
                                  :sid="sid" :titleServer="titleServer"/>
                  </el-tab-pane>
                </template>

              </el-tabs>

            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 批量建站弹窗 -->
    <el-drawer
      class="pl-drawer gold-frame-drawer"
      title="开始建站"
      size="96%"
      :wrapper-closable="false"
      :visible.sync="dialogCreate"
      :direction="direction"
      @close="clsoeDialog"
    >
      <addSite
        v-if="dialogAddShow"
        :sid="sid"
        :value-server="valueServer"
        @clsoeDialog="clsoeDialog"
        @sonOrder="fromSonOrder"
      />
    </el-drawer>
  </div>
</template>

<script>
import Cookies from 'js-cookie'
import {mapGetters} from 'vuex'
import EventBus from '@/utils/eventBus.js'
import serversCard from '@/components/servers-card'
import serversSelect from '@/components/servers-select'
import VueDragResize from 'vue-drag-resize'
import siteList from '@/views/v2/website/list'
import toolList from '@/views/v2/tools/toolList'
import systemConfig from '@/views/v2/system/config'
import page404 from '@/views/v2/system/page404'
import allowIP from '@/views/v2/system/allowIP'
import blacklist from '@/views/v2/system/blacklist'
import robots from '@/views/v2/system/robots'
import shouluPage from '@/views/v2/report/shoulu'
import spiderHistory from '@/views/v2/report/spiderHistory'
import tools from '@/views/v2/tools/index'
import serverPage from '@/views/v2/server/index'
import upgradePage from '@/views/v2/server/upgrade'
import taskPage from '@/views/v2/server/task'
import firewallPage from '@/views/v2/server/firewall'
import siteAdd from '@/views/v2/website/add'
import pageConfig from '@/views/v2/website/page'
import addSite from '@/views/v2/website/add'
import setSitePage from '@/views/v2/website/setsitepage'
import toolsPage from '@/views/v2/tools/index'
import codePage from '@/views/v2/website/code'
import moreSiteOne from '@/views/v2/website/moreSiteOne'
import moreSiteTwo from '@/views/v2/website/moreSiteTwo'
import {
  cloneLoad
} from '@/api/system'
import {
  getSiteInfo,
} from '@/api/moreSite'
import BatchUpdate from "../tools/batchUpdate";

export default {
  components: {
    BatchUpdate,
    moreSiteOne,
    moreSiteTwo,
    VueDragResize,
    siteList,
    systemConfig,
    page404,
    allowIP,
    blacklist,
    robots,
    serverPage,
    shouluPage,
    spiderHistory,
    tools,
    serversCard,
    siteAdd,
    pageConfig,
    serversSelect,
    addSite,
    upgradePage,
    taskPage,
    firewallPage,
    toolsPage,
    setSitePage,
    codePage,
    toolList
  },
  data() {
    return {
      toolsActiveName: 'toolsUpdate',
      moreSitesActiveName: 'siteconfig',
      toolsWebList: [],
      activities: [
        {
          content: '影响等待建站的任务执行，如长时间居高不下，请尝试重启克隆服务',
          timestamp: '0',
          size: 'large',
          type: 'primary',
          icon: 'el-icon-more'
        }, {
          content: '正在克隆的任务数量，达到指定深度后停止。',
          timestamp: '0',
          color: '#0bbd87'
        }, {
          content: '未推送的克隆深度任务',
          timestamp: '0',
          size: 'large'
        }
      ],
      restatName: '',
      restatOpen: false,
      restatFlag: '',
      cloneLoadNum: 0,//正在处理：
      unplanNum: 0,//杂项任务
      waitNum: 0,//等待处理
      activeTools: 'toolsUpdate',
      activeMoreSite: 'siteconfig',
      activeSpider: 'spider',
      activeShoulu: 'shoulu',
      siteType: 'edit',
      title: '保存修改',
      pageType1: 'friendlink',
      pageType2: 'footjs',
      pageType3: 'headjs',
      pageType4: '404',
      pageType5: 'other',
      pageType6: 'nginx',
      showUrlInput: false,
      showPageSelect: false,
      dialogAddShow: false,
      dialogCreate: false,
      showSiteList: true,
      isShow: true,
      direction: 'btt', // 抽屉方向
      openDrawer: '',
      winLeft: 200,
      winTop: 20,
      activeSite: 'config',
      activeServer: 'serverList',
      activeSys: 'site',
      activeName: 'add',
      winWidth: 900,
      winHeight: 640,
      row: {},
      sid: null,
      valueServer: '',
      titleServer: '',
      spiderConfig: {},
      tabPosition: 'left',
      webConfig: [],
      webOriginalConfig: [
        {
          id: 1,
          title: '网站设置',
          name: 'config',
          active: true
        }

      ],
      bigMenus: [
        {
          name: 'site',
          icon: 'monitor',
          title: '网站管理'
        }, {
          name: 'shoulu',
          icon: 'folder-add',
          title: '网站收录'
        }, {
          name: 'spider',
          icon: 'data-analysis',
          title: '蜘蛛统计'
        }, {
          name: 'tools',
          icon: 'setting',
          title: '功能大全'
        }, {
          name: 'moresites',
          icon: 's-home',
          title: '泛站群'
        }
        // , {
        //   name: 'home',
        //   icon: 's-home',
        //   title: '回到首页'
        // }
      ],
      currentConfig: {},
      currentGroupName: '',
      currentSiteId: '',
      showUpdate: false
    }
  },
  beforeDestroy() {
    EventBus.$off('order')
    clearInterval(this.timer);
  },
  watch: {},
  mounted() {
    this.webConfig = [...this.webOriginalConfig]
    EventBus.$on('order', (order) => {
      if (order == 'showCK') {
        this.activeName = 'tools'
        EventBus.$emit('order', 'showCKPannel') // 传递更新列表指令
      } else if (order == 'addsite') {
      } else if (order == 'updateAddList') { // 更新右侧面板
        console.log('updateAddListupdateAddListupdateAddList')
      }
    })
    this.getCloneLoad()
    this.timer = setInterval(this.getCloneLoad, 5000)
  },
  methods: {
    submitDomain(domain) {
      console.log(domain, 'domain')
      this.$refs.siteListRef.getList()
      this.$set(this.row, 'domain', domain)
    },
    updateCofing(config) {
      const newRow = {
        ...this.row,
        config
      }
      this.currentConfig = Object.assign({}, config)
      this.row = Object.assign({}, newRow)
      this.$refs.siteListRef.getList()
    },
    selectServerFromSon(msg, list) { // 来自公共组件传值
      if (msg && list) {
        list.forEach((item) => {
          if (item.value == msg.server_ip) {
            this.sid = item.sid
            this.valueServer = msg.server_ip
            this.titleServer = msg.iname
            this.spiderConfig = item.spiderConfig

            // this.menusChange('site')
          }
        })
      }
    },
    clickHandle(e) {
      try {
        e.target.focus()
      } catch (e) {
      }
    },
    getRow(row) {
      if (row) {
        if (this.activeSys == 'moresites') {
          //选中的是泛站群就调用moreSiteOne 组件下面的方法
          getSiteInfo({
            domain: row?.domain
          }).then(response => {
            if (response.status) {
              const res = response.data
              if (res) {
                this.showUpdate = true
                this.currentGroupName = res?.igroup || 'defult',
                  this.currentSiteId = res?.id
              }
            } else {
              this.showUpdate = false
            }
          })
        }
        if (row == 'addsite') { // 添加站点指令
          this.dialogCreate = true
          this.dialogAddShow = true
        } else {

          this.row = row
          this.currentConfig = this.row?.config || {}
          this.activeName = 'add'
          const webConfigItem = [
            {
              id: 2,
              title: '友情连接',
              name: 'friendlink',
              active: false
            },
            {
              id: 3,
              title: '广告设置',
              name: 'footjs',
              active: false
            },
            {
              id: 4,
              title: '统计代码',
              name: 'headjs',
              active: false
            },
            {
              id: 5,
              title: '模版代码',
              name: 'other',
              active: false
            },
            {
              id: 6,
              title: 'Nginx配置',
              name: 'nginx',
              active: false
            }]
          //   ,{
          //   id: 6,
          //   title: '站点设置',
          //   name: 'siteset',
          //   active: false
          // }
          if (Number(row.istatus) === 3) {
            const newArr = new Set([...this.webOriginalConfig, ...webConfigItem])
            this.webConfig = [...newArr]
          } else {
            this.webConfig = [...this.webOriginalConfig]
          }
          this.activeSite = 'config'
          this.isShow = false
          EventBus.$off('row')
          EventBus.$off('order')
          this.webConfig[0].active = true
          setTimeout(() => {
            this.isShow = true
          }, 100)
          console.log(this.isShow, 'isShow')

        }
      }
    },
    handleClickTools(tab, event) {
      this.toolsActiveName = tab.name
    },
    handleClickMoreSites(tab, event) {
      this.moreSitesActiveName = tab.name
    },
    handleClick(tab, event) {
      this.activeName = tab.name
      if (tab.name == 'add') {
        this.showSiteList = true
        this.dialogCreate = true
        this.dialogAddShow = true
      }
      if (tab.name == 'server' || tab.name == 'shoulu' || tab.name == 'zhizhu') {
        this.showSiteList = false
      } else {
        this.showSiteList = true
      }
    },
    handleClickSite(tab, event) {
      // if(tab.name == 'config') {
      //   EventBus.$emit('domainActived', this.row.domain); //传递更新列表指令
      // }
      EventBus.$off('row')
      EventBus.$off('order')
      this.activeSite = tab.name
      this.webConfig.map((v, i) => {
        return v.active = Number(tab.index) === i
      })
    },
    handleClickSys(tab, event) {
      this.activeSys = tab.name
    },
    menusChange(name) {
      EventBus.$off('row')
      EventBus.$off('order')
      if (name === 'home') {
        this.$router.push('/')
      }
      this.activeSys = name
    },
    fromSonOrder(order) {
      this.dialogCreate = false
      this.dialogAddShow = false
    },
    changeRow(id) {
      this.$refs.siteListRef.getList('', '', id)
    },
    getToolsBatch(val) {
      this.toolsWebList = val
    },
    getRowData(row) {
      this.row = row
      this.currentConfig = this.row?.config || {}
    },
    clsoeDialog() {
      this.dialogCreate = false
      this.dialogAddShow = false
    },
    getCloneLoad() { // 查询克隆负载
      console.log('getCloneLoad', this.sid)
      const parmers = {}
      if (!this.sid) {
        return false
      }
      parmers.server_id = this.sid
      cloneLoad(parmers).then(res => {
        console.log(res, 'cloneLoadres')
        if (res.status) {
          this.cloneLoadNum = res.data?.process + '' || '0'
          // this.activities=[
          //   {
          //     content: '影响等待建站的任务执行，如长时间居高不下，请尝试重启克隆服务',
          //     timestamp: res.data?.wait +'' || '0',
          //     size: 'large',
          //     type: 'primary',
          //     icon: 'el-icon-more'
          //   }, {
          //     content: '正在克隆的任务数量，达到指定深度后停止。',
          //     timestamp: this.cloneLoadNum,
          //     color: '#0bbd87'
          //   }, {
          //     content: '未推送的克隆深度任务',
          //     timestamp: res.data?.unplan+'' || '0',
          //     size: 'large'
          //   }
          // ]
          this.waitNum = res.data?.process || 0
          this.unplanNum = res.data?.unplan || 0
        }
      }).catch(err => {
        console.log(err)
      })
    },
    logout() {
      const that = this
      this.$confirm('即将登出后台（程序会继续后台运行）, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        that.$message({
          type: 'success',
          message: '登出成功!'
        })
        sessionStorage.clear()
        localStorage.clear()
        Cookies.remove('Admin-Token')
        that.$store.dispatch('user/logout')
        setTimeout(() => {
          that.$router.push(`/login?redirect=${that.$route.fullPath}`)
        }, 1000)
      }).catch(() => {
      })
    }
  }
}
</script>


<style lang="scss" scoped>
/*.new-content-right {*/
/*  width: calc(100vw - 210px);*/
/*}*/
.bg-green {
  background: url("../../../assets/top-bg-50.png") no-repeat;
  background-size: 100% 100%;
}

.bg-yellow {
  background: url("../../../assets/top-bg-70.png") no-repeat;
  background-size: 100% 100%;
}

.bg-red {
  background: url("../../../assets/top-bg.png") no-repeat;
  background-size: 100% 100%;
}

.title-box {
  padding: 0 20px;
  height: 50px;
  min-width: 200px;

  .item-title {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 50px;
    background: #0dff0d;
  }

  .icon-green {
    background: #67C23A;
    width: 100%;
    height: 6px;
  }

  .icon-yellow {
    background: #E6A23C;
    width: 100%;
    height: 6px;
  }

  .icon-red {
    background: #F56C6C;
    width: 100%;
    height: 6px;
  }
}
</style>
<style lang="scss">
@import "~@/styles/box.scss";

.right-closed {
  background: rgba(0, 0, 0, 0.7);
  width: 100%;
  height: 100%;
  position: absolute;
  left: 200px;
  z-index: 999;

  p {
    color: #fff;
    font-size: 30px;
    margin: 200px 0 0 200px;
    text-shadow: 2px 2px 3px #c6ff29;
  }
}

.vdr.active:before {
  // outline: none;
}

.vdr-stick-tm,
.vdr-stick-ml,
.vdr-stick-mr,
.vdr-stick-bm {
  display: none;
}

.main-box {
  position: relative;
  display: flex;

  .el-tabs {
    .el-tabs__header {
      padding-bottom: 10px;
    }

    .el-tabs__content {
      overflow-x: auto;
    }
  }

  .el-input--medium .el-input__inner {
    height: 30px;
    line-height: 30px;
    border-color: #eee;
    color: #409EFF;
    font-family: monospace, monospace;
  }

  .el-select .el-input .el-select__caret {
    color: #0a51e0;
  }

  .el-input__suffix {
    right: 2px;
    top: 2px;
  }

  .is-focus {
    .el-input__suffix {
      top: -4px;
    }
  }

  .el-input--suffix {
    .el-input__inner {
      padding: 0;
    }
  }

  .box-footer {
    display: flex;
    align-items: center;
    font-size: 14px;

    p {
      padding: 0;
      margin: 15px 0 0 15px;
      cursor: pointer;

      &:hover {
        color: blue;
      }
    }
  }

  .right-btn {
    i {
      cursor: pointer;
      margin: 0 5px;

      &:hover {
        font-weight: bold;
      }
    }
  }
}

.active-server {
  color: #ebff10;
  animation: blink 1s linear infinite;
  -webkit-animation: blink 1s linear infinite;
  -moz-animation: blink 1s linear infinite;
  -ms-animation: blink 1s linear infinite;
  -o-animation: blink 1s linear infinite;
}

@keyframes blink {
  0% {
    color: #ebff10;
  }

  50% {
    color: red;
  }

  100% {
    color: #ebff10;
  }
}
</style>
