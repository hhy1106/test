<template>
    <div>
      <div>
      SSH开关
      <el-switch
        size="small"
        @change="sshSwitch()"
        v-model="sshStatus">
      </el-switch>

      <el-divider direction="vertical"></el-divider>

      禁ping
      <el-switch
        size="small"
        @change="pingSwitch()"
        v-model="pingStatus">
      </el-switch>

      <el-divider direction="vertical"></el-divider>

      Web日志：<span>/www/wwwlogs</span>12.34G

      <el-button
        type="success"
        size="small"
        :loadig="loadingBtn"
        style="margin: 0 10px 0 0;"
        @click="clearLog">
        清空
      </el-button>

    </div>
    <el-divider></el-divider>
    <div class="ssh-setting">
      ssh安全管理
      <el-form label-width="120px">
        <el-form-item label="SSH端口">
          <el-input size="small" v-model="sshPort" style="width: 100px;"></el-input>
          <el-button
            type="success"
            size="small"
            :loadig="loadingBtn"
            style="margin: 0 10px;"
            @click="savePort">
            保存
          </el-button>
          <el-link icon="el-icon-info" type="info" :underline="false">当前SSH协议所使用的的端口，默认为22</el-link>
        </el-form-item>

        <el-form-item label="root登录设置">
            <el-select v-model="loginSelect" size="small" style="width:300px">
              <el-option
                v-for="(index,item) in loginType"
                :label="item.label"
                 :key="index"
                :value="item.value">
              </el-option>
            </el-select>
        </el-form-item>

        <el-form-item label="SSH密码登录">
          <el-switch
            size="small"
            @change="loginPwdSwitch()"
            v-model="loginPwdStatus">
          </el-switch>
          <el-link icon="el-icon-info" type="info" :underline="false">SSH的默认登录方式</el-link>
        </el-form-item>

        <el-form-item label="SSH密钥登录">
          <el-switch
            size="small"
            @change="loginKeySwitch()"
            v-model="loginKeyStatus">
          </el-switch>
          <el-button
            type="success"
            size="mini"
            style="margin: 0 10px;"
            @click="viewKey">
            查看密钥
          </el-button>
          <el-button
            type="success" plain
            size="mini"
            style="margin: 0 10px 0 0;"
            @click="downloadKey">
            下载
          </el-button>
          <el-link icon="el-icon-info" type="info" :underline="false">推荐使用密钥登录，关闭密码，安全性更高</el-link>
        </el-form-item>

      </el-form>
    </div>
  </div>
</template>
<script>
import {
  sshList,
  sshSwitch
} from '@/api/system'

export default {
  data() {
    return {
      sshPort: '',
      loginPwdStatus: false,
      loginKeyStatus: false,
      pingStatus: false,
      sshStatus: false,
      loadingBtn: false,
      loginSelect: 'yes',
      loginType: [
        {
          value: 'yes',
          label: 'yes - 可密码和密钥登录'
        },{
          value: 'no',
          label: 'no - 禁止登录'
        },{
          value: 'without-password',
          label: 'without-password - 只能密钥登录'
        },{
          value: 'forced-commands-only',
          label: 'forced-commands-only - 只能执行命令'
        }
      ]
    }
  },
  mounted() {
    this.getsshList()
  },
  methods: {
    getsshList() { // 查
      let query = {}
      query.page = this.page
      query.limit = this.limit
      sshList(query).then(response => {
        if (response.status) {
          this.sshStatus = response.data.status
        } else {
          this.$message({
            type: 'error',
            message: res.message
          });
        }
      }).catch(err => {
        console.log(err)
      })
    },
    pingSwitch() {

    },
    clearLog() {

    },
    savePort() {

    },
    viewKey() {

    },
    downloadKey() {

    },
    loginPwdSwitch() {

    },
    loginKeySwitch() {

    },
    sshSwitch() {
      let title = ''
      let onoff = ''
      if(this.sshStatus) {
        title = '开启'
        onoff = 'on'
      } else {
        title = '关闭'
        onoff = 'off'
      }

      this.$confirm(`${title}ssh，继续操作?`, '操作确认', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$message({
          type: 'success',
          message: '操作成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消操作'
        });
      });

      let FormData = require('form-data');
      let parmers = new FormData();
      parmers.append('onoff', onoff);
      sshSwitch(parmers).then(res => {
        if (res.status) {
          this.$message({
            type: 'success',
            message: res.message
          });
        } else {
          this.$message({
            type: 'error',
            message: res.message
          });
        }
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  @import "~@/styles/common.scss";
  .ssh-setting {
    margin-top: 20px;
  }
</style>
