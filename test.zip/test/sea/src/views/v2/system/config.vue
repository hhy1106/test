<template>
  <div class="sys-page">
    <div class="checkbox-group">
      <el-checkbox v-model="checked">开启蜘蛛放行</el-checkbox>
      <el-checkbox v-model="checked">繁体站模式</el-checkbox>
      <el-checkbox v-model="checked">开启JStitle</el-checkbox>
      <el-checkbox v-model="checked1" disabled>开启日志记录</el-checkbox>
    </div>

    <el-button type="success" size="mini">保存设置</el-button>
  </div>
</template>


<script>
  export default {
    components: {
    },
    data() {
      return {
        checked: false,
        checked1: true,
      }
    },
    methods: {
    }
  }
</script>

<style scoped lang="scss">
  .sys-page {
    .checkbox-group {
      display: flex;
      flex-wrap: wrap;
      .el-checkbox {
        margin: 10px 8px 50px 20px;
        width: 120px;
      }
    }
    .el-button {
      margin: 0 20px 50px auto;
      float: right;
    }
  }
</style>
