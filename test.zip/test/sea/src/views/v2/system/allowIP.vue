<template>
  <div class="robots-page robots-page-two">
    <div class="left-box">
      <div class="robots-top">
        <p>放行蜘蛛IP段：（允许访问）</p>
        <el-button
          type="success"
          size="mini">
          保存
        </el-button>
      </div>
      <el-input
        class="robots-content"
        type="textarea"
        v-model="blockSpider"
        rows="15">
      </el-input>
    </div>
    <div class="right-box">
      <div class="robots-top">
        <p>删除蜘蛛ip段</p>
        <el-button
          type="success"
          size="mini">
          保存
        </el-button>
      </div>
      <el-input
        class="robots-content"
        type="textarea"
        v-model="blockIps"
        rows="15">
      </el-input>
    </div>
  </div>
</template>


<script>
  export default {
    components: {
    },
    data() {
      return {
        blockSpider: 'baiduBot',
        blockIps: '10.01.01',
      }
    },
    methods: {
    }
  }
</script>

<style scoped lang="scss">
  .robots-page {
    width: 100%;
    margin: 5px;
    .robots-top {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      line-height: .2;
      p {
        color: blue;
        font-size: 14px;
      }
    }
  }
  .robots-page-two {
      display: flex;
      justify-content: space-between;
      .left-box,
      .right-box{
        width: 49%;
      }
  }

</style>
