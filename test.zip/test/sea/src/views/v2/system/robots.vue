<template>
  <div class="robots-page">

    <div class="robots-top">
      <p>控制全部站点的robots.txt</p>
      <el-button
        type="success"
        size="mini">
        保存设置
      </el-button>
    </div>

    <el-input
      class="robots-content"
      type="textarea"
      v-model="textarea"
      rows="14">
    </el-input>

  </div>
</template>


<script>
  export default {
    components: {
    },
    data() {
      return {
        textarea: 'User-agent: *Allow: /',
      }
    },
    methods: {
    }
  }
</script>

<style scoped lang="scss">
  .robots-page {
    width: 100%;
    margin: 5px;
    .robots-top {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      line-height: .2;
      p {
        color: blue;
        font-size: 14px;
      }
    }
  }

</style>
